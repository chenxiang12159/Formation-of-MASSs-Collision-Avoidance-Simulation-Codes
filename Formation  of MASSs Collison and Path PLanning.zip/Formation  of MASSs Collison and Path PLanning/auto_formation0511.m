function [pose_quan_fina_x_res,pose_quan_fina_y_res] = auto_formation0511(i_form,pose_lead,fol_num,vars,formation,sub_lead,judge_tran_cond,N,pose_theta,tran_theta,dis_tran)
% 函数名称
% 根据子船的数量自动生成编队的队形,编队的队形应该根据设定的每排最多的数量进行取模的判断，模的不同，编队的最后一排的船舶也要变。
% mode 表示为更新的无人船编队的编队子船的个数

% 输入变量： 领导者船编号，领导者船当前时刻的位置，该领导者子跟随船的数量，当前的目标点的序号，当前编队信息，子领导者集合
%  详细说明：首先 队形的设置是固定好的。现在缺的是，如何把队形分配下去。即：队形是否负责更新每次迭代的跟随船的位置

if (sub_lead(i_form)==N)&& (judge_tran_cond(sub_lead(i_form))==2)
    
    
    
    for i_init_fol=1:fol_num    % 此处设定每次迭代过程中 的跟随无人船的位置
        i_fina_fol=formation(sub_lead(i_form),i_init_fol);
%         if i_fina_fol<4
%             init_f_auto(i_fina_fol,:)=[pose_lead(1,1)-(i_fina_fol-2)*20 pose_lead(1,2)-20];
%         elseif i_fina_fol<12
%             init_f_auto(i_fina_fol,:)=[pose_lead(1,1)-(i_fina_fol-7.5)*20 pose_lead(1,2)-40];
%         else
%             init_f_auto(i_fina_fol,:)=[pose_lead(1,1)-(i_fina_fol-15.5)*20 pose_lead(1,2)-60];
%         end
%         if  (i_fina_fol/n_fol_ajust)<=fix(fol_num/n_fol_ajust)
%              if mod(i_fina_fol,n_fol_ajust)==0
%                     init_f_auto(i_fina_fol,1)=pose_lead(1,1)-(n_fol_ajust-(n_fol_ajust+1)/2)*20;
%                     init_f_auto(i_fina_fol,2)=pose_lead(1,2)-(fix(i_fina_fol/(n_fol_ajust+1))+1)*20;
%             else
%                     init_f_auto(i_fina_fol,1)=pose_lead(1,1)-(mod(i_fina_fol,n_fol_ajust)-(n_fol_ajust+1)/2)*20;
%                     init_f_auto(i_fina_fol,2)=pose_lead(1,2)-(fix(i_fina_fol/n_fol_ajust)+1)*20;
%             end
% %                     init_f_auto(i_fina_fol,1)=pose_lead(1,1)-(mod(i_fina_fol,(n_fol_ajust+1))-(n_fol_ajust+1)/2)*20;
% %                     init_f_auto(i_fina_fol,2)=pose_lead(1,2)-(fix(i_fina_fol/(n_fol_ajust+1))+1)*20;
%             
%         else
% 
%             
%                     init_f_auto(i_fina_fol,1)=pose_lead(1,1)-(mod(i_fina_fol,n_fol_ajust)-(mod(fol_num,n_fol_ajust)+1)/2)*20;
%                     init_f_auto(i_fina_fol,2)=pose_lead(1,2)-(fix(i_fina_fol/n_fol_ajust)+1)*20;  
%                     
%         end
        init_f_auto(i_fina_fol,1)=pose_lead(1,1)+dis_tran(i_fina_fol,1,N-1)*cos(pose_theta+tran_theta(i_fina_fol,1,N-1));
        init_f_auto(i_fina_fol,2)=pose_lead(1,2)+dis_tran(i_fina_fol,1,N-1)*sin(pose_theta+tran_theta(i_fina_fol,1,N-1));    
        
            pose_quan_fina_x_res(formation(sub_lead(i_form),i_init_fol),vars(formation(sub_lead(i_form),i_init_fol)))=init_f_auto(i_fina_fol,1);
            pose_quan_fina_y_res(formation(sub_lead(i_form),i_init_fol),vars(formation(sub_lead(i_form),i_init_fol)))=init_f_auto(i_fina_fol,2);
    end



else
    % 按照专利中提及的 无人船自动形成队形
     for i_init_fol=1:fol_num    % 此处设定每次迭代过程中 的跟随无人船的位置
     % 得保证 pose_theta与tran_theta都是正值
        init_f_auto(i_init_fol,1)=pose_lead(1,1)+dis_tran(i_init_fol,1,fol_num)*cos(pose_theta+tran_theta(i_init_fol,1,fol_num));
        init_f_auto(i_init_fol,2)=pose_lead(1,2)+dis_tran(i_init_fol,1,fol_num)*sin(pose_theta+tran_theta(i_init_fol,1,fol_num));    
         
            pose_quan_fina_x_res(formation(sub_lead(i_form),i_init_fol),vars(formation(sub_lead(i_form),i_init_fol)))=init_f_auto(i_init_fol,1);
            pose_quan_fina_y_res(formation(sub_lead(i_form),i_init_fol),vars(formation(sub_lead(i_form),i_init_fol)))=init_f_auto(i_init_fol,2); 
         
         
         
         
%         if  (i_init_fol/n_fol_ajust)<=fix(fol_num/n_fol_ajust)
%              if mod(i_init_fol,n_fol_ajust)==0
%                     init_f_auto(i_init_fol,1)=pose_lead(1,1)+dis_tran(i_init_fol)*cos(pose_theta+tran_theta(i_init_fol));
%                     init_f_auto(i_init_fol,2)=pose_lead(1,2)+dis_tran(i_init_fol)*sin(pose_theta+tran_theta(i_init_fol)); 
%             else
%                     init_f_auto(i_init_fol,1)=pose_lead(1,1)-(mod(i_init_fol,n_fol_ajust)-(n_fol_ajust+1)/2)*20;
%                     init_f_auto(i_init_fol,2)=pose_lead(1,2)-(fix(i_init_fol/n_fol_ajust)+1)*20;
%             end
% %                     init_f_auto(i_fina_fol,1)=pose_lead(1,1)-(mod(i_fina_fol,(n_fol_ajust+1))-(n_fol_ajust+1)/2)*20;
% %                     init_f_auto(i_fina_fol,2)=pose_lead(1,2)-(fix(i_fina_fol/(n_fol_ajust+1))+1)*20;
%             
%         else
% 
%             
%                     init_f_auto(i_init_fol,1)=pose_lead(1,1)-(mod(i_init_fol,n_fol_ajust)-(mod(fol_num,n_fol_ajust)+1)/2)*20;
%                     init_f_auto(i_init_fol,2)=pose_lead(1,2)-(fix(i_init_fol/n_fol_ajust)+1)*20;  
%                     
%         end
%         if (i_init_fol/n_fol_ajust)<=fix(fol_num/n_fol_ajust) 
%                     init_f_auto(i_init_fol,1)=pose_lead(1,1)-(mod(i_init_fol,(n_fol_ajust+1))-(n_fol_ajust+1)/2)*20;
%                     init_f_auto(i_init_fol,2)=pose_lead(1,2)-(fix(i_init_fol/(n_fol_ajust+1))+1)*20;
%             
%         else
%                     init_f_auto(i_init_fol,1)=pose_lead(1,1)-(mod(i_init_fol,n_fol_ajust)-(mod(fol_num,n_fol_ajust)+1)/2)*20;
%                     init_f_auto(i_init_fol,2)=pose_lead(1,2)-(fix(i_init_fol/n_fol_ajust)+1)*20;  
%                     
%         end
        

    end
    % 注意这里的fol_num 不一定是所有的无人船序号，此处应该在外面套一个分路径的循环和判断。





end



end

