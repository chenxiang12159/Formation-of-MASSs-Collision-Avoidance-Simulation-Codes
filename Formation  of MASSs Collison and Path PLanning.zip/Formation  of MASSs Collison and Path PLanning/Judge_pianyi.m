function [indeed_obs] = Judge_pianyi(pose_next,pose_now,obs_num,theta_obs,theta_obs_dup,i_quan_num,i_quanju)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
indeed_obs=0;
dis_x=pose_next(1,1)-pose_now(1,1);
dis_y=pose_next(1,2)-pose_now(1,2);

                    if dis_x>=0&&dis_y>=0
                       theta=atan(dis_y/dis_x);
                    elseif dis_y>=0&&dis_x<0
                        theta=pi-abs(atan(dis_y/dis_x));
                    elseif dis_y<0&&dis_x<0
                        theta=pi+abs(atan(dis_y/dis_x));
                    elseif dis_y<0&&dis_x>=0
                        theta=2*pi-abs(atan(dis_y/dis_x));
                    end
% 修正了判断是否会穿越相关障碍物的条件
   if obs_num~=0
       if (max(theta_obs(i_quan_num,i_quanju,obs_num,:))-min(theta_obs(i_quan_num,i_quanju,obs_num,:)))>pi
            if (min(theta_obs_dup(i_quan_num,i_quanju,obs_num,:))<=theta)&&(theta<=max(theta_obs_dup(i_quan_num,i_quanju,obs_num,:)))
                indeed_obs=1;
                
            end
       else
           if (min(theta_obs(i_quan_num,i_quanju,obs_num,:))<=theta)&&(theta<=max(theta_obs(i_quan_num,i_quanju,obs_num,:))) 
                indeed_obs=1;
                
           end
       end
       

   end
end

