function [i_obs,Way_change] = theta_judge_extra(obs,theta_obs,theta,i_quan_num,i_quanju,theta_obs_dup)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
i_obs=[];
Way_change=0;
  for i_check=1:size(obs,3)

        if  (max(theta_obs(i_quan_num,i_quanju,i_check,:))-min(theta_obs(i_quan_num,i_quanju,i_check,:))>pi)
                 if (min(theta_obs_dup(i_quan_num,i_quanju,i_check,:))<=theta)&&(theta<=max(theta_obs_dup(i_quan_num,i_quanju,i_check,:)))  %theta_goal 是指当前情况下与目标点的位置

                      Way_change=Way_change+1;  %进入子目标点函数的信号
                      i_obs(Way_change,1)=i_check;
                      

                 end
                 
        else

        
                  if ((min(theta_obs(i_quan_num,i_quanju,i_check,:))<=theta)&&(theta<=max(theta_obs(i_quan_num,i_quanju,i_check,:))))  %theta_goal 是指当前情况下与目标点的位置

                      Way_change=Way_change+1;  %进入子目标点函数的信号
                      i_obs(Way_change,1)=i_check;

 
                  end   
      end
%       if i_check==size(obs,3)&&
%          Way_change=0; 
%          disp(['USV',num2str(i_quan_num),'的第',num2str(i_quanju),'次子目标点无碰撞路径'])
%       end
      
  end
  end



