function [theta_goal,Judge_theta_obs] = Quanju_theta_closest_obs(theta_goal,theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta_rec,num_theta,degree_quanju,theta_a)

        if theta_a==1
            

                                if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))>pi
                                    if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))<=theta_goal)&&(theta_goal<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:)))  %判断当前改变后的theta_goal1值是否影响刚才穿过的障碍物

                                            while (theta_goal)<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))
                                                        theta_goal=theta_goal+degree_quanju/4;% degree_quanju_sec 为每次向偏移的角度度数，设置为degree_quanju的一半

                                            end
                                            Judge_theta_obs=1;
                                            

                                    else
                                            Judge_theta_obs=2;
                                    end     
                                else
                                    if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))<=theta_goal)&&(theta_goal<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:)))  %theta_goal 是指当前情况下与目标点的位置
                                            while (theta_goal)<max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))
                                                        theta_goal=theta_goal+degree_quanju/4;% degree_quanju_sec 为每次向偏移的角度度数，设置为degree_quanju的一半

                                            end
                                            Judge_theta_obs=1;
                                            
                                    else
                                            Judge_theta_obs=2;
                                    end     
                                end 
                                
        elseif theta_a==2
                                 if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))>pi
                                    if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))<=theta_goal)&&(theta_goal<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:)))  %判断当前改变后的theta_goal2值是否影响刚才穿过的障碍物

                                            while (theta_goal)>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))
                                                        theta_goal=theta_goal-degree_quanju/4;% degree_quanju_sec 为每次向偏移的角度度数，设置为degree_quanju的一半

                                            end
                                            Judge_theta_obs=1;
                                            

                                    else
                                            Judge_theta_obs=2;
                                    end     
                                else
                                    if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))<=theta_goal)&&(theta_goal<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:)))  %theta_goal 是指当前情况下与目标点的位置
                                            while (theta_goal)>min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta_rec(i_quan_num,num_theta(i_quan_num,1)),:))
                                                        theta_goal=theta_goal-degree_quanju/4;% degree_quanju_sec 为每次向偏移的角度度数，设置为degree_quanju的一半

                                            end
                                            Judge_theta_obs=1;
                                            
                                    else
                                            Judge_theta_obs=2;
                                    end     
                                end 
            
            
        end
end

