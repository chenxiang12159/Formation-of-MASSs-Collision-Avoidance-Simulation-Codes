function [obs_pos,obs_pos_plot] = cal_quanju_obspoint(Obs,island_tran_pos)
%摘要 该函数是为了寻找出障碍物的四个关键点，以供主函数进行与障碍物连线的识别
island_num_test_all=0;
for island_trans=1:max(island_tran_pos(:,3))
    island_num=find(island_tran_pos(:,3)==island_trans);
    
%     for island_num_test=1:size(island_num,1)
% island_num_test_all是代指已经计算过的每个障碍物包含的点的个数
% obs 4列  x坐标列中最大的坐标的点的次序，y坐标列中最大坐标的点的次序，x坐标列中最小的坐标的点的次序，y坐标列中最小坐标的点的次序
        obs_point(island_trans,1)=find(Obs(island_num,1)==max(Obs(island_num,1)),1)+island_num_test_all;%找到第island_trans个x坐标列中最大的坐标的点的次序
        obs_point(island_trans,3)=find(Obs(island_num,1)==min(Obs(island_num,1)),1)+island_num_test_all; %找到第island_trans个x坐标列中最小的坐标的点的次序
        obs_point(island_trans,2)=find(Obs(island_num,2)==max(Obs(island_num,2)),1)+island_num_test_all ;%找到第island_trans个y坐标列中最大坐标的点的次序
        obs_point(island_trans,4)=find(Obs(island_num,2)==min(Obs(island_num,2)),1)+island_num_test_all ;%找到第island_trans个y坐标列中最小坐标的点的次序
        
        %和上述步骤重复
        obs_point_plot(island_trans,1)=find(Obs(island_num,1)==max(Obs(island_num,1)),1)+island_num_test_all;
        obs_point_plot(island_trans,3)=find(Obs(island_num,1)==min(Obs(island_num,1)),1)+island_num_test_all;
        obs_point_plot(island_trans,2)=find(Obs(island_num,2)==max(Obs(island_num,2)),1)+island_num_test_all;
        obs_point_plot(island_trans,4)=find(Obs(island_num,2)==min(Obs(island_num,2)),1)+island_num_test_all;
        obs_point_plot(island_trans,5)=find(Obs(island_num,1)==max(Obs(island_num,1)),1)+island_num_test_all;        %增加一个第五行，方便全局障碍物的地图连线
        island_num_test=size(island_num,1);
        island_num_test_all=island_num_test_all+island_num_test;
        
%     end

      
end
for island_tongji=1:max(island_tran_pos(:,3))
    for island_obs_point=1:size(obs_point,2)
        
        obs_pos(island_obs_point,1,island_tongji)=Obs(obs_point(island_tongji,island_obs_point),1);  
        obs_pos(island_obs_point,2,island_tongji)=Obs(obs_point(island_tongji,island_obs_point),2);
    end
end
% 下面的循环是为了全局障碍物地图的画法，不作为障碍物点来使用
for island_tongji=1:max(island_tran_pos(:,3))
    for island_obs_point=1:size(obs_point_plot,2)
        
        obs_pos_plot(island_obs_point,1,island_tongji)=Obs(obs_point_plot(island_tongji,island_obs_point),1);  
        obs_pos_plot(island_obs_point,2,island_tongji)=Obs(obs_point_plot(island_tongji,island_obs_point),2);
    end
end
%   传入真实地形的障碍物点数据，进行障碍物最外处点的确定


end

