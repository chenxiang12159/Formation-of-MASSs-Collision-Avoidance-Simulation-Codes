clc;
clear;
close all;

%% ���г���ǰ�ؿ� 
picture_save_dir1= ''  % your save path
%      'E:\Desktop\����\Ships and offshore structure\����\TSET1';  %�趨����Ľ��ͼ�ı���·��   ����
%% �ֶ����β���
%��ӳ�ʼ��������
fol_num=19;  %���洬������  
fol_test=fol_num;
N=20;           % ���˴��������(�����쵼�ߣ�
dt=1;             %����ʱ��  
n_fol_ajust=5; % ���쵼�� �����ı����һ������ӵ�е���󴬲�����
% Ŀ�����������ֶ�ʽ�� �ﵽĿ���1���ټ�����Ŀ���2ǰ��
% ������Ŀ������Ŀ�������� Ӧ����ҪǶ��һ��ѭ�� ѭ�����ж������� ����Ƿ��Ա�Ӷ��ε������õ���Ŀ��� �� ��Ҫ�޸� �ָ����εĺ�����
%% �յ㳢�Թ�������
goal=[14000 71500;18000 96000];       %����쵼��Ҫ�����Ŀ���
pose_fol_st=[14000 71400];
% ����Ǳ�Ӷ��Σ�Ϊ�ֶ����ӣ�������Ҫ��չ�߶�
Kinematic=[5;5;1.5;1.5];   % �ٶȵ����� [����ٶȣ�������ٶȣ������ٶȣ��������ٶ�]

%���������쵼�ߵĳ�ʼλ������


init_f_st(N,:)=[0 0 pi/2] ;   
for i_fol_mode=1:fol_test
    fol_num=i_fol_mode;
 for i_init_fol=1:fol_num    % �˴��趨ÿ�ε��������� �ĸ������˴���λ��


        if  (i_init_fol/n_fol_ajust)<=fix(fol_num/n_fol_ajust)   % ��15�������ʣ��ҳ����15�������Է���
            if mod(i_init_fol,n_fol_ajust)==0
                    init_f_st(i_init_fol,1)=init_f_st(N,1)-(n_fol_ajust-(n_fol_ajust+1)/2)*30;
                    init_f_st(i_init_fol,2)=init_f_st(N,2)-(fix(i_init_fol/(n_fol_ajust+1))+1)*30;
            else
                    init_f_st(i_init_fol,1)=init_f_st(N,1)-(mod(i_init_fol,n_fol_ajust)-(n_fol_ajust+1)/2)*30;
                    init_f_st(i_init_fol,2)=init_f_st(N,2)-(fix(i_init_fol/n_fol_ajust)+1)*30;
            end
                    
            
        else
                    init_f_st(i_init_fol,1)=init_f_st(N,1)-(mod(i_init_fol,n_fol_ajust)-(mod(fol_num,n_fol_ajust)+1)/2)*30;
                    init_f_st(i_init_fol,2)=init_f_st(N,2)-(fix(i_init_fol/n_fol_ajust)+1)*30;  
                    
        end
        

 end

    
    for i_tran_st=1:fol_num
        dis_st_fol(i_tran_st,1,i_fol_mode)=sqrt(init_f_st(i_tran_st,1)^2+init_f_st(i_tran_st,2)^2);
        tran_theta(i_tran_st,1,i_fol_mode)=atan2(init_f_st(i_tran_st,2),init_f_st(i_tran_st,1));
        if tran_theta(i_tran_st,1,i_fol_mode)<0
             tran_theta(i_tran_st,1,i_fol_mode)= tran_theta(i_tran_st,1,i_fol_mode)+2*pi;
        end
         tran_theta(i_tran_st,1,i_fol_mode)= tran_theta(i_tran_st,1,i_fol_mode)-pi/2; % ��һ������Ϊ��ʼ�ĽǶ�pose_lead�趨����pi/2
    end
end
    init_f_st(1:19,3)=init_f_st(N,3);
% ���
init_f(:,1)=init_f_st(:,1)+pose_fol_st(1,1);   %������ȫ�ַ�Χ��x
init_f(:,2)=init_f_st(:,2)+pose_fol_st(1,2);   %������ȫ�ַ�Χ��y
goal_fol(:,1,1)=init_f_st(:,1)+goal(1,1);
goal_fol(:,2,1)=init_f_st(:,2)+goal(1,2);
goal_fol(:,1,2)=init_f_st(:,1)+goal(2,1);
goal_fol(:,2,2)=init_f_st(:,2)+goal(2,2);

d_max_lead=30;   %�쵼�߾�����Ŀ������ǿ�����

d_max_fol=30;       %  ����ͧ����Ŀ�������ǿ�����


    
K_att=3;               % ��������ϵ��

K_rep_obs=150;           % ��������ϵ��-���ڲ�����㾲̬�ϰ���ĳ���
K_rep_obs_fol=150;       % ��������ϵ��-���ڲ���������˴����㾲̬�ϰ���ĳ���
K_rep_mass=1;          % ��������ϵ��-���ڼ����������˴���ɵĳ���
K_rep_ts=1;            % ��������ϵ��-���ڼ�����Ŵ������Ŵ�����λ����ɵĳ���
m_rep = 20;%�������������ϵ�� 
% i_lead=2;   % �쵼����Ŀ����ʼ����ֵ  

l = 1;%����

J = 20000;  %ѭ����������
pose_x=init_f(:,1);            % x��ȡ��һ��λ�õ���
pose_y=init_f(:,2);            % y��ȡ�ڶ��е���
pose_th=init_f_st(:,3);           % �Ƕȶ�ȡ�����е��� 





init_fols=init_f;
pose_setfol=init_fols;     
pose_setfol_x=pose_setfol(:,1);
pose_setfol_y=pose_setfol(:,2);
vars=ones(N,1)*2; % ���洬����Ŀ����ʼ����ֵ  



P_obs = 300;%�ϰ�Ӱ����룬���ϰ��ͳ��ľ�������������ʱ������Ϊ0�������ܸ��ϰ���Ӱ�졣Ҳ���Լ��趨��
c_obs=1; %mode_��̬�ϰ���

P_mass =20; % ����ڴ���Ӱ�����
c_mass=2;%mode_������������˴�

P_ts = 400;  % ���Ŵ���Ӱ�����
c_ts=3;%mode_����ڸ��Ŵ�
% �����������㷨

pose_change=zeros(1,N);%�������ø��ʵĳ�ʼֵ ,��Ҫ�ŵ���ǰ��
pose_change_judge=zeros(1,N);
pose_change_judge_num=zeros(1,N);
follower_arrive=zeros(1,N);
Arrive_goal=zeros(1,N);
disp_mass=zeros(1,N);
disp_mass_leader=0;
judge_fol_goal=zeros(1,N);
rec_opt_jubu=zeros(1,N); %������ǰ��
rec_opt_jubu_xunhuan=zeros(1,N);
sub_lead_rec=zeros(1,N);
radar=150; % �����ھֲ�����ʱ�����ж��Ƿ���Ĵ����ϰ����Ӱ�췶Χ�ڡ�
judge_tran_cond=zeros(1,N);
error=zeros(1,N-1); 
distance_jubu2vars=zeros(1,N);
     

for i_setfol=1:N
    delta_set_x(i_setfol)=pose_x(N,1)-pose_setfol(i_setfol,1);
    delta_set_y(i_setfol)=pose_y(N,1)-pose_setfol(i_setfol,2);
end
for i_set2pose=1:N-1
    distance_set2pose(i_set2pose,1)=sqrt((init_fols(i_set2pose,1)-init_f(i_set2pose,1))^2+(init_fols(i_set2pose,2)-init_f(i_set2pose,2))^2);
end


V_x(:,1)=zeros(1,N);           %��һ�е���ֵ
V_y(:,1)=zeros(1,N); %%%leader��y����ĳ�ʼ�ٶ�Ϊ1m/s
V_os(:,1)=zeros(1,N);
V_ts(:,1)=zeros(1,N);
V_record_lead_jubu=0;





%% AIS���ݵ���

ship_pos=xlsread('data_ship_v2.xlsx');% [��ţ����ʱ�䣬γ�ȣ�����]
R=6378100;
set_origin=[122 29];
for ship_trans=1:max(ship_pos(:,1))
    ship_num=find(ship_pos(:,1)==ship_trans);
    for ship_num_test=1:size(ship_num,1)
        ship_tran_pos(ship_num(ship_num_test),2)=R*[ship_pos(ship_num(ship_num_test),3)-set_origin(1,2)]/180*pi; %γ��תΪy����
        ship_tran_pos(ship_num(ship_num_test),1)=[ship_pos(ship_num(ship_num_test),4)-set_origin(1,1)]/180*pi*R*0.5*(180-ship_pos(ship_num(ship_num_test),3)-set_origin(1,2))/90; %����תΪx����
    end
    
end
ship_tran_pos(:,3)=ship_pos(:,1);% ship_tran_pos���У��ֱ���x��y�����
ship_tran_time(:,1)=ship_pos(:,1);
ship_tran_time(:,2)=ship_pos(:,2);
ship_num_ts=0; % ��ʼѰ�ұ����ŵ�ֵ
for ship_trans=1:max(ship_pos(:,1))
    
    ship_time_delta(ship_trans,1)=ship_num_ts(size(ship_num_ts,1),1)+1;
    ship_num_ts=find(ship_pos(:,1)==ship_trans);

    
end


N_ais_att=0;
for i_ship_point=1:max(ship_pos(:,1))               % init_attΪ��ʼ���Ŵ�����Ϣ
                                                    % 4�зֱ�Ϊ���Ŵ�x��㣬y��㣻x�յ㣬y�յ�
    ship_num_record=find(ship_pos(:,1)==i_ship_point);
    ship_point_record=size(ship_num_record,1);
    init_att(i_ship_point,1)=ship_tran_pos(ship_num_record(1),1);
    init_att(i_ship_point,2)=ship_tran_pos(ship_num_record(1),2);
    init_att(i_ship_point,3)=ship_tran_pos(ship_num_record(ship_point_record),1);
    init_att(i_ship_point,4)=ship_tran_pos(ship_num_record(ship_point_record),2);
    N_ais_att=N_ais_att+1;  % ��ʾ��������
end

Goal_att=init_att(:,3:4);%��ȡAIS���ݴ������յ���Ϣ


% init_att_th=atan2((Goal_att(:,2)-init_att(:,2)),(Goal_att(:,1)-init_att(:,1)));
for i_init_att_th=1:max(ship_pos(:,1))  % init_att_th�ĽǶ�Ϊ (0,2pi)
    

       if(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1))>=0&&(Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))>=0
                        init_att_th(i_init_att_th,1)=atan((Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))/(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1)));
            elseif (Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))>=0&&(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1))<0
                        init_att_th(i_init_att_th,1)=pi-abs(atan((Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))/(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1))));
            elseif (Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))<0&&(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1))<0
                        init_att_th(i_init_att_th,1)=pi+abs(atan((Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))/(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1))));
            elseif (Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))<0&&(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1))>0
                        init_att_th(i_init_att_th,1)=2*pi-abs(atan((Goal_att(i_init_att_th,2)-init_att(i_init_att_th,2))/(Goal_att(i_init_att_th,1)-init_att(i_init_att_th,1))));
       end
end       

    pose_att_x=init_att(:,1);
    pose_att_y=init_att(:,2);
    pose_att_th=init_att_th;
    pose_att_th_vir=init_att_th;
    att_pos=ones(max(ship_pos(:,1)),1);
att_vir_imp=200;   % ���⴬Ӱ�����ӣ�������ǰ̽��λ��,���⴬�Ĵ�λ��Ŀǰ���������㹻��  
% att_detect_R=2;


for i_att_vir_init=1:size(pose_att_x,1) % ���ø��Ŵ������⴬�ĳ�ʼλ��
    pose_att_x_vir(i_att_vir_init,1)=pose_att_x(i_att_vir_init,1)+cos(pose_att_th(i_att_vir_init,1))*att_vir_imp;
    pose_att_y_vir(i_att_vir_init,1)=pose_att_y(i_att_vir_init,1)+sin(pose_att_th(i_att_vir_init,1))*att_vir_imp;
end

% -------------------------------------------------------------------------
%% �ϰ����趨����ʼλ�ö���֪��·���滮,��ͼʵ�ִ������Թ滮��һ���ܿ��ϰ�����Ŀ���·����
% �����ϰ���
% �������
island_pos=xlsread('data_island.xlsx');

island_lat=island_pos(:,2);
island_long=island_pos(:,3);

for island_trans=1:max(island_pos(:,1))
    island_num=find(island_pos(:,1)==island_trans);
    for island_num_test=1:size(island_num,1)
        island_tran_pos(island_num(island_num_test),2)=R*[island_pos(island_num(island_num_test),2)-set_origin(1,2)]/180*pi; % ת��γ��
        island_tran_pos(island_num(island_num_test),1)=[island_pos(island_num(island_num_test),3)-set_origin(1,1)]/180*pi*R*0.5*(180-island_pos(island_num(island_num_test),2)-set_origin(1,2))/90; %ת������
    end
    

    
end
island_tran_pos(:,3)=island_pos(:,1);

%% ��̬�ϰ����ֵ����
% ˼·:�����ϰ���10��һ���������Լ�����˳��ȡ��,�����ĵ㶼�ǰ�˳��ȡֵ,�����ϰ�����Ŷ�ÿ���ϰ�����в�ֵ,����ԭ���Ǽ���
% ���������ϰ���ľ���,��������趨�ľ���ֵd_set_island.�ͽ����м��ֵ�����վ��볤�̷ֵ��ֵ�� ployfit
% ��������֮��б�ʣ�linespace �����Ⱦ�㡣
island_tran_pos_x=island_tran_pos(:,1)';
island_tran_pos_y=island_tran_pos(:,2)';
island_tran_pos_num=island_tran_pos(:,3)';
record_add_obs=0;
judge_chazhi=50;% �����Ƿ�������֮����в�ֵ���ж�ֵ
for island_trans=1:max(island_pos(:,1))
    island_num=find(island_pos(:,1)==island_trans);
    for i_chazhi=1:(size(island_num,1)-1)
        i_chazhi=i_chazhi+record_add_obs;
       dis_chazhi(i_chazhi)=sqrt((island_tran_pos(i_chazhi+1,1)-island_tran_pos(i_chazhi,1))^2+(island_tran_pos(i_chazhi+1,2)-island_tran_pos(i_chazhi,2))^2);
            if  dis_chazhi(i_chazhi)>judge_chazhi
                para_chazhi(i_chazhi,:)=polyfit([island_tran_pos(i_chazhi+1,1),island_tran_pos(i_chazhi,1)],[island_tran_pos(i_chazhi+1,2),island_tran_pos(i_chazhi,2)],1);
                delta_s(i_chazhi)=dis_chazhi(i_chazhi)/40;
                chazhi_x(i_chazhi,1:ceil(delta_s(i_chazhi))+1)=linspace(island_tran_pos(i_chazhi,1),island_tran_pos(i_chazhi+1,1),ceil(delta_s(i_chazhi))+1);% ceil+1 ��Ϊ�˵���ԭ���������㣬�Ӷ��������µĲ�ֵ�㡣
                chazhi_y(i_chazhi,1:ceil(delta_s(i_chazhi))+1)=para_chazhi(i_chazhi,1)*chazhi_x(i_chazhi,1:ceil(delta_s(i_chazhi))+1)+para_chazhi(i_chazhi,2); % �������ֵ���y����
                chazhi_num(i_chazhi,1:ceil(delta_s(i_chazhi))+1)=island_tran_pos_num(1,i_chazhi);
%                 for i_add_obs=1:(ceil(delta_s(i_chazhi))-1)
                    island_tran_pos_x=[island_tran_pos_x(1:i_chazhi) chazhi_x(i_chazhi,2:ceil(delta_s(i_chazhi))) island_tran_pos_x(i_chazhi+1:end)];
                    island_tran_pos_y=[island_tran_pos_y(1:i_chazhi) chazhi_y(i_chazhi,2:ceil(delta_s(i_chazhi))) island_tran_pos_y(i_chazhi+1:end)];
                    island_tran_pos_num=[island_tran_pos_num(1:i_chazhi) chazhi_num(i_chazhi,2:ceil(delta_s(i_chazhi))) island_tran_pos_num(i_chazhi+1:end)];
%                 end
   
            end
        
        
    end
    record_add_obs=record_add_obs+size(island_num,1);
    
end
island_tran_pos_add(:,1)=island_tran_pos_x';
island_tran_pos_add(:,2)=island_tran_pos_y';
island_tran_pos_add(:,3)=island_tran_pos_num';
Obs_all=[island_tran_pos_add(:,1) island_tran_pos_add(:,2)];


n=size(Obs_all,1);% �ϰ������



% r_os=2;


%% ȫ��·����Ŀ����ȷ��   
% ȫ��·�������ı�д
%   ��Ҫ��˳��ʱ���ת����ȷ���ϰ����λ�ü������ߵ�Ŀ��·���㹹��
% ���¼ƻ������켣�������캽����ҪȥѰ���µ��ϰ�����������ﵽ����������֪���ܵ�Ŀ��㣬(�յ�)���µ�wpӦ����Ŀ�괬�к���ǣ�
%  ...�ϰ���ͨ�� Ѱ�����е㡪��(�����͵İ뾶) ��ȷ��·����
pose_quan_x=init_f(:,1);  %ȫ�ַ�Χ�����˴���ӳ�ʼx����
pose_quan_y=init_f(:,2);  %ȫ�ַ�Χ�����˴���ӳ�ʼy����
goal_quanju=goal_fol;
degree_quanju=pi/180; %����Ѱ����Ŀ����ÿ�νǶȱ仯����
i_obs_judge_theta1_rec=[];
i_obs_judge_theta2_rec=[];
num_theta1=zeros(N,1);
num_theta2=zeros(N,1);
indeed_obs=zeros(N,1);
distan_pianyi=80;
%��Ϊ������Ŀ���ƫ���ϰ���ĵ��жϡ�
Obs_all_quanju=[island_tran_pos(:,1) island_tran_pos(:,2)];
[obs,obs_pos_plot]=cal_quanju_obspoint(Obs_all_quanju,island_tran_pos);


n_quanju=size(Obs_all_quanju,1);
[centre_obs,r_obs]=clock_search_method_single(obs); 

i_goal_quanju=1;
%% Test ȫ��·���Ļ�ȡ  

    for i_quanju=1:100
        Judge_distance=zeros(N,1)  ;  

        for i_quan_num=1:N        %����ȫ���յ�Ե�ǰλ�õĽǶ�

           dis_goal_os_x=goal_quanju(i_quan_num,1,i_goal_quanju)-pose_quan_x(i_quan_num,i_quanju);
           dis_goal_os_y=goal_quanju(i_quan_num,2,i_goal_quanju)-pose_quan_y(i_quan_num,i_quanju);
           if dis_goal_os_x>=0&&dis_goal_os_y>=0
                            theta_goal(i_quan_num,i_quanju)=atan(dis_goal_os_y/dis_goal_os_x);
                elseif dis_goal_os_y>=0&&dis_goal_os_x<0
                            theta_goal(i_quan_num,i_quanju)=pi-atan(abs(dis_goal_os_y/dis_goal_os_x));
                elseif dis_goal_os_y<0&&dis_goal_os_x<0
                            theta_goal(i_quan_num,i_quanju)=pi+atan(abs(dis_goal_os_y/dis_goal_os_x));
                elseif dis_goal_os_y<0&&dis_goal_os_x>0
                            theta_goal(i_quan_num,i_quanju)=2*pi-atan(abs(dis_goal_os_y/dis_goal_os_x));
           end

      %  ��������ϰ�����뱾���γɵļн�

            for i_obs_num=1:size(obs,3)  
                for i_deg_obs=1:size(obs,1)
                    dis_obs_os_x=obs(i_deg_obs,1,i_obs_num)-pose_quan_x(i_quan_num,i_quanju);  %����obs���Ϊi_obs_num��4��ѡ�еĵ���뱾���ľ���
                    dis_obs_os_y=obs(i_deg_obs,2,i_obs_num)-pose_quan_y(i_quan_num,i_quanju);

                        if dis_obs_os_x>=0&&dis_obs_os_y>=0                         %���ݾ���õ�ÿ���ϰ���4����Ըô��ļн�
                            theta_obs(i_quan_num,i_quanju,i_obs_num,i_deg_obs)=atan(dis_obs_os_y/dis_obs_os_x); % theta_obs(�������,�ڼ��ε���,�ϰ������,�ϰ���ĵڼ�����)��ɵĽǶ�
                        elseif dis_obs_os_y>=0&&dis_obs_os_x<0
                            theta_obs(i_quan_num,i_quanju,i_obs_num,i_deg_obs)=pi-atan(abs(dis_obs_os_y/dis_obs_os_x));
                        elseif dis_obs_os_y<0&&dis_obs_os_x<0
                            theta_obs(i_quan_num,i_quanju,i_obs_num,i_deg_obs)=pi+atan(abs(dis_obs_os_y/dis_obs_os_x));
                        elseif dis_obs_os_y<0&&dis_obs_os_x>0
                            theta_obs(i_quan_num,i_quanju,i_obs_num,i_deg_obs)=2*pi-atan(abs(dis_obs_os_y/dis_obs_os_x));
                        end
                end

            end


            theta_obs_dup(i_quan_num,i_quanju,:,:)=theta_obs(i_quan_num,i_quanju,:,:);        %���� ����Ͱ�֮ǰ�ļ���õĸ�������
            for i_check=1:size(obs,3)     %����theta_obs_dup ��theta_obs����ĽǶȷ�Χ��Ҫ����270�㣬��Ϊ���ж��Ƿ񴩹��ϰ���ʱ������ϰ��ﱾ��4�����Ƚϴ���Ҫת���ϰ���ĽǶ�Ϊͬһ��������ͬΪ180�����ڽ����жϣ�,���ֽǶ���[-pi/2,3/2pi]]
                for i_deg_change=1:size(theta_obs,4)
                    if theta_obs(i_quan_num,i_quanju,i_check,i_deg_change)>1.5*pi           % �����ϰ��������˴���λ�� 4����ֱ���Ŀ����1��4���ޣ���������нǶ�ת�������1���޵��ϰ����Ƕȴ���theta_goal��4���޵��ϰ����Ƕȴ���theta_goal��4���ϰ���Ƕȶ�>theta_goal�������ϲ������ϰ��ʵ�����Ǵ����ϰ�� ������Ҫ���нǶȻ��㡣
                        theta_obs_dup(i_quan_num,i_quanju,i_check,i_deg_change)= theta_obs(i_quan_num,i_quanju,i_check,i_deg_change)-2*pi;
                    end
                end 
            end
            % �жϵ�ǰ���˴��Ĺ滮λ�����յ������ϰ�������ߣ��ж��Ƿ���Ҫ��ʼ�����ϰ��� ��û�п��Ǹ���theta_goal
                distance_quanju2goal(i_quan_num,i_quanju)=sqrt((goal_quanju(i_quan_num,1,i_goal_quanju)-pose_quan_x(i_quan_num,i_quanju))^2+(goal_quanju(i_quan_num,2,i_goal_quanju)-pose_quan_y(i_quan_num,i_quanju))^2);

                [i_obs_quanju_theta,Way_change_theta]=theta_judge_extra(obs,theta_obs,theta_goal(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                if Way_change_theta>0
                                    for i_cal_centre=1:size(i_obs_quanju_theta,1)
                                        pose_cal_syn(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta(i_cal_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta(i_cal_centre,1),2))^2);

                                    end
                    i_cal_ob(i_quan_num)=i_obs_quanju_theta(find(pose_cal_syn(i_quan_num,1:size(i_obs_quanju_theta,1))==min(pose_cal_syn(i_quan_num,1:size(i_obs_quanju_theta,1)))),1);
                    distance_quanju2obs(i_quan_num,i_quanju)=sqrt((centre_obs(i_cal_ob(i_quan_num),1)-pose_quan_x(i_quan_num,i_quanju))^2+(centre_obs(i_cal_ob(i_quan_num),2)-pose_quan_y(i_quan_num,i_quanju))^2);


                    if  distance_quanju2goal(i_quan_num,i_quanju)<distance_quanju2obs(i_quan_num,i_quanju)
                            Way_change=0;
                    else
                            Way_change=1;
                    end
                else
                    Way_change=0;
                end
            if Way_change==1   % ˵����ǰ�Ƕ��Ѿ���Խ���ϰ����Ҫ���ĳ���Ŀ���ĽǶȽ��б���
                % ׼������
                theta_goal1(i_quan_num,i_quanju)=theta_goal(i_quan_num,i_quanju);   %׼���ӱ�������Ŀ���ĽǶȽ�����������Ѱ�ҿ����ƹ��ϰ���ĵ�
                theta_goal2(i_quan_num,i_quanju)=theta_goal(i_quan_num,i_quanju);
                Way_change_theta1=Way_change;           
                Way_change_theta2=Way_change;


                theta1(i_quan_num,i_quanju)=0;
                theta2(i_quan_num,i_quanju)=0;

                Judge_theta_obs1(i_quan_num)=0;
                Judge_theta_obs2(i_quan_num)=0;



                if mod(i_quan_num,2)==0     % ���滮·��������ż�Բ�ͬ�ֿ�
                      while Way_change_theta1==1
                            theta_a=1;
                            [i_obs_quanju_theta1,Way_change_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                if Way_change_theta1>0
                                            for i_cal_centre=1:size(i_obs_quanju_theta1,1)
                                                pose_cal_theta1(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta1(i_cal_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta1(i_cal_centre,1),2))^2);

                                            end
                                    i_cal_ob(i_quan_num)=i_obs_quanju_theta1(find(pose_cal_theta1(i_quan_num,1:size(i_obs_quanju_theta1,1))==min(pose_cal_theta1(i_quan_num,1:size(i_obs_quanju_theta1,1)))),1);
                                    i_obs_judge_theta1(i_quan_num)=i_cal_ob(i_quan_num);
                                end

                                if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:)))
                                    while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:))


                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju;
                                    end
                                        %�����ж��Ƿ�Խ����һ���ϰ���          
                                        if num_theta1(i_quan_num,1)~=0                           
                                            if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))>pi
                                                if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal1ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                        while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        [obs_theta1]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                        obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                        [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta1>0
                                                                    for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                        pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                    if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                end
                                                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                    end                                              
                                                        end                                         
                                                        Judge_theta_obs1(i_quan_num)=1;
                                                        break;

                                                else
                                                        Judge_theta_obs1(i_quan_num)=0;
                                                end     
                                            else
                                                if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                        while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        [obs_theta1]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                        obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                        [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta1>0
                                                                    for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                        pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                    if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                end
                                                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                    end

                                                        end                                    
                                                        Judge_theta_obs1(i_quan_num)=1;
                                                        break;
                                                else
                                                        Judge_theta_obs1(i_quan_num)=0;
                                                end     
                                            end

                                        end

                                else
                                    while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:))
                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju;

                                    end
                                        %�����ж�
                                        if num_theta1(i_quan_num,1)~=0
                                            if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))>pi
                                                if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal1ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                        while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        [obs_theta1]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                        obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                        [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta1>0
                                                                    for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                        pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                    if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��
                                                                                end
                                                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                    end                                             
                                                        end                                           
                                                        Judge_theta_obs1(i_quan_num)=1;
                                                        break;
                                                else
                                                        Judge_theta_obs1(i_quan_num)=0;
                                                end     
                                            else
                                                if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                        while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        [obs_theta1]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                        obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                        [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta1>0
                                                                    for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                        pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                    if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                end
                                                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                    end                                            
                                                        end
                                                        Judge_theta_obs1(i_quan_num)=1;
                                                        break;
                                                else
                                                        Judge_theta_obs1(i_quan_num)=0;
                                                end     
                                            end

                                        end

                                 end 

                              [i_obs_cal_theta1,Way_change_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup); 
                              % num_theta1==0 ����Գ�ʼ�����������������λ�ã��ɱ�
                              if (num_theta1(i_quan_num,1)==0)
                                   while Way_change_theta1>0
                                       if Way_change_theta1>=1
                                            for i_cal_centre=1:size(i_obs_cal_theta1,1)
                                                pose_cal_syn1(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre),2))^2);
                                            end
                                            i_cal_obs1(i_quan_num)=i_obs_cal_theta1(find(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1))==min(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1)))),1);
                                            if  max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))-min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))>pi
                                                     if (min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))


                                                            while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                            end
                                                             i_obs_judge_theta1(i_quan_num)=i_cal_obs1(i_quan_num); 
                                                              Judge_theta_obs1(i_quan_num)=4;


                                                     end
                                             else
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))


                                                            while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                            end
                                                             i_obs_judge_theta1(i_quan_num)=i_cal_obs1(i_quan_num);  
                                                             Judge_theta_obs1(i_quan_num)=4;                                         
                                                    end
                                            end     
                                       end
                                        [i_obs_cal_theta1,Way_change_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                    end

                              end





                                if (num_theta1(i_quan_num,1)~=0)&&(Judge_theta_obs1(i_quan_num)==0)
                                    cishu=0;
                                     while (Way_change_theta1>0)&&(cishu<=2)
                                        if Way_change_theta1>0
                                            for i_cal_centre=1:size(i_obs_cal_theta1,1)
                                                pose_cal_syn1(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre,1),2))^2);
                                            end
                                            if cishu<2
                                                pose_cal_syn1(i_quan_num,i_cal_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta1(i_quan_num),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta1(i_quan_num),2))^2);
                                                i_obs_cal_theta1(i_cal_centre+1,1)=i_obs_judge_theta1(i_quan_num);
                                            end


                                                    i_cal_obs1(i_quan_num)=i_obs_cal_theta1(find(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1))==min(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1)))),1);

                                                 if  max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))-min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))>pi
                                                     if (min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))

                                                            while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                            end
                                                            % ����ĺ����������жϴ�ʱ�ĽǶ��Ƿ񴩹�����һ���������е��ϰ��������һ��Խ�����ϰ���
                                                            [theta_goal1(i_quan_num,i_quanju),Judge_theta_obs1(i_quan_num)] = Quanju_theta_closest_obs(theta_goal1(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta1_rec,num_theta1,degree_quanju,theta_a);                                               

                                                     end
                                                 else
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))

                                                           while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                            end
                                                              [theta_goal1(i_quan_num,i_quanju),Judge_theta_obs1(i_quan_num)] = Quanju_theta_closest_obs(theta_goal1(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta1_rec,num_theta1,degree_quanju,theta_a);                                              

                                                    end
                                                 end
                                            i_obs_judge_theta1(i_quan_num)=i_cal_obs1(i_quan_num);    
                                        end
                                        [i_obs_cal_theta1,Way_change_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                        cishu=cishu+1;
                                     end
                                end
                                num_theta1(i_quan_num,1)=num_theta1(i_quan_num,1)+1;
                                if Judge_theta_obs1(i_quan_num)==1
                                    i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)-1);
                                elseif Judge_theta_obs1(i_quan_num)==2
                                    i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_cal_obs1(i_quan_num);
                                elseif Judge_theta_obs1(i_quan_num)==4
                                     i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_obs_judge_theta1(i_quan_num);
                                else
                                    i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_obs_judge_theta1(i_quan_num);
                                end    
                            Way_change_theta1=0;
            %                 [i_obs_judge_theta1(i_quan_num),Way_change_theta1]=theta_judge_2_0(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_a,theta_obs_dup);
                       end

                %Ϊ�ڶ���ѭ����׼�� ����һ��ѭ�����ƣ���֮ͬ���������ѭ����Ѱ�����ӽǶȺ����·��
                        while Way_change_theta2==1
                            theta_a=2;
                            [i_obs_quanju_theta2,Way_change_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                if Way_change_theta2>0
                                            for i_cal_centre=1:size(i_obs_quanju_theta2,1)
                                                pose_cal_theta2(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta2(i_cal_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta2(i_cal_centre,1),2))^2);

                                            end
                                    i_cal_ob(i_quan_num)=i_obs_quanju_theta2(find(pose_cal_theta2(i_quan_num,1:size(i_obs_quanju_theta2,1))==min(pose_cal_theta2(i_quan_num,1:size(i_obs_quanju_theta2,1)))),1);
                                    i_obs_judge_theta2(i_quan_num)=i_cal_ob(i_quan_num);
                                end

                                if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:)))
                                    while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:))
                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju; 
                                    end
                                        if num_theta2(i_quan_num,1)~=0
                                            if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))>pi
                                                if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal2ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                        while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        [obs_theta2]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                        obs_theta_x2=obs(obs_theta2(1,1),1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y2=obs(obs_theta2(1,1),2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                        [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta2>0
                                                                    for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                        pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2)^2);
                                                                    if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                end
                                                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                    end                                         
                                                        end
                                                        Judge_theta_obs2(i_quan_num)=1;
                                                        break;
                                                else
                                                        Judge_theta_obs2(i_quan_num)=0;
                                                end     
                                            else
                                                if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                        while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        [obs_theta2]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                        obs_theta_x2=obs(obs_theta2,1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y2=obs(obs_theta2,2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                        [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta2>0
                                                                    for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                        pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2(1,1))^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2(1,1))^2);
                                                                    if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                end
                                                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                    end



                                                        end

                                                        Judge_theta_obs2(i_quan_num)=1;
                                                        break;

                                                else  
                                                    Judge_theta_obs2(i_quan_num)=0;
                                                end     
                                            end 
                                        end


                                else

                                    while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:))

                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju;   
                                    end
                                        %�����ж�
                                        if num_theta2(i_quan_num,1)~=0
                                            if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))>pi
                                                if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal2ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                        while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        [obs_theta2]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                        obs_theta_x2=obs(obs_theta2,1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y2=obs(obs_theta2,2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                        [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta2>0
                                                                    for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                        pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2)^2);
                                                                    if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                end
                                                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                    end



                                                        end
                                                        Judge_theta_obs2(i_quan_num)=1;
                                                        break;

                                                else
                                                        Judge_theta_obs2(i_quan_num)=0;
                                                end     
                                            else
                                                if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                        while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                        end
                                                        % ��Judge_theta_obs2��������
                                                        [obs_theta2]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                        obs_theta_x2=obs(obs_theta2,1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                        obs_theta_y2=obs(obs_theta2,2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                        [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                        if Way_find_theta2>0
                                                                    for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                        pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                    end
                                                                        pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2)^2);
                                                                    if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                        [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                end
                                                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                    end                               
                                                        end
                                                        Judge_theta_obs2(i_quan_num)=1;
                                                        break;
                                                else  
                                                    Judge_theta_obs2(i_quan_num)=0;
                                                end    

                                            end
                                        end

                                end

                                [i_obs_cal_theta2,Way_change_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);   
                                if (num_theta2(i_quan_num,1)==0)

                                       if Way_change_theta2>=1
                                            for i_cal_centre=1:size(i_obs_cal_theta2,1)
                                                pose_cal_syn2(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta2(i_cal_centre),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta2(i_cal_centre),2))^2);
                                            end
                                            i_cal_obs2(i_quan_num)=i_obs_cal_theta2(find(pose_cal_syn2(i_quan_num,1:size(i_obs_cal_theta2,1))==min(pose_cal_syn2(i_quan_num,1:size(i_obs_cal_theta2,1)))),1);
                                            if  max(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))-min(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))>pi
                                                     if (min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:)))


                                                            if  i_cal_obs2(i_quan_num)==22
                                                                while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju/8;
                                                                end
                                                                 i_obs_judge_theta2(i_quan_num)=i_cal_obs2(i_quan_num); 
                                                                 
                                                                  Judge_theta_obs2(i_quan_num)=0;
                                                                
                                                            else
                                                                while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/8;
                                                                end
                                                                 i_obs_judge_theta2(i_quan_num)=i_cal_obs2(i_quan_num); 
                                                                  Judge_theta_obs2(i_quan_num)=4;
                                                            end                                             
                                                     end

                                             else
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:)))


                                                             if  i_cal_obs2(i_quan_num)==22
                                                                while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju/8;
                                                                end
                                                                 i_obs_judge_theta2(i_quan_num)=i_cal_obs2(i_quan_num); 
                                                                 
                                                                  Judge_theta_obs2(i_quan_num)=0;
                                                                
                                                            else
                                                                while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/8;
                                                                end
                                                                 i_obs_judge_theta2(i_quan_num)=i_cal_obs2(i_quan_num); 
                                                                  Judge_theta_obs2(i_quan_num)=4;
                                                            end

                                                    end
                                            end    
        %                                     [i_obs_cal_theta2,Way_change_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);   
                                       end

                                end



                                if (num_theta2(i_quan_num,1)~=0)&&(Judge_theta_obs2(i_quan_num)==0)
                                    cishu=0;
                                    while( Way_change_theta2>=1)&&(cishu<=2)
                                        if Way_change_theta2>=1
                                            for i_cal_centre=1:size(i_obs_cal_theta2,1)
                                                pose_cal_syn2(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta2(i_cal_centre),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta2(i_cal_centre),2))^2);
                                            end
                                            if cishu<2
                                                 pose_cal_syn2(i_quan_num,i_cal_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta2(i_quan_num),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta2(i_quan_num),2))^2);
                                                 i_obs_cal_theta2(i_cal_centre+1,1)=i_obs_judge_theta2(i_quan_num);
                                            end

                                                    i_cal_obs2(i_quan_num)=i_obs_cal_theta2(find(pose_cal_syn2(i_quan_num,1:size(i_obs_cal_theta2,1))==min(pose_cal_syn2(i_quan_num,1:size(i_obs_cal_theta2,1)))),1);

                                            if  max(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))-min(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))>pi
                                                     if (min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:)))


                                                            while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju/8;
                                                            end
                                                             [theta_goal2(i_quan_num,i_quanju),Judge_theta_obs2(i_quan_num)] = Quanju_theta_closest_obs(theta_goal2(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta2_rec,num_theta2,degree_quanju,theta_a);                                 
                                                     end
                                             else
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:)))


                                                            while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju/8;
                                                            end
                                                             [theta_goal2(i_quan_num,i_quanju),Judge_theta_obs2(i_quan_num)] = Quanju_theta_closest_obs(theta_goal2(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta2_rec,num_theta2,degree_quanju,theta_a);                              



                                                    end
                                            end
                                            i_obs_judge_theta2(i_quan_num)=i_cal_obs2(i_quan_num);
                                        end
                                        [i_obs_cal_theta2,Way_change_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                        if  i_obs_cal_theta2==15  % ���15�ӿ�
                                            Way_change_theta2=0;
                                        end
                                        cishu=cishu+1;
                                    end
                                end
                                num_theta2(i_quan_num,1)=num_theta2(i_quan_num,1)+1;
                                if Judge_theta_obs2(i_quan_num)==1
                                    i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1);
                                elseif Judge_theta_obs2(i_quan_num)==2
                                    i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_cal_obs2(i_quan_num);
                                elseif Judge_theta_obs2(i_quan_num)==4
                                    i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_obs_judge_theta2(i_quan_num);
                                else
                                    i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_obs_judge_theta2(i_quan_num);
                                end

                           Way_change_theta2=0; 
                        end 
                
                else
                    % ���˴������Ϊ���� ����ÿ��������ϰ�����ߵĲ���
                      while Way_change_theta1==1
                                theta_a=1;
                                [i_obs_quanju_theta1,Way_change_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                        if Way_change_theta1>0
                                                    for i_cal_centre=1:size(i_obs_quanju_theta1,1)
                                                        pose_cal_theta1(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta1(i_cal_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta1(i_cal_centre,1),2))^2);

                                                    end
                                            i_cal_ob(i_quan_num)=i_obs_quanju_theta1(find(pose_cal_theta1(i_quan_num,1:size(i_obs_quanju_theta1,1))==min(pose_cal_theta1(i_quan_num,1:size(i_obs_quanju_theta1,1)))),1);
                                            i_obs_judge_theta1(i_quan_num)=i_cal_ob(i_quan_num);
                                        end

                                      if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:)))
                                            while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:))


                                            theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju;
                                            if num_theta1(i_quan_num,1)~=0
                                                if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))>pi
                                                    if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal1ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                            while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end

                                                                [obs_theta1]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                                obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                                obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                                [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta1>0
                                                                            for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                                pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                            end
                                                                            pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                        if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                            theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                        end

                                                            end

                                                            Judge_theta_obs1(i_quan_num)=1;
                                                            break;
                                                    else
                                                            Judge_theta_obs1(i_quan_num)=0;
                                                    end     
                                                else
                                
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                            while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end
                                                            [obs_theta1]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                            obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                            obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                            [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta1>0
                                                                        for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                            pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                        end
                                                                            pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                        if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                            theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                        end

                                                            end                      
                                                            Judge_theta_obs1(i_quan_num)=1;
                                                            break;
                                                    else
                                                            Judge_theta_obs1(i_quan_num)=0;
                                                    end     
                                                end 
                                            end     
                                        end

                                    else
                                       while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1(i_quan_num),:))
                                            theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju;
                                            %�����ж�
                                            if num_theta1(i_quan_num,1)~=0
                                                if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))>pi
                                                    if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal1ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                            while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end
                                                            [obs_theta1]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                            obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                            obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                            [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta1>0
                                                                        for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                            pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                        end
                                                                            pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                        if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                            theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                        end

                                                            end         
                                                            Judge_theta_obs1(i_quan_num)=1;
                                                            break;
                                                    else
                                                            Judge_theta_obs1(i_quan_num)=0;
                                                    end     
                                                else
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                            while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:))
                                                                        theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end
                                                            [obs_theta1]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                                                            obs_theta_x1=obs(obs_theta1,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                            obs_theta_y1=obs(obs_theta1,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); 
                                                            [i_obs_find_theta1,Way_find_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta1>0
                                                                        for i_find_centre=1:size(i_obs_find_theta1,1)
                                                                            pose_find_syn1(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta1(i_find_centre,1),2))^2);
                                                                        end
                                                                            pose_find_syn1(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x1)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y1)^2);
                                                                        if pose_find_syn1(i_quan_num,i_find_centre+1)>min(pose_find_syn1(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs1]=(find(pose_find_syn1(i_quan_num,1:i_find_centre)==min(pose_find_syn1(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal1(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_find_theta1(obs_judge_theta_obs1,1),:))
                                                                                            theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)+degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))= i_obs_find_theta1(obs_judge_theta_obs1,1);       
                                                                        end
                                                            end
                                                            Judge_theta_obs1(i_quan_num)=1;
                                                            break;
                                                    else
                                                            Judge_theta_obs1(i_quan_num)=0;
                                                    end     
                                                end
                                            end
                                        end 
                                    end

                                  [i_obs_cal_theta1,Way_change_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);            
                                  if (num_theta1(i_quan_num,1)==0)
                                       while Way_change_theta1>0
                                           if Way_change_theta1>=1
                                                for i_cal_centre=1:size(i_obs_cal_theta1,1)
                                                    pose_cal_syn1(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre),2))^2);
                                                end
                                                i_cal_obs1(i_quan_num)=i_obs_cal_theta1(find(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1))==min(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1)))),1);
                                                if  max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))-min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))>pi
                                                         if (min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))
                                                                while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                                end
                                                                 i_obs_judge_theta1(i_quan_num)=i_cal_obs1(i_quan_num); 
                                                                  Judge_theta_obs1(i_quan_num)=4;
                                                         end
                                                 else
                                                        if (min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))
                                                                while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                                end
                                                                 i_obs_judge_theta1(i_quan_num)=i_cal_obs1(i_quan_num);  
                                                                 Judge_theta_obs1(i_quan_num)=4;
                                                        end
                                                end     
                                           end
                                            [i_obs_cal_theta1,Way_change_theta1]=theta_judge_extra(obs,theta_obs,theta_goal1(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                         end

                                  end





                                    if (num_theta1(i_quan_num,1)~=0)&&(Judge_theta_obs1(i_quan_num)==0)
                                        % ֻ����һ���ϰ�����ж�
                                            if Way_change_theta1>0
                                                for i_cal_centre=1:size(i_obs_cal_theta1,1)
                                                    pose_cal_syn1(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta1(i_cal_centre,1),2))^2);
                                                end
                                                        pose_cal_syn1(i_quan_num,i_cal_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta1(i_quan_num),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta1(i_quan_num),2))^2);
                                                        i_obs_cal_theta1(i_cal_centre+1,1)=i_obs_judge_theta1(i_quan_num);
                                                        i_cal_obs1(i_quan_num)=i_obs_cal_theta1(find(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1))==min(pose_cal_syn1(i_quan_num,1:size(i_obs_cal_theta1,1)))),1);
                                                     if  max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))-min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))>pi
                                                         if (min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))

                                                             if Judge_theta_obs1(i_quan_num)==0
                                                                while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                                end
                                                                [theta_goal1(i_quan_num,i_quanju),Judge_theta_obs1(i_quan_num)] = Quanju_theta_closest_obs(theta_goal1(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta1_rec,num_theta1,degree_quanju,theta_a);                                                
                                                             end
                                                         end
                                                     else
                                                        if (min(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))<=theta_goal1(i_quan_num,i_quanju))&&(theta_goal1(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:)))
                                                            if Judge_theta_obs1(i_quan_num)==0
                                                                while (theta_goal1(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs1(i_quan_num),:))
                                                                    theta_goal1(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju)-degree_quanju/8;
                                                                end
                                                                  [theta_goal1(i_quan_num,i_quanju),Judge_theta_obs1(i_quan_num)] = Quanju_theta_closest_obs(theta_goal1(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta1_rec,num_theta1,degree_quanju,theta_a);                                              
                                                            end
                %
                                                        end
                                                     end

                                            end
                                    end
                                    num_theta1(i_quan_num,1)=num_theta1(i_quan_num,1)+1;
                                    if Judge_theta_obs1(i_quan_num)==1
                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)-1);
                                    elseif Judge_theta_obs1(i_quan_num)==2
                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_cal_obs1(i_quan_num);
                                    elseif Judge_theta_obs1(i_quan_num)==4
                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_obs_judge_theta1(i_quan_num);
                                    else
                                        i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_obs_judge_theta1(i_quan_num);
                                    end    

                                Way_change_theta1=0;

                            end


                    %Ϊ�ڶ���ѭ����׼�� ����һ��ѭ�����ƣ���֮ͬ���������ѭ����Ѱ�����ӽǶȺ����·��
                    %     Way_change=1;
                            while Way_change_theta2==1
                                theta_a=2;
                                        [i_obs_quanju_theta2,Way_change_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                        if Way_change_theta2>0
                                                    for i_cal_centre=1:size(i_obs_quanju_theta2,1)
                                                        pose_cal_theta2(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta2(i_cal_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_quanju_theta2(i_cal_centre,1),2))^2);

                                                    end
                                            i_cal_ob(i_quan_num)=i_obs_quanju_theta2(find(pose_cal_theta2(i_quan_num,1:size(i_obs_quanju_theta2,1))==min(pose_cal_theta2(i_quan_num,1:size(i_obs_quanju_theta2,1)))),1);
                                            i_obs_judge_theta2(i_quan_num)=i_cal_ob(i_quan_num);
                                        end
                                    if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:)))
                                        while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:))
                                            theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju; 
                                            if num_theta2(i_quan_num,1)~=0
                                                if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))>pi
                                                    if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal2ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                            while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end
                                                            [obs_theta2]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                            obs_theta_x2=obs(obs_theta2(1,1),1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                            obs_theta_y2=obs(obs_theta2(1,1),2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                            [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta2>0
                                                                        for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                            pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                        end
                                                                            pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2)^2);
                                                                        if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                            theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                        end



                                                            end
                                                            Judge_theta_obs2(i_quan_num)=1;
                                                            break;

                                                    else
                                                            Judge_theta_obs2(i_quan_num)=0;
                                                    end     
                                                else
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                            while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end
                                                            [obs_theta2]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                            obs_theta_x2=obs(obs_theta2,1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                            obs_theta_y2=obs(obs_theta2,2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                            [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta2>0
                                                                        for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                            pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                        end
                                                                            pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2(1,1))^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2(1,1))^2);
                                                                        if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                            theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                        end



                                                            end

                                                            Judge_theta_obs2(i_quan_num)=1;
                                                            break;

                                                    else  
                                                        Judge_theta_obs2(i_quan_num)=0;
                                                    end     
                                                end 
                                            end
                                        end

                                    else

                                        while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2(i_quan_num),:))


                                            theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju;   
                                            %�����ж�
                                            if num_theta2(i_quan_num,1)~=0
                                                if  max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))-min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))>pi
                                                    if (min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %�жϵ�ǰ�ı���theta_goal2ֵ�Ƿ�Ӱ��ղŴ������ϰ���

                                                            while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end
                                                            [obs_theta2]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                            obs_theta_x2=obs(obs_theta2,1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                            obs_theta_y2=obs(obs_theta2,2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                            [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta2>0
                                                                        for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                            pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                        end
                                                                            pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2)^2);
                                                                        if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs_dup(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                            theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                        end

                                                            end
                                                            Judge_theta_obs2(i_quan_num)=1;
                                                            break;

                                                    else
                                                            Judge_theta_obs2(i_quan_num)=0;
                                                    end     
                                                else
                                                    if (min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)))  %theta_goal ��ָ��ǰ�������Ŀ����λ��
                                                            while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:))
                                                                        theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                            end
                                                            % ��Judge_theta_obs2��������
                                                            [obs_theta2]=find(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                                                            obs_theta_x2=obs(obs_theta2,1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); % ��¼��ǰ�Ƕ���������
                                                            obs_theta_y2=obs(obs_theta2,2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))); 
                                                            [i_obs_find_theta2,Way_find_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                                            if Way_find_theta2>0
                                                                        for i_find_centre=1:size(i_obs_find_theta2,1)
                                                                            pose_find_syn2(i_quan_num,i_find_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_find_theta2(i_find_centre,1),2))^2);
                                                                        end
                                                                            pose_find_syn2(i_quan_num,i_find_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-obs_theta_x2)^2+(pose_quan_y(i_quan_num,i_quanju)-obs_theta_y2)^2);
                                                                        if pose_find_syn2(i_quan_num,i_find_centre+1)>min(pose_find_syn2(i_quan_num,1:i_find_centre))
                                                                            [obs_judge_theta_obs2]=(find(pose_find_syn2(i_quan_num,1:i_find_centre)==min(pose_find_syn2(i_quan_num,1:i_find_centre))));
                                                                                    while (theta_goal2(i_quan_num,i_quanju))>min(theta_obs(i_quan_num,i_quanju,i_obs_find_theta2(obs_judge_theta_obs2,1),:))
                                                                                            theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)-degree_quanju/4;% degree_quanju_sec Ϊÿ����ƫ�ƵĽǶȶ���������Ϊdegree_quanju��һ��

                                                                                    end
                                                                            i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))= i_obs_find_theta2(obs_judge_theta_obs2,1);       
                                                                        end



                                                            end
                                                            Judge_theta_obs2(i_quan_num)=1;
                                                            break;

                                                    else  
                                                        Judge_theta_obs2(i_quan_num)=0;
                                                    end    

                                                end
                                            end

                                        end

                                    end
                                    [i_obs_cal_theta2,Way_change_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);   
                                 



                                    if (num_theta2(i_quan_num,1)~=0)&&(Judge_theta_obs2(i_quan_num)==0)
                                            [i_obs_cal_theta2,Way_change_theta2]=theta_judge_extra(obs,theta_obs,theta_goal2(i_quan_num,i_quanju),i_quan_num,i_quanju,theta_obs_dup);
                                            if Way_change_theta2>=1
                                                for i_cal_centre=1:size(i_obs_cal_theta2,1)
                                                    pose_cal_syn2(i_quan_num,i_cal_centre)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta2(i_cal_centre),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_cal_theta2(i_cal_centre),2))^2);
                                                end
                                                        pose_cal_syn2(i_quan_num,i_cal_centre+1)=sqrt((pose_quan_x(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta2(i_quan_num),1))^2+(pose_quan_y(i_quan_num,i_quanju)-centre_obs(i_obs_judge_theta2(i_quan_num),2))^2);
                                                        i_obs_cal_theta2(i_cal_centre+1,1)=i_obs_judge_theta2(i_quan_num);
                                                        i_cal_obs2(i_quan_num)=i_obs_cal_theta2(find(pose_cal_syn2(i_quan_num,1:size(i_obs_cal_theta2,1))==min(pose_cal_syn2(i_quan_num,1:size(i_obs_cal_theta2,1)))),1);
                                                if  max(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))-min(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))>pi
                                                         if (min(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:)))

                                                                while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju/8;
                                                                end
                                                                 [theta_goal2(i_quan_num,i_quanju),Judge_theta_obs2(i_quan_num)] = Quanju_theta_closest_obs(theta_goal2(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta2_rec,num_theta2,degree_quanju,theta_a);                              
                                                         end
                                                 else
                                                        if (min(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))<=theta_goal2(i_quan_num,i_quanju))&&(theta_goal2(i_quan_num,i_quanju)<=max(theta_obs(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:)))

                                                                while (theta_goal2(i_quan_num,i_quanju))<max(theta_obs_dup(i_quan_num,i_quanju,i_cal_obs2(i_quan_num),:))
                                                                    theta_goal2(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju)+degree_quanju/8;
                                                                end
                                                                 [theta_goal2(i_quan_num,i_quanju),Judge_theta_obs2(i_quan_num)] = Quanju_theta_closest_obs(theta_goal2(i_quan_num,i_quanju),theta_obs,theta_obs_dup,i_quan_num,i_quanju,i_obs_judge_theta2_rec,num_theta2,degree_quanju,theta_a);                              
                                                        end
                                                end
                                                 i_obs_judge_theta2(i_quan_num)=i_cal_obs2(i_quan_num);
                                            end
                                    end
                                    num_theta2(i_quan_num,1)=num_theta2(i_quan_num,1)+1;
                                    if Judge_theta_obs2(i_quan_num)==1
                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1);
                                    elseif Judge_theta_obs2(i_quan_num)==2
                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_cal_obs2(i_quan_num);
                                    elseif Judge_theta_obs2(i_quan_num)==4
                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_obs_judge_theta2(i_quan_num);
                                    else
                                        i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_obs_judge_theta2(i_quan_num);
                                    end

                               Way_change_theta2=0; 
                            end
                end
        


                                % �˴���obsmin_colֻ����һ�����ֲ��Ǵ�����С
                if   Judge_theta_obs1(i_quan_num)==1
                    [obsmin_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                elseif Judge_theta_obs1(i_quan_num)==2
                    [obsmin_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                elseif Judge_theta_obs1(i_quan_num)==4
                    [obsmin_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                else
                    [obsmin_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),:)));
                end
                
                if   Judge_theta_obs2(i_quan_num)==1
                    [obsmax_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                elseif  Judge_theta_obs2(i_quan_num)==2
                    [obsmax_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                elseif Judge_theta_obs2(i_quan_num)==4
                     [obsmax_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==min(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                else
                    [obsmax_col]=find(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)==max(theta_obs_dup(i_quan_num,i_quanju,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),:)));
                end
        %% ����ֱ�ó�����Ŀ����x��y����
                
                obs_x1=obs(obsmin_col,1,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); %��¼��Сֵ������xֵ
                obs_y1=obs(obsmin_col,2,i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))); % ��¼��Сֵ������yֵ
                theta_obs_d1=atan((obs_y1(1,1)-pose_quan_y(i_quan_num,i_quanju))/(obs_x1(1,1)-pose_quan_x(i_quan_num,i_quanju)));
                obs_ob_d1(i_quan_num,i_quanju)= sqrt((obs_x1(1,1)-pose_quan_x(i_quan_num,i_quanju))^2+(obs_y1(1,1)-pose_quan_y(i_quan_num,i_quanju))^2); % obs_x1,obs_y1ָ�����ϰ����λ��
                % ����֤����û�����⣬����Ƕ�Ҳû����
                obs_ob_d_long1(i_quan_num,i_quanju)=obs_ob_d1(i_quan_num,i_quanju)*cos(theta_obs_d1-theta_goal(i_quan_num,i_quanju));% obs_ob_d_long ��ʾ�������г��ߣ���λ�á�(theta_obs_d1-theta_goal)��ʾ
                obs_ob_d_f1(i_quan_num,i_quanju)=abs(obs_ob_d_long1(i_quan_num,i_quanju)/(cos(theta_goal1(i_quan_num,i_quanju)-theta_goal(i_quan_num,i_quanju)))); % obs_ob_d_f ��ʾ��ߣ���������Ҫ��ĵ�%���ʹ��abs����ֵ ��Ϊ��ʹ���м����������ʱ�����ж����λ����
                % ȷ����Ŀ����λ����Ҫ���������

                    x_wp1(i_quan_num,i_quanju)=pose_quan_x(i_quan_num,i_quanju)+obs_ob_d_f1(i_quan_num,i_quanju)*cos(theta_goal1(i_quan_num,i_quanju));
                    y_wp1(i_quan_num,i_quanju)=pose_quan_y(i_quan_num,i_quanju)+obs_ob_d_f1(i_quan_num,i_quanju)*sin(theta_goal1(i_quan_num,i_quanju));






                obs_x2=obs(obsmax_col,1,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)));
                obs_y2=obs(obsmax_col,2,i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)));  

                theta_obs_d2=atan((obs_y2(1,1)-pose_quan_y(i_quan_num,i_quanju))/(obs_x2(1,1)-pose_quan_x(i_quan_num,i_quanju)));
                obs_ob_d2(i_quan_num,i_quanju)= sqrt((obs_x2(1,1)-pose_quan_x(i_quan_num,i_quanju))^2+(obs_y2(1,1)-pose_quan_y(i_quan_num,i_quanju))^2);
                obs_ob_d_long2(i_quan_num,i_quanju)=obs_ob_d2(i_quan_num,i_quanju)*cos(theta_obs_d2-theta_goal(i_quan_num,i_quanju));
                obs_ob_d_f2(i_quan_num,i_quanju)=abs(obs_ob_d_long2(i_quan_num,i_quanju)/(cos(theta_goal2(i_quan_num,i_quanju)-theta_goal(i_quan_num,i_quanju))));  %���ʹ��abs����ֵ ��Ϊ��ʹ���м����������ʱ�����ж����λ����

                obs_ob_d_f2_record(i_quan_num,i_quanju)=obs_ob_d_f2(i_quan_num,i_quanju);

                     x_wp2(i_quan_num,i_quanju)=pose_quan_x(i_quan_num,i_quanju)+obs_ob_d_f2(i_quan_num,i_quanju)*cos(theta_goal2(i_quan_num,i_quanju));
                     y_wp2(i_quan_num,i_quanju)=pose_quan_y(i_quan_num,i_quanju)+obs_ob_d_f2(i_quan_num,i_quanju)*sin(theta_goal2(i_quan_num,i_quanju));

    % ���߻�ͷ·���жϣ�ʹ��ȫ��·����ѡ��ֻ�������յ�ǰ��
                % ���������⣬��ǰ�ж��� ���Բ���
                % obs 4��  x����������������ĵ�Ĵ���y���������������ĵ�Ĵ���x����������С������ĵ�Ĵ���y����������С����ĵ�Ĵ���
                theta_obs_judge_num1(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                theta_obs_judge_num_xuhao1(i_quan_num,i_quanju)=obsmin_col(1,1);

                theta_obs_judge_num2(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                theta_obs_judge_num_xuhao2(i_quan_num,i_quanju)=obsmax_col(1,1);
                % ���ڻ�ͷ·���жϣ���ͷ·����ָ�滮��ȫ��·�������С�ǰһ�ι滮��·���뱾�ι滮��·�����򼸺���ȫ���򣬲��ص�����һ�ο�ʼ�жϵ���㡣
                if size(theta_goal1,2)>2
    % 
%                     for i_theta_dup=1:1
                      for i_theta_dup=1:(size(theta_goal1,2)-2)
                            if theta_obs_judge_num1(i_quan_num,i_quanju)==theta_obs_judge_mirror(i_quan_num,i_theta_dup+1)
                                % �ĳɱ��ε�ѡ��ĽǶ�����һ���ߵĽǶȵĺͣ��������pi������˵�����߻�ͷ·����Ҫ����ѡ����һ��·��
                                if (0.9*pi<=abs(theta_fir_final(i_quan_num,i_quanju-1)-theta_goal1(i_quan_num,i_quanju)))&&(abs(theta_fir_final(i_quan_num,i_quanju-1)-theta_goal1(i_quan_num,i_quanju))<1.1*pi)


                                    theta1(i_quan_num,i_quanju)=1;
                                    break;
                                end
                            end

                             if theta_obs_judge_num2(i_quan_num,i_quanju)==theta_obs_judge_mirror(i_quan_num,i_theta_dup+1)
                                if (0.9*pi<=abs(theta_fir_final(i_quan_num,i_quanju-1)-theta_goal2(i_quan_num,i_quanju)))&&(abs(theta_fir_final(i_quan_num,i_quanju-1)-theta_goal2(i_quan_num,i_quanju))<1.1*pi)
                                    theta2(i_quan_num,i_quanju)=1;
                                    break;
                                end
                             end
                      end




                end

        %% ѡ��·����Ĳ��ԣ����ѡ��·���㣨��һ��ʱΪ���ѡ��
           
                %ֻ�����ڴ�����������Ŀ��������������������Ҫ����������������Ҫ����ض����龰���и����ж������������ֵ�ʱ��������֡��ô��жϸ���
                %˵��ѭ���Ѿ���ʼ���й�һ�Ρ���ʱΪ1�Ǳ�ʾ�ظ����ϰ����Ҫǿ�Ƹ���·������һ���ϣ�ǿ��·����Ҫע���յ��λ��,��ǰ���õ�ֵΪ�յ���10��11�ڲ���


                if  mod(i_quan_num,2)==0
                    
                    if (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==4&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==3))||...  % �ô��������ϰ���4��x��С��ʱ��
                        (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==10&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4))||...  % �ϰ���10��y��С��ʱ��                                                                 
                        (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==13&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==3))||...%�ô��������ϰ���13��x��С��ʱ�����е��ж���ֻ����ѡ��theta_goal1��·��
                        (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==14&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==1))||...
                        (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==22&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4)) 
                            wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                            wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                            theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                            theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1);
                            theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                            Judge_distance(i_quan_num,1)=2;


                    elseif  (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==1&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4))||...  %�ô��������ϰ���1��y��С��ʱ��
                            (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==2&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==2))||... %�ô��������ϰ���2��y����ʱ
                            (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==3&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4))||... %�ô��������ϰ���3��y��С��ʱ
                            (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==4&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==1))||... %�ô��������ϰ���4��x����ʱ
                            (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==12&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==1))||...%�ô��������ϰ���12��x����ʱ�����е��ж���ֻ����������                
                            (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==16&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==1)) %�ô��������ϰ���3��x����ʱ�����е��ж���ֻ����ѡ��theta_goal1��·��



                             wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                             wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                             theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                             theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);  
                             theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                             Judge_distance(i_quan_num,1)=1;   
                             
                    elseif theta1(i_quan_num,i_quanju)==1
                            wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                            wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                            theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                            theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1);
                            theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                            Judge_distance(i_quan_num,1)=2;

                    elseif theta2(i_quan_num,i_quanju)==1
                             wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                             wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                             theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                             theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);  
                             theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                             Judge_distance(i_quan_num,1)=1;

                    else
                    
                    
                    % ���ȡ ǰ������֮��Ϊ��ʹ·�������Ż�����Ҫ�����ֽǶ�ѡ���·������������
                    % ����theta1��theta2����һ���Ƕȱ����ľ���ֵ���Լ�pose_quan_x\y����һ���ľ������ֵ���ֱ��������ռ����֮�͵���Ա���Ȼ����ӣ�ѡ��ֵ��С��

                            if (size(pose_quan_x(i_quan_num,:),2)>=7)&&(isfinite(theta_fir_final(i_quan_num,i_quanju-1)))
                                theta_abs1(i_quan_num)=abs(theta_goal1(i_quan_num,i_quanju)-theta_fir_final(i_quan_num,i_quanju-1));
                                theta_abs2(i_quan_num)=abs(theta_goal2(i_quan_num,i_quanju)-theta_fir_final(i_quan_num,i_quanju-1));
                                dis_theta_abs1(i_quan_num)=sqrt((x_wp1(i_quan_num,i_quanju)-pose_quan_x(i_quan_num,i_quanju))^2+(y_wp1(i_quan_num,i_quanju)-pose_quan_y(i_quan_num,i_quanju))^2);
                                dis_theta_abs2(i_quan_num)=sqrt((x_wp2(i_quan_num,i_quanju)-pose_quan_x(i_quan_num,i_quanju))^2+(y_wp2(i_quan_num,i_quanju)-pose_quan_y(i_quan_num,i_quanju))^2);
                                factor_theta1(i_quan_num)=theta_abs1(i_quan_num)/(theta_abs1(i_quan_num)+theta_abs2(i_quan_num))+dis_theta_abs1(i_quan_num)/( dis_theta_abs1(i_quan_num)+dis_theta_abs2(i_quan_num));
                                factor_theta2(i_quan_num)=theta_abs2(i_quan_num)/(theta_abs1(i_quan_num)+theta_abs2(i_quan_num))+dis_theta_abs2(i_quan_num)/( dis_theta_abs1(i_quan_num)+dis_theta_abs2(i_quan_num));
                                    if factor_theta1(i_quan_num)<=factor_theta2(i_quan_num)
                                         wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                                         wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                                         theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                                         theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);

                                         theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                                         Judge_distance(i_quan_num,1)=1;
                                    else
                                        wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                                        wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                                        theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                                        theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1); 

                                        theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                                        Judge_distance(i_quan_num,1)=2;
                                    end
                            else

                             a_ship=rand;
                            % ת�������ϰ����,��Ҫ��ʼ��������\����ת�Ǻ���һ����ȵľ���ֵ��(�Լ�����),ͬ�������,����ֵ����
                                    if a_ship>0.5
                                         wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                                         wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                                         theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                                         theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);
                                         theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                                         Judge_distance(i_quan_num,1)=1;
                                    else
                                        wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                                        wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                                        theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                                        theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1); 
                                        theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                                        Judge_distance(i_quan_num,1)=2;
                                    end
                            end
                    end
                   
                else
                    
                    % ������˴����Ϊ�����Ĳ���
                     if  (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==1&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4))||... %�ô��������ϰ���2��y����ʱ 
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==3&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4))||...  % �ô��������ϰ���3��y��С��ʱ��    
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==4&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==3))||...  % �ô��������ϰ���4��x��С��ʱ��
                         (i_quanju>=3&& (i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)-1)==4&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==1))||... %�ô��������ϰ���4��x����ʱ  
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==10&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4))||...  % �ϰ���10��y��С��ʱ��                                                                 
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==13&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==3))||...%�ô��������ϰ���13��x��С��ʱ�����е��ж���ֻ����ѡ��theta_goal1��·�� 
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==14&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==1))||...    
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==12&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==1))||... %�ô��������ϰ���12��x����ʱ
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==18&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==3))||...       %���������ϰ���18��x��С��ʱ
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==22&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==2))||...  %���������ϰ���22��y����ʱ
                         (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==22&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==3))        %���������ϰ���22��x��С��ʱ
                            wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                            wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                            theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                            theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1);
                            theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                            Judge_distance(i_quan_num,1)=2;

% 
                    elseif  (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==2&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==2))||... %�ô��������ϰ���21��y����ʱ�����е��ж���ֻ����ѡ��theta_goal1��·��
                            (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==21&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==2))||...  % ���������ϰ���2 ��y����ʱ
                            (i_quanju>=3&& (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)-1)==22&&theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju-1)==4)) 
                             wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                             wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                             theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                             theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);  
                             theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                             Judge_distance(i_quan_num,1)=1;     
                             
                    elseif theta1(i_quan_num,i_quanju)==1
                            wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                            wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                            theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                            theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1);
                            theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                            Judge_distance(i_quan_num,1)=2;

                    elseif theta2(i_quan_num,i_quanju)==1
                             wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                             wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                             theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                             theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);  
                             theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                             Judge_distance(i_quan_num,1)=1;

                    else

                    % ���ȡ ǰ������֮��Ϊ��ʹ·�������Ż�����Ҫ�����ֽǶ�ѡ���·������������
                    % ����theta1��theta2����һ���Ƕȱ����ľ���ֵ���Լ�pose_quan_x\y����һ���ľ������ֵ���ֱ��������ռ����֮�͵���Ա���Ȼ����ӣ�ѡ��ֵ��С��

                            if (size(pose_quan_x(i_quan_num,:),2)>=7)&&(isfinite(theta_fir_final(i_quan_num,i_quanju-1)))
                                theta_abs1(i_quan_num)=abs(theta_goal1(i_quan_num,i_quanju)-theta_fir_final(i_quan_num,i_quanju-1));
                                theta_abs2(i_quan_num)=abs(theta_goal2(i_quan_num,i_quanju)-theta_fir_final(i_quan_num,i_quanju-1));
                                dis_theta_abs1(i_quan_num)=sqrt((x_wp1(i_quan_num,i_quanju)-pose_quan_x(i_quan_num,i_quanju))^2+(y_wp1(i_quan_num,i_quanju)-pose_quan_y(i_quan_num,i_quanju))^2);
                                dis_theta_abs2(i_quan_num)=sqrt((x_wp2(i_quan_num,i_quanju)-pose_quan_x(i_quan_num,i_quanju))^2+(y_wp2(i_quan_num,i_quanju)-pose_quan_y(i_quan_num,i_quanju))^2);
                                factor_theta1(i_quan_num)=theta_abs1(i_quan_num)/(theta_abs1(i_quan_num)+theta_abs2(i_quan_num))+dis_theta_abs1(i_quan_num)/( dis_theta_abs1(i_quan_num)+dis_theta_abs2(i_quan_num));
                                factor_theta2(i_quan_num)=theta_abs2(i_quan_num)/(theta_abs1(i_quan_num)+theta_abs2(i_quan_num))+dis_theta_abs2(i_quan_num)/( dis_theta_abs1(i_quan_num)+dis_theta_abs2(i_quan_num));
                                    if factor_theta1(i_quan_num)<=factor_theta2(i_quan_num)
                                         wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                                         wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                                         theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                                         theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);

                                         theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                                         Judge_distance(i_quan_num,1)=1;
                                    else
                                        wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                                        wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                                        theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                                        theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1); 

                                        theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                                        Judge_distance(i_quan_num,1)=2;
                                    end
                            else

                                a_ship=rand;
                            % ����ҲҪ�Ľ�,ת�������ϰ����,��Ҫ��ʼ��������\����ת�Ǻ���һ����ȵľ���ֵ��(�Լ�����),ͬ�������,����ֵ����
                                    if a_ship>0.5
                                         wp_x(i_quan_num,i_quanju)=x_wp1(i_quan_num,i_quanju);
                                         wp_y(i_quan_num,i_quanju)=y_wp1(i_quan_num,i_quanju);
                                         theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                                         theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmin_col(1,1);
                                         theta_fir_final(i_quan_num,i_quanju)=theta_goal1(i_quan_num,i_quanju);
                                         Judge_distance(i_quan_num,1)=1;
                                    else
                                        wp_x(i_quan_num,i_quanju)=x_wp2(i_quan_num,i_quanju);
                                        wp_y(i_quan_num,i_quanju)=y_wp2(i_quan_num,i_quanju);
                                        theta_obs_judge_mirror(i_quan_num,i_quanju)=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                                        theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=obsmax_col(1,1); 
                                        theta_fir_final(i_quan_num,i_quanju)=theta_goal2(i_quan_num,i_quanju);
                                        Judge_distance(i_quan_num,1)=2;
                                    end
                            end
                    end
                

                end


            else
            %˵����λ���յ������û���ϰ������ԭ�е�·�������н�
                    wp_x(i_quan_num,i_quanju)=goal_quanju(i_quan_num,1,i_goal_quanju);
                    wp_y(i_quan_num,i_quanju)=goal_quanju(i_quan_num,2,i_goal_quanju);
                    theta_fir_final(i_quan_num,i_quanju)=theta_goal(i_quan_num,i_quanju);
                    theta_obs_judge_mirror(i_quan_num,i_quanju)=0;
                    theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)=0; 
                    Judge_distance(i_quan_num,1)=0;
            end     
            % ��Ϊ�������ϰ���ķָ�����ֵ
            % ���ú�centre_obs,��wp_x��λ�ò��Ҫע����Ƕ����յ� ��Ҫ���������ж�����
            % �������ƫ���������Ҳ��������ϰ�����ص㣬������Ӧ������ƫ���������ƫ����
            if  Judge_distance(i_quan_num,1)==1
                
                i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))=i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1));
                
                if wp_x(i_quan_num,i_quanju)<centre_obs(i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),1)
                     pose_quan_x(i_quan_num,i_quanju+1)=wp_x(i_quan_num,i_quanju)-distan_pianyi; 
                else
                     pose_quan_x(i_quan_num,i_quanju+1)=wp_x(i_quan_num,i_quanju)+distan_pianyi;
                end

                if wp_y(i_quan_num,i_quanju)<centre_obs(i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1)),2)
                     pose_quan_y(i_quan_num,i_quanju+1)=wp_y(i_quan_num,i_quanju)-distan_pianyi; 
                else
                     pose_quan_y(i_quan_num,i_quanju+1)=wp_y(i_quan_num,i_quanju)+distan_pianyi;
                end

                


            elseif Judge_distance(i_quan_num,1)==2
                
              i_obs_judge_theta1_rec(i_quan_num,num_theta1(i_quan_num,1))=i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1));
                if wp_x(i_quan_num,i_quanju)<centre_obs(i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),1)

                    if i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))==3 % ʹ���ϰ����x������ƫ��x���
                        pose_quan_x(i_quan_num,i_quanju+1)=wp_x(i_quan_num,i_quanju)-distan_pianyi; 
                    end


                     pose_quan_x(i_quan_num,i_quanju+1)=wp_x(i_quan_num,i_quanju)-distan_pianyi; 
                    if (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))==4)&&(theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)==3)
                        pose_quan_x(i_quan_num,i_quanju+1)=wp_x(i_quan_num,i_quanju);
                    end
                else
                     pose_quan_x(i_quan_num,i_quanju+1)=wp_x(i_quan_num,i_quanju)+distan_pianyi;
                end

                if wp_y(i_quan_num,i_quanju)<centre_obs(i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1)),2)
                     pose_quan_y(i_quan_num,i_quanju+1)=wp_y(i_quan_num,i_quanju)-distan_pianyi; 
                else 
                    if i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))==3
                        pose_quan_y(i_quan_num,i_quanju+1)=wp_y(i_quan_num,i_quanju)+distan_pianyi;
                    end
                     pose_quan_y(i_quan_num,i_quanju+1)=wp_y(i_quan_num,i_quanju)+distan_pianyi;
                    if (i_obs_judge_theta2_rec(i_quan_num,num_theta2(i_quan_num,1))==4)&&(theta_obs_judge_num_xuhao_mirror(i_quan_num,i_quanju)==3)
                        pose_quan_y(i_quan_num,i_quanju+1)=wp_y(i_quan_num,i_quanju);
                    end
                end
                



            else
                 pose_quan_x(i_quan_num,i_quanju+1)=wp_x(i_quan_num,i_quanju); 
                 pose_quan_y(i_quan_num,i_quanju+1)=wp_y(i_quan_num,i_quanju); 

            end



        end

        Is_quanju=1;
        for i_quanju_judge=1:N
            if (abs(pose_quan_x(i_quanju_judge,i_quanju+1) - goal_quanju(i_quanju_judge,1,i_goal_quanju)) < 10*l)&&(abs(pose_quan_y(i_quanju_judge,i_quanju+1) - goal_quanju(i_quanju_judge,2,i_goal_quanju))< 10*l)
                disp(['USV',num2str(i_quanju_judge),'�Ѽƻ����յ�',num2str(i_goal_quanju)]);
            else
                Is_quanju=0;
            end

        end

        if Is_quanju==1
            if i_goal_quanju==size(goal_quanju,3)
                
            
                        disp(['FAN�Ѽƻ����յ�',num2str(i_goal_quanju)]);
                break;  
            else
               
                disp(['FAN�Ѽƻ�����һ���յ�',num2str(i_goal_quanju)]);
                 i_goal_quanju=i_goal_quanju+1;
            end
            
        end


    end
i_opt_jubu_obs=i_obs_judge_theta2_rec;
% ����ԭʼ·��δ���Ż����ĳ���

%% ȫ�ֱ������������ӡ��������Ż�

% ·������
route_set=zeros(N,1);
    %С���ܣ���¼ÿ��·���ļ���ʵ�ʳ���
for i_route_usv=1:size(pose_quan_x,1)
        for i_route=1:(size(pose_quan_x,2)-1)
            route_set(i_route_usv)=route_set(i_route_usv)+sqrt((pose_quan_x(i_route_usv,i_route+1)-pose_quan_x(i_route_usv,i_route))^2+(pose_quan_y(i_route_usv,i_route+1)-pose_quan_y(i_route_usv,i_route))^2);
        end
end

route_set_sec=route_set;
% ת��ǽǶȲ����ֵ
theta_set_sec=theta_fir_final(:,1);
for i_theta_set_usv=1:size(theta_fir_final,1)
        for i_theta_set=1:(size(theta_fir_final,2)-1)
            % ��Ҫ��֤ ת�ǲ�Ӧ�ô���pi���������˴���ת������
            if  isnan(theta_fir_final(i_theta_set_usv,i_theta_set+1))
                continue;
            else
                
            
                if abs(theta_fir_final(i_theta_set_usv,i_theta_set+1)-theta_fir_final(i_theta_set_usv,i_theta_set))>pi
                     theta_set_sec(i_theta_set_usv)=theta_set_sec(i_theta_set_usv)+(2*pi-abs((theta_fir_final(i_theta_set_usv,i_theta_set+1)-theta_fir_final(i_theta_set_usv,i_theta_set))));
                else
                     theta_set_sec(i_theta_set_usv)=theta_set_sec(i_theta_set_usv)+abs((theta_fir_final(i_theta_set_usv,i_theta_set+1)-theta_fir_final(i_theta_set_usv,i_theta_set)));
                end
            
             end  
        end
end

% ת��Ƶ��
theta_trans_sec=zeros(N,1);


for i_theta_trans_usv=1:size(theta_fir_final,1)
        for i_theta_trans=1:(size(theta_fir_final,2)-1)
            % ��Ҫ��֤ ת�ǲ�Ӧ�ô���pi���������˴���ת������
            if  isnan(theta_fir_final(i_theta_trans_usv,i_theta_trans))
                
                continue;
            else
                theta_trans_sec(i_theta_trans_usv)=theta_trans_sec(i_theta_trans_usv)+1;
            
            end
            
        end  
end


% �˹�����Ȩ�ؽ��м��㣬�˹�����Ȩ��ֵ���� ƫ����·������ ����ת��ǽǶ� ���� ת�����
% Ҳ����ͨ�����ʺ������Զ���ȷ��Ȩ��
route_factor=0.4;
theta_set_factor=0.3;
theta_trans_factor=0.3;

[b_route_set_sec,i_route_set_sec]=sort(route_set_sec);
[b_route_set_sec_next,i_route_set_sec_next]=sort(i_route_set_sec);
[b_theta_set_sec,i_theta_set_sec]=sort(theta_set_sec);
[b_theta_set_sec_next,i_theta_set_sec_next]=sort(i_theta_set_sec);
[b_theta_trans_sec,i_theta_trans_sec]=sort(theta_trans_sec);
[b_theta_trans_sec_next,i_theta_trans_sec_next]=sort(i_theta_trans_sec);
% ���ƵĴ���
i_theta_trans_sec_next_dup=i_theta_trans_sec_next;

% �޸���һ��������ת�����һ�µ���ֵ��һ��������

for i_theta_trans_re =1:(size(i_theta_trans_sec_next,1)-1)
%     if  i_theta_trans_sec_next(i_theta_trans_re)==1
%         Value_a=i_theta_trans_sec_next(i_theta_trans_re);
        
        if theta_trans_sec(i_theta_trans_sec(i_theta_trans_re))==theta_trans_sec(i_theta_trans_sec(i_theta_trans_re+1))
                i_theta_trans_sec_next_dup(i_theta_trans_sec(i_theta_trans_re+1))=i_theta_trans_sec_next_dup(i_theta_trans_sec(i_theta_trans_re));

        end
%     end
    
    
end

% ����˲�ͬ���ȼ������·�����ȶȺ󣬼ǵ��ȸ��쵼��·��һ�����Ž�

for i_route_opt=1:N
    Opt(i_route_opt)=i_route_set_sec_next(i_route_opt)*route_factor+i_theta_set_sec_next(i_route_opt)*theta_set_factor+i_theta_trans_sec_next_dup(i_route_opt)*theta_trans_factor;
    
end


% ����Opt ���� ���ȼ�������ֵ��ֵ��Ϊ���ʣ�Ȼ�����·����ƫ����ѡ��


[b_route_fina,i_route_fina]=sort(Opt);
[b_route_fina_next,i_route_fina_next]=sort(i_route_fina);

% i_route_fina_next ��ʾ��·�����ۺ��ѡ�����ȼ���� Ҳ����ȫ��·���ۺ���������
route_fir_dup_x=pose_quan_x;
route_fir_dup_y=pose_quan_y;


% �˴���pose_quan_fina_x _y Ϊ���¹滮·����Ķ���·��

% �˴�Ϊ���쵼��֮��Ĵ�����ƣ��쵼�ߵ�·��ѡ�����ȼ���ߵ�·����������������ö���·��ѡ��
pose_quan_fina_x(N,:)=route_fir_dup_x(i_route_fina(1),:);
pose_quan_fina_y(N,:)=route_fir_dup_y(i_route_fina(1),:);
pose_quan_fina_jubu(N)=i_route_fina(1);
% ��ԭ�ȵ��쵼�ߵ�ȫ��·���еķַ�Ŀ��������

disp('MASS�쵼���������Ż����ȫ��·��');
for i_fina_route=1:(N-1)
    if i_fina_route==1      %Э����ǰ����
        judge_1=0;
    end
    
    route_random=rand+judge_1;
    judge_1=0;

    
    
% ѡ��·������ ��ͨ������i_route_fina����Ž���·�ߵ�ѡ��
    
        if route_random>=0.9
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(1),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(1),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(1);
            judge_1=-0.4;
        elseif (route_random>=0.8&& route_random<0.9)
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(2),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(2),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(2);
            judge_1=-0.3;
        elseif (route_random>=0.7&& route_random<0.8)
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(3),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(3),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(3);
            judge_1=-0.2;
        elseif (route_random>=0.6&& route_random<0.7)
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(4),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(4),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(4);
            judge_1=-0.1;
        elseif (route_random>=0.5&& route_random<0.6) 
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(5),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(5),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(5);
            judge_1=0;
        elseif (route_random>=0.4&& route_random<0.5)
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(6),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(6),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(6);
            judge_1=0.1;            
        elseif (route_random>=0.3&& route_random<0.4)     
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(7),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(7),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(7);
            judge_1=0.2;
        elseif (route_random>=0.2&& route_random<0.3)
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(8),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(8),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(8);
            judge_1=0.3;            
        elseif (route_random>=0.1&& route_random<0.2)
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(9),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(9),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(9);
            judge_1=0.4; 
        elseif (route_random>=0 && route_random<0.1)  
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(10),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(10),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(10);
            judge_1=0.45; 
        else
            pose_quan_fina_x(i_fina_route,:)=route_fir_dup_x(i_route_fina(11),:);
            pose_quan_fina_y(i_fina_route,:)=route_fir_dup_y(i_route_fina(11),:);
            pose_quan_fina_jubu(i_fina_route)=i_route_fina(11);
            judge_1=0.50;
        end
        disp(['MASS',num2str(i_fina_route),'�������Ż���ȫ��·��']);

end
for i_re_quanju_obs=1:N
    i_opt_quanju_fina(i_re_quanju_obs,:)=i_opt_jubu_obs(pose_quan_fina_jubu(i_re_quanju_obs),:);
    obs_axis_fina(i_re_quanju_obs,:)=theta_obs_judge_num_xuhao_mirror(pose_quan_fina_jubu(i_re_quanju_obs),:);
end
i_opt_quanju_fina(1:N,size(i_opt_quanju_fina,2)+1)=0;
i_re_goal_change=length(find(i_opt_quanju_fina(N,:)));
% ��ԭ�����˴��ķ�Ŀ���Ϊ����ԭʼ��ֵ
for i_re_goal=1:N
   pose_quan_fina_x(i_re_goal,2)=goal_quanju(i_re_goal,1,1);
   pose_quan_fina_y(i_re_goal,2)=goal_quanju(i_re_goal,2,1);
   
   pose_quan_fina_x(i_re_goal,size(pose_quan_x,2))=goal_quanju(i_re_goal,1,2); 
   pose_quan_fina_y(i_re_goal,size(pose_quan_x,2))=goal_quanju(i_re_goal,2,2); 
end
% ������Ҫ��N��·�� �����յ����ֵ�ø���
pose_quan_fina_x(N,(3+i_re_goal_change):size(pose_quan_x,2))=goal_quanju(N,1,2); 
pose_quan_fina_y(N,(3+i_re_goal_change):size(pose_quan_x,2))=goal_quanju(N,2,2); 
% Ѱ�ź��·��ͳ��

route_set_opt=zeros(N,1);
route_add_speed=zeros(N,1);
    %С���ܣ���¼ÿ��·���ļ���ʵ�ʳ���
for i_route_usv_opt=1:size(pose_quan_fina_x,1)
    judge_addspeed=0;
        for i_route=1:(size(pose_quan_fina_x,2)-1)
            route_set_opt(i_route_usv_opt)=route_set_opt(i_route_usv_opt)+sqrt((pose_quan_fina_x(i_route_usv_opt,i_route+1)-pose_quan_fina_x(i_route_usv_opt,i_route))^2+(pose_quan_fina_y(i_route_usv_opt,i_route+1)-pose_quan_fina_y(i_route_usv_opt,i_route))^2);
            % ������ж��Ǽ���ÿ��·���ĵ����ڶ�����Ŀ��㵽����ȫ��·�����ȣ����������������˴��ٶ�
            if i_route<=(size(pose_quan_fina_x,2)-3)
                if (judge_addspeed==0)&&(pose_quan_fina_x(i_route_usv_opt,i_route+2)==pose_quan_fina_x(i_route_usv_opt,i_route+3))
                    route_add_speed(i_route_usv_opt)= route_set_opt(i_route_usv_opt);
                    judge_addspeed=1;
                end
            end
            
            
        end
end
% ����Opt����λ��
Opt_median(1:N,1)=[1:1:20];
Opt_median(1:N,2)=median(Opt);



%% ��ʼѭ���������Ŀ���Ϊ�쵼��,����û�������ϰ��������£�

F_record_fol_mass=[];

F_record_fol_mass_mirror=[];
F_record_fol_obs=[];
F_record_fol_obs_mirror=[];
F_record_fol_ts=[];
F_record_fol_ts_mirror=[];
% picture_save_dir1=('');
% ����������쵼�ߵ�׼������
pose_quan_fina_x_res=pose_quan_fina_x;
pose_quan_fina_y_res=pose_quan_fina_y;
pose_quan_fina_xx_res=pose_quan_fina_x;
pose_quan_fina_yy_res=pose_quan_fina_y;
[formation,decide_num]=decide_lead_fol(i_opt_quanju_fina,obs_axis_fina,vars,N);
% [formation,decide_num]=decide_lead_fol(N);
sub_lead=find(decide_num~=0);
% ѭ�������˵�һ�ε�����Ҫ�������Ŀ��㣬
for i_fol_num=1:size(find(decide_num~=0),2)
    fol_num_mass(i_fol_num)=size(find(formation(sub_lead(i_fol_num),:)~=0),2);
    if fol_num_mass(i_fol_num)~=0

        [pose_quan_fina_x_res,pose_quan_fina_y_res] = auto_formation0511(i_fol_num,[pose_x(sub_lead(i_fol_num),1) pose_y(sub_lead(i_fol_num),1)],fol_num_mass(i_fol_num),vars,formation,sub_lead,judge_tran_cond,N,pose_th(sub_lead(i_fol_num),1),tran_theta,dis_st_fol);

        for i_write=1:fol_num_mass(i_fol_num)
            pose_quan_fina_xx_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)))=pose_quan_fina_x_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)));
            pose_quan_fina_yy_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)))=pose_quan_fina_y_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)));
        end
    else
        
    end
end



%% ʵ��ѭ����ʼ��λ��
for j = 1:J
    tic;
    
    
    for i_leader=1:length(find(sub_lead~=0))
  %% �غϿ�ʼǰ ��ͳ���ϰ��������������
   % �˴����±���ϰ���Ա�����쵼�߶��ԣ��ϰ�����˾�̬�ϰ��ﻹ���������Ŵ���
   
            % ���Ŵ�����λ�û�ȡ������AIS�������þ������ϰ��ﲻͬ�Ŷ�
            for num_ts=1:N_ais_att

                obs_pose_ts(num_ts,1)=pose_att_x(num_ts,j);
                obs_pose_ts(num_ts,2)=pose_att_y(num_ts,j);
                obs_pose_ts_th(num_ts,1)=pose_att_th(num_ts,j);
            end
            %���Ŵ����⴬λ�Ļ�ȡ
%             for num_ts_vir=1:N_ais_att     
%                 obs_pose_ts(num_ts+num_ts_vir,1)=pose_att_x_vir(num_ts_vir,j);
%                 obs_pose_ts(num_ts+num_ts_vir,2)=pose_att_y_vir(num_ts_vir,j);
%                 obs_pose_ts_th(num_ts+num_ts_vir,1)=pose_att_th_vir(num_ts_vir,j);
%             end  
            [n_lead_ts_row,n_lead_ts_col]=size(obs_pose_ts); 
  %% ��Ϊ���캽�ߵ���������
        Theta_lead= compute_angle_NaN([pose_x(sub_lead(i_leader),j),pose_y(sub_lead(i_leader),j)],Obs_all,n,P_obs);
        distance_lead(sub_lead(i_leader),j)=sqrt((pose_quan_fina_x(sub_lead(i_leader),vars(sub_lead(i_leader)))-pose_x(sub_lead(i_leader),j))^2+(pose_quan_fina_y(sub_lead(i_leader),vars(sub_lead(i_leader)))-pose_y(sub_lead(i_leader),j))^2);   %�쵼�߾����յ�ľ���
        th_lead(sub_lead(i_leader),j)=atan2(pose_quan_fina_y(sub_lead(i_leader),vars(sub_lead(i_leader)))-pose_y(sub_lead(i_leader),j),pose_quan_fina_x(sub_lead(i_leader),vars(sub_lead(i_leader)))-pose_x(sub_lead(i_leader),j));    %atan2���������޷����еĻ���ֵ�������޷����� atan2(Y,X) ����ͼ������ʾ�� Y �� X ��ֵ���ر����� [-pi,pi] �е�ֵ��
        if th_lead(sub_lead(i_leader),j)<0
            th_lead(sub_lead(i_leader),j)=th_lead(sub_lead(i_leader),j)+2*pi;
        end
        if  distance_lead(sub_lead(i_leader),j)>d_max_lead
                 distance_lead(sub_lead(i_leader),j)=d_max_lead;         % ��������յ�ľ������2�����趨��Ŀ���Ϊ����Ϊ2����Ŀ���ǿ���������Ҫ����
        end  
    % ��һʱ�̵��ٶ��Ѿ������
        V_x(sub_lead(i_leader),j+1)=K_att*distance_lead(sub_lead(i_leader),j)*cos(th_lead(sub_lead(i_leader),j));             % ����ͧ����ٶȣ�KN��ʾϵ�����ֽ⵽x��y�����ϵ��ٶ�ֵ��
        V_y(sub_lead(i_leader),j+1)=K_att*distance_lead(sub_lead(i_leader),j)*sin(th_lead(sub_lead(i_leader),j));
    % �˴�Ϊ��¼һ�½���������ʱ�����쵼�ߵ��ٶ�      
        V_rec_att_lead_x(sub_lead(i_leader),j)=V_x(sub_lead(i_leader),j+1);
        V_rec_att_lead_y(sub_lead(i_leader),j)=V_y(sub_lead(i_leader),j+1);
     %% �캽�߱���    
        [Frerxx,Freryy]=Change_compute_repulsion_20220401([pose_x(sub_lead(i_leader),j),pose_y(sub_lead(i_leader),j)],Obs_all,m_rep,Theta_lead,n,P_obs,distance_lead(sub_lead(i_leader),j),c_obs);

        F_record_lead_mirror_x(sub_lead(i_leader),j)=Frerxx;
        F_record_lead_mirror_y(sub_lead(i_leader),j)=Freryy;
            if Frerxx>=90
                Frerxx=90+log10(Frerxx);
            elseif Frerxx<-90
                Frerxx=-90-log10(-Frerxx);
            end
            if Freryy>=90
                Freryy=90+log10(Freryy);
            elseif Freryy<-90
                Freryy=-90-log10(-Freryy);
            end    
        V_x(sub_lead(i_leader),j+1)=V_x(sub_lead(i_leader),j+1)+K_rep_obs*Frerxx;  
        V_y(sub_lead(i_leader),j+1)=V_y(sub_lead(i_leader),j+1)+K_rep_obs*Freryy;
        F_record_lead_x(sub_lead(i_leader),j)=Frerxx;
        F_record_lead_y(sub_lead(i_leader),j)=Freryy;
        %�˴�Ϊ��¼�����쵼�߱���֮����ٶȼӳ�
        V_rec_lead_obs_x(sub_lead(i_leader),j)=V_x(sub_lead(i_leader),j+1);
        V_rec_lead_obs_y(sub_lead(i_leader),j)=V_y(sub_lead(i_leader),j+1);
   %% ��Ŀ�괬����λ�ú�ʵ��λ��-�����˴��쵼�ߵĳ���
        %�˴��������Ŀ�괬������λ��

         % �˴��ĳ����Ǹ��Ŵ����⴬λ�������쵼�ߵ� 
            Theta_att_vir=compute_angle_NaN([pose_x(sub_lead(i_leader),j),pose_y(sub_lead(i_leader),j)],obs_pose_ts, n_lead_ts_row,P_ts);
           
            [Fattxx_lead_ts,Fattyy_lead_ts]=Change_compute_repulsion_20220601([pose_x(sub_lead(i_leader),j),pose_y(sub_lead(i_leader),j)],obs_pose_ts,m_rep,Theta_att_vir,n_lead_ts_row,P_ts,distance_lead(sub_lead(i_leader),j),c_ts,obs_pose_ts_th,pose_th(sub_lead(i_leader),j),V_os(sub_lead(i_leader),j),V_ts(:,j),pose_att_x(:,j),pose_att_y(:,j));             
            F_record_lead_ts_mirror_x(sub_lead(i_leader),j)=Fattxx_lead_ts;
            F_record_lead_ts_mirror_y(sub_lead(i_leader),j)=Fattyy_lead_ts;
            if Fattxx_lead_ts>=90
                    Fattxx_lead_ts=90+log10(Fattxx_lead_ts);
            elseif Fattxx_lead_ts<=-90
                    Fattxx_lead_ts=-90-log10(-Fattxx_lead_ts);
            end
            if Fattyy_lead_ts>=90
                    Fattyy_lead_ts=90+log10(Fattyy_lead_ts);
            elseif Fattyy_lead_ts<=-90
                    Fattyy_lead_ts=-90-log10(-Fattyy_lead_ts);
            end
       %���쵼�ߵĴ��ڽ��г���������
            F_record_lead_ts_x(sub_lead(i_leader),j)=Fattxx_lead_ts;
            F_record_lead_ts_y(sub_lead(i_leader),j)=Fattyy_lead_ts;
            V_x(sub_lead(i_leader),j+1)=V_x(sub_lead(i_leader),j+1)+K_rep_ts*Fattxx_lead_ts;  
            V_y(sub_lead(i_leader),j+1)=V_y(sub_lead(i_leader),j+1)+K_rep_ts*Fattyy_lead_ts;

            V_rec_lead_ts_x(sub_lead(i_leader),j)=V_x(sub_lead(i_leader),j+1);
            V_rec_lead_ts_y(sub_lead(i_leader),j)=V_y(sub_lead(i_leader),j+1);
       
       %% followers�ľֲ�·���滮�㷨   
            
            for i_fol_ca=1:fol_num_mass(i_leader)
                    distance_fol(formation(sub_lead(i_leader),i_fol_ca),j)=sqrt((pose_quan_fina_xx_res(formation(sub_lead(i_leader),i_fol_ca),vars(formation(sub_lead(i_leader),i_fol_ca)))-pose_x(formation(sub_lead(i_leader),i_fol_ca),j))^2+(pose_quan_fina_yy_res(formation(sub_lead(i_leader),i_fol_ca),vars(formation(sub_lead(i_leader),i_fol_ca)))-pose_y(formation(sub_lead(i_leader),i_fol_ca),j))^2);   %�쵼�߾����յ�ľ���
                    th_fol(formation(sub_lead(i_leader),i_fol_ca),j) =atan2(pose_quan_fina_yy_res(formation(sub_lead(i_leader),i_fol_ca),vars(formation(sub_lead(i_leader),i_fol_ca)))-pose_y(formation(sub_lead(i_leader),i_fol_ca),j),pose_quan_fina_xx_res(formation(sub_lead(i_leader),i_fol_ca),vars(formation(sub_lead(i_leader),i_fol_ca)))-pose_x(formation(sub_lead(i_leader),i_fol_ca),j));    %atan2���������޷����еĻ���ֵ�������޷����� atan2(Y,X) ����ͼ������ʾ�� Y �� X ��ֵ���ر����� [-pi,pi] �е�ֵ��     
                    if th_fol(formation(sub_lead(i_leader),i_fol_ca),j)<0
                           th_fol(formation(sub_lead(i_leader),i_fol_ca),j)=th_fol(formation(sub_lead(i_leader),i_fol_ca),j)+2*pi;
                    end
                    if distance_fol(formation(sub_lead(i_leader),i_fol_ca),j)>d_max_fol               %���Ƹ��洬������ֵ
                           distance_fol(formation(sub_lead(i_leader),i_fol_ca),j)=d_max_fol;  
                    end% ��������յ�ľ������d_max_fol �����趨��Ŀ���Ϊ����Ϊd_max_fol ��Ҳ��һ�������ƶ��Ĳ���
                    V_x(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_att*distance_fol(formation(sub_lead(i_leader),i_fol_ca),j)*cos(th_fol(formation(sub_lead(i_leader),i_fol_ca),j));            
                    V_y(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_att*distance_fol(formation(sub_lead(i_leader),i_fol_ca),j)*sin(th_fol(formation(sub_lead(i_leader),i_fol_ca),j));
                    
                    V_rec_att_fol_x(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_x(formation(sub_lead(i_leader),i_fol_ca),j+1);
                    V_rec_att_fol_y(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_y(formation(sub_lead(i_leader),i_fol_ca),j+1);
                % �˴����±���ϰ���Ա����ͧ���ԣ��ϰ�����˾�̬�ϰ��ﻹ�����������˴�����������û�мӸ��Ŵ�
                    other_usv=0;
                % ��¼�������˴�λ��
                    for num_usv=1:N
                        if num_usv~=formation(sub_lead(i_leader),i_fol_ca)
                            other_usv=other_usv+1;
                            fol_pose(other_usv,1)=pose_x(num_usv,j);
                            fol_pose(other_usv,2)=pose_y(num_usv,j);
                            obs_pose_mass(other_usv,1) = fol_pose(other_usv,1);
                            obs_pose_mass(other_usv,2) = fol_pose(other_usv,2);                
                        end
                    end            
                    % ���Ŵ�����λ�û�ȡ������AIS�������þ������ϰ��ﲻͬ�Ŷ�
                    for num_ts=1:N_ais_att
                        obs_pose_ts(num_ts,1)=pose_att_x(num_ts,j);
                        obs_pose_ts(num_ts,2)=pose_att_y(num_ts,j);
                        obs_pose_ts_th(num_ts,1)=pose_att_th(num_ts,j);
                    end
                    %���Ŵ����⴬λ�Ļ�ȡ
%                     for num_ts_vir=1:N_ais_att
%                         obs_pose_ts(num_ts+num_ts_vir,1)=pose_att_x_vir(num_ts_vir,j);
%                         obs_pose_ts(num_ts+num_ts_vir,2)=pose_att_y_vir(num_ts_vir,j);
%                         obs_pose_ts_th(num_ts+num_ts_vir,1)=pose_att_th_vir(num_ts_vir,j);
%                     end  
                    % �Բ�ͬ�����ϰ������ͳ������
                    [n_fol_obs_row,n_fol_obs_col]=size(Obs_all);    
                    [n_fol_mass_row,n_fol_mass_col]=size(obs_pose_mass); 
                    [n_fol_ts_row,n_fol_ts_col]=size(obs_pose_ts); 

                    % �����ļ���Ƕ�
                    Theta_fol_obs = compute_angle_NaN([pose_x(formation(sub_lead(i_leader),i_fol_ca),j),pose_y(formation(sub_lead(i_leader),i_fol_ca),j)], Obs_all, n_fol_obs_row,P_obs);
                    Theta_fol_mass = compute_angle_NaN([pose_x(formation(sub_lead(i_leader),i_fol_ca),j),pose_y(formation(sub_lead(i_leader),i_fol_ca),j)], obs_pose_mass, n_fol_mass_row,P_mass);
                    Theta_fol_ts = compute_angle_NaN([pose_x(formation(sub_lead(i_leader),i_fol_ca),j),pose_y(formation(sub_lead(i_leader),i_fol_ca),j)], obs_pose_ts, n_fol_ts_row,P_ts);
        %% �Ը��洬��Ҫ����̬�ϰ�����mass�ֿ����������Ӱ�죬���и��Ŵ�
                    %��̬�ϰ���ĳ���
                   [Frexfol_obs,Freyfol_obs]=Change_compute_repulsion_20220401([pose_x(formation(sub_lead(i_leader),i_fol_ca),j),pose_y(formation(sub_lead(i_leader),i_fol_ca),j)],Obs_all,m_rep,...
                     Theta_fol_obs,n_fol_obs_row,P_obs,distance_fol(formation(sub_lead(i_leader),i_fol_ca),j),c_obs);
                    F_record_fol_obs_mirror_x(formation(sub_lead(i_leader),i_fol_ca),j)=Frexfol_obs;
                    F_record_fol_obs_mirror_y(formation(sub_lead(i_leader),i_fol_ca),j)=Freyfol_obs;
                    % ���ﴦ������Ҳ�Ǽ򵥵ĸ���������
                        if Frexfol_obs>=90
                        Frexfol_obs=90+log10(Frexfol_obs);
                        elseif Frexfol_obs<-90
                        Frexfol_obs=-90-log10(-Frexfol_obs);
                        end
                        if Freyfol_obs>=90
                        Freyfol_obs=90+log10(Freyfol_obs);
                        elseif Freyfol_obs<-90
                        Freyfol_obs=-90-log10(-Freyfol_obs);
                        end 
                    F_record_fol_obs_x(formation(sub_lead(i_leader),i_fol_ca),j)=Frexfol_obs;
                    F_record_fol_obs_y(formation(sub_lead(i_leader),i_fol_ca),j)=Freyfol_obs;
                %   �˴�beta�� ���ŵ� ԭ���ǳ����ļ��㾭�򻯺��Ϊ�˼򵥵��������� ��Ҫ��Ϊ���Ϸ��������趨���н������෴��  
                    V_x(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_rep_obs_fol*Frexfol_obs+V_x(formation(sub_lead(i_leader),i_fol_ca),j+1);   %���洬����һ���ĵ����ٶ�     
                    V_y(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_rep_obs_fol*Freyfol_obs+V_y(formation(sub_lead(i_leader),i_fol_ca),j+1);
                    % ��¼���ӳ�������ı����ͧ���ٶ�    
                    V_contrax2_fol_obs(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_x(formation(sub_lead(i_leader),i_fol_ca),j+1);
                    V_contray2_fol_obs(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_y(formation(sub_lead(i_leader),i_fol_ca),j+1);   
                       % mass�ĳ���

                   [Frexfol_mass,Freyfol_mass]=Change_compute_repulsion_20220401([pose_x(formation(sub_lead(i_leader),i_fol_ca),j),pose_y(formation(sub_lead(i_leader),i_fol_ca),j)],obs_pose_mass,m_rep,...
                        Theta_fol_mass,n_fol_mass_row,P_mass,distance_fol(formation(sub_lead(i_leader),i_fol_ca),j),c_mass);
                    F_record_fol_mass_mirror_x(formation(sub_lead(i_leader),i_fol_ca),j)=Frexfol_mass;
                    F_record_fol_mass_mirror_y(formation(sub_lead(i_leader),i_fol_ca),j)=Freyfol_mass;
                    % ���ﴦ������Ҳ�Ǽ򵥵ĸ���������
                        if Frexfol_mass>=90
                        Frexfol_mass=90+log10(Frexfol_mass);
                        elseif Frexfol_mass<-90
                        Frexfol_mass=-90-log10(-Frexfol_mass);
                        end
                        if Freyfol_mass>=90
                        Freyfol_mass=90+log10(Freyfol_mass);
                        elseif Freyfol_mass<-90
                        Freyfol_mass=-90-log10(-Freyfol_mass);
                        end 
                    F_record_fol_mass_x(formation(sub_lead(i_leader),i_fol_ca),j)=Frexfol_mass;
                    F_record_fol_mass_y(formation(sub_lead(i_leader),i_fol_ca),j)=Freyfol_mass;
                    % ����Ҫ��������mass�ķ�Χ
                    V_x(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_rep_obs*Frexfol_mass+V_x(formation(sub_lead(i_leader),i_fol_ca),j+1);   %���洬����һ���ĵ����ٶ�     
                    V_y(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_rep_obs*Freyfol_mass+V_y(formation(sub_lead(i_leader),i_fol_ca),j+1);
                    
                    V_contrax2_fol_mass(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_x(formation(sub_lead(i_leader),i_fol_ca),j+1);
                    V_contray2_fol_mass(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_y(formation(sub_lead(i_leader),i_fol_ca),j+1);
                      %���Ŵ��ĳ���


                    [Frexfol_ts,Freyfol_ts]=Change_compute_repulsion_20220601([pose_x(formation(sub_lead(i_leader),i_fol_ca),j),pose_y(formation(sub_lead(i_leader),i_fol_ca),j)],obs_pose_ts,m_rep,...
                        Theta_fol_ts,n_fol_ts_row,P_ts,distance_fol(formation(sub_lead(i_leader),i_fol_ca),j),c_ts,obs_pose_ts_th,pose_th(formation(sub_lead(i_leader),i_fol_ca),j),V_os(formation(sub_lead(i_leader),i_fol_ca),j),V_ts(:,j),pose_att_x(:,j),pose_att_y(:,j));
                         F_record_fol_ts_mirror_x(formation(sub_lead(i_leader),i_fol_ca),j)=Frexfol_ts;
                         F_record_fol_ts_mirror_y(formation(sub_lead(i_leader),i_fol_ca),j)=Freyfol_ts;
                        if Frexfol_ts>=90
                                Frexfol_ts=90+log10(Frexfol_ts);
                        elseif Frexfol_ts<-90
                                Frexfol_ts=-90-log10(-Frexfol_ts);
                        end

                        if Freyfol_ts>=90
                                Freyfol_ts=90+log10(Freyfol_ts);
                        elseif Freyfol_ts<-90
                                Freyfol_ts=-90-log10(-Freyfol_ts);
                        end 
                         F_record_fol_ts_x(formation(sub_lead(i_leader),i_fol_ca),j)=Frexfol_ts;
                         F_record_fol_ts_y(formation(sub_lead(i_leader),i_fol_ca),j)=Freyfol_ts; 
                    V_x(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_rep_obs*Frexfol_ts+V_x(formation(sub_lead(i_leader),i_fol_ca),j+1);   %���洬����һ���ĵ����ٶ�     
                    V_y(formation(sub_lead(i_leader),i_fol_ca),j+1)=K_rep_obs*Freyfol_ts+V_y(formation(sub_lead(i_leader),i_fol_ca),j+1);


                    V_contrax2_fol_ts(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_x(formation(sub_lead(i_leader),i_fol_ca),j+1);
                    V_contray2_fol_ts(formation(sub_lead(i_leader),i_fol_ca),j+1)=V_y(formation(sub_lead(i_leader),i_fol_ca),j+1);

            end
            
            
    end

%% ���Ŵ����ٶ�λ�ø���

for i_att_ais=1:max(ship_pos(:,1))
    % ����ͨ�����ָ��ֹ켣��AIS���켣�����������˴�������ö���
    if (i_att_ais==1&&j>=4460)||...
       (i_att_ais==2&&j>=3300)||...
       (i_att_ais==3&&j>=4254)||...
       (i_att_ais==4&&j>=2818)||...
       (i_att_ais==5&&j>=4462)||...
       (i_att_ais==6&&j>=1438)
        
        
        

        if (abs(pose_att_x(i_att_ais,j)-init_att(i_att_ais,3))<100*l)&&(abs(pose_att_y(i_att_ais,j)-init_att(i_att_ais,4))<100*l)
            V_att_x(i_att_ais,j)=0;
            V_att_y(i_att_ais,j)=0;
            V_syn_att(i_att_ais,j)=sqrt((V_att_x(i_att_ais,j))^2+(V_att_y(i_att_ais,j))^2);
            V_ts(i_att_ais,j+1)=sqrt(V_att_x(i_att_ais,j)^2+V_att_y(i_att_ais,j)^2);
            pose_att_x(i_att_ais,j+1)=pose_att_x(i_att_ais,j)+V_att_x(i_att_ais,j)*dt;
            pose_att_y(i_att_ais,j+1)=pose_att_y(i_att_ais,j)+V_att_y(i_att_ais,j)*dt;
            if V_att_x(i_att_ais,j)==0&&V_att_y(i_att_ais,j)==0
                pose_att_th(i_att_ais,j+1)=nan;
            else
                    pose_att_th(i_att_ais,j+1)=atan2(V_att_y(i_att_ais,j),V_att_x(i_att_ais,j));
                    if  pose_att_th(i_att_ais,j+1)<0
                        pose_att_th(i_att_ais,j+1)=pose_att_th(i_att_ais,j+1)+2*pi;
                    end
            end

        else
            delta_att_t(i_att_ais,1)=ship_tran_time(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),2)-ship_tran_time(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1)-1,2);
            delta_att_x(i_att_ais,1)=ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),1)-ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1)-1,1);
            delta_att_y(i_att_ais,1)=ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),2)-ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1)-1,2);
            while (delta_att_t(i_att_ais,1)==0)
                att_pos(i_att_ais,1)=att_pos(i_att_ais,1)+1;
                        delta_att_t(i_att_ais,1)=ship_tran_time(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),2)-ship_tran_time(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1)-1,2);
                        delta_att_x(i_att_ais,1)=ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),1)-ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1)-1,1);
                        delta_att_y(i_att_ais,1)=ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),2)-ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1)-1,2);


            end

            V_att_x(i_att_ais,j)=delta_att_x(i_att_ais,1)/delta_att_t(i_att_ais,1);
            V_att_y(i_att_ais,j)=delta_att_y(i_att_ais,1)/delta_att_t(i_att_ais,1);
            V_ts(i_att_ais,j+1)=sqrt(V_att_x(i_att_ais,j)^2+V_att_y(i_att_ais,j)^2);
            V_syn_att(i_att_ais,j)=sqrt((V_att_x(i_att_ais,j))^2+(V_att_y(i_att_ais,j))^2);
            pose_att_x(i_att_ais,j+1)=pose_att_x(i_att_ais,j)+V_att_x(i_att_ais,j)*dt;
            pose_att_y(i_att_ais,j+1)=pose_att_y(i_att_ais,j)+V_att_y(i_att_ais,j)*dt;
            if V_att_x(i_att_ais,j)==0&&V_att_y(i_att_ais,j)==0
                pose_att_th(i_att_ais,j+1)=nan;
            else
                    pose_att_th(i_att_ais,j+1)=atan2(V_att_y(i_att_ais,j),V_att_x(i_att_ais,j));
                    if  pose_att_th(i_att_ais,j+1)<0
                        pose_att_th(i_att_ais,j+1)=pose_att_th(i_att_ais,j+1)+2*pi;
                    end
            end
            if (abs(pose_att_x(i_att_ais,j+1)-ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),1))<=5*l)&&(abs(pose_att_y(i_att_ais,j+1)-ship_tran_pos(ship_time_delta(i_att_ais)+att_pos(i_att_ais,1),2))<=5*l)
                att_pos(i_att_ais,1)=att_pos(i_att_ais,1)+1;
            else
                continue;
            end

        end
    else
            V_att_x(i_att_ais,j)=0;
            V_att_y(i_att_ais,j)=0;
            V_syn_att(i_att_ais,j)=sqrt((V_att_x(i_att_ais,j))^2+(V_att_y(i_att_ais,j))^2);
            pose_att_x(i_att_ais,j+1)=pose_att_x(i_att_ais,j)+V_att_x(i_att_ais,j)*dt;
            pose_att_y(i_att_ais,j+1)=pose_att_y(i_att_ais,j)+V_att_y(i_att_ais,j)*dt;
           
             V_ts(i_att_ais,j+1)=sqrt(V_att_x(i_att_ais,j)^2+V_att_y(i_att_ais,j)^2);
            if V_att_x(i_att_ais,j)==0&&V_att_y(i_att_ais,j)==0
                pose_att_th(i_att_ais,j+1)=nan;
            else
                    pose_att_th(i_att_ais,j+1)=atan2(V_att_y(i_att_ais,j),V_att_x(i_att_ais,j));
                    if  pose_att_th(i_att_ais,j+1)<0
                        pose_att_th(i_att_ais,j+1)=pose_att_th(i_att_ais,j+1)+2*pi;
                    end
            end
    end
    
end






    %% ����ʱ���ڵ�λ�ø���
    % �����ٶȸ���ǰ��׼������
    
    judge_confine(j)=1;
    for i_leader_pos=1:length(find(sub_lead~=0))
        % ������Ҫ��i_leader_pos��Ϊsub_lead(i_leader_pos)
%         for i_pos=1:N   % ��ÿ�μ����ٶȺ�������Ҫ������1sʱ��������˵�λ�ø���

        if sub_lead(i_leader_pos)<N
            out_fol=confine([V_x(sub_lead(i_leader_pos),j) V_y(sub_lead(i_leader_pos),j)],[V_x(sub_lead(i_leader_pos),j+1) V_y(sub_lead(i_leader_pos),j+1)],Kinematic,1); %confine��һ������,��442��
            V_x(sub_lead(i_leader_pos),j+1)=out_fol(1);
            V_y(sub_lead(i_leader_pos),j+1)=out_fol(2);
            V_syn(sub_lead(i_leader_pos),j+1)=sqrt(V_x(sub_lead(i_leader_pos),j+1)^2+V_y(sub_lead(i_leader_pos),j+1)^2);
        end
        
         if judge_confine(j)==1
         out_fol=confine([V_x(N,j) V_y(N,j)],[V_x(N,j+1) V_y(N,j+1)],Kinematic,1);
         V_x(N,j+1)=out_fol(1);
         V_y(N,j+1)=out_fol(2);
         V_syn(N,j+1)=sqrt(V_x(N,j+1)^2+V_y(N,j+1)^2);
         judge_confine(j)=0;
         end
        
         
         V_x_rec_confine(sub_lead(i_leader_pos),j+1)=out_fol(1);  
         V_y_rec_confine(sub_lead(i_leader_pos),j+1)=out_fol(2);
         
            if pose_change(sub_lead(i_leader_pos))==1
                if sub_lead(i_leader_pos)<=fol_num

        % 
        %           ȫ�ָ�����Ŀ���  
                [V_x_add,V_y_add]=fols_addspeed(V_x(sub_lead(i_leader_pos),j+1),V_y(sub_lead(i_leader_pos),j+1),pose_x(sub_lead(i_leader_pos),j),...
                    pose_y(sub_lead(i_leader_pos),j),pose_quan_fina_x(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))),pose_quan_fina_y(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))),d_max_fol,Kinematic);
                     V_x(sub_lead(i_leader_pos),j+1)=V_x_add;
                     V_x_rec_fols_addspeed(sub_lead(i_leader_pos),j+1)=V_x_add;
                     V_y(sub_lead(i_leader_pos),j+1)=V_y_add;
                     V_y_rec_fols_addspeed(sub_lead(i_leader_pos),j+1)=V_y_add;


                end
            end

    if pose_change(sub_lead(i_leader_pos))==0

        if judge_fol_goal(sub_lead(i_leader_pos))==0     % �жϵ�ʱ���쵼���Ƿ�Ŀ����Ѿ�����Ϊ�յ�
        
            

            if j>1000 %1000���������Ժ�Ż�������־ֲ�����
                % ˼·:����һ���״�ѡ��,�жϱ����Ǹ������ϰ������״�Ȧ�ڲ�������ü��ξ��������С�ڶ�ֵ,�ٽ��н���ֲ��Ż���ѡ��.
               
%                 distance_obs2
            for i_dis_pose2obs=1:size(Obs_all,1)
                dis_pose2obs(sub_lead(i_leader_pos),i_dis_pose2obs)=sqrt((pose_x(sub_lead(i_leader_pos),j)-Obs_all(i_dis_pose2obs,1))^2+(pose_y(sub_lead(i_leader_pos),j)-Obs_all(i_dis_pose2obs,2))^2);
            end
                if (distance_diedai(sub_lead(i_leader_pos),j-1)<4)&&(distance_diedai(sub_lead(i_leader_pos),j-2)<4)&&(distance_diedai(sub_lead(i_leader_pos),j-3)<4)&&(min(dis_pose2obs(sub_lead(i_leader_pos),:))<radar)
                        rec_opt_jubu(sub_lead(i_leader_pos))=1;
                        % �˴��������˴����ò�ȡ���ϰ���Ĳ���������ʩ
                        % i_opt_quanju_fina
                            if i_opt_quanju_fina(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))-1)==3 % �˴�������ض����ϰ�����Ž���ר�ŵľֲ����Ż���
                                
                                    rec_opt_jubu_xunhuan(sub_lead(i_leader_pos))=15;
                            else
                                    rec_opt_jubu_xunhuan(sub_lead(i_leader_pos))=5;
                            end



                else
                        rec_opt_jubu(sub_lead(i_leader_pos))=0;
                        if  rec_opt_jubu_xunhuan(sub_lead(i_leader_pos))>0
                            rec_opt_jubu_xunhuan(sub_lead(i_leader_pos))=rec_opt_jubu_xunhuan(sub_lead(i_leader_pos))-1;
                        
                            
                        end
                end

            end
            if  rec_opt_jubu_xunhuan(sub_lead(i_leader_pos))>0
                    rec_opt_jubu(sub_lead(i_leader_pos))=0;

 % �����������˴��뵱ǰ��Ŀ���ļнǣ����쵼�ߴ���(��������Ŀ������ŵı���)

                                       dir_x = pose_quan_fina_x(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos)))-pose_x(sub_lead(i_leader_pos),j);   %��Ŀ��������˴���ǰλ�õĲ�ֵx
                                       dir_y = pose_quan_fina_y(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos)))-pose_y(sub_lead(i_leader_pos),j);   %��Ŀ��������˴���ǰλ�õĲ�ֵy
                                            if dir_x>=0&&dir_y>=0
                                                dir_th=atan(dir_y/dir_x);
                                            elseif dir_y>=0&&dir_x<0
                                               dir_th=pi-abs(atan(dir_y/dir_x));
                                            elseif dir_y<0&&dir_x<0
                                                dir_th=pi+abs(atan(dir_y/dir_x));
                                            elseif dir_y<0&&dir_x>=0
                                                dir_th=2*pi-abs(atan(dir_y/dir_x));
                                            end             
                                            
                    if i_opt_quanju_fina(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))-2)==0
                        if pose_y(sub_lead(i_leader_pos),j)<centre_obs(i_opt_quanju_fina(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))-3),2)  % �˴���var(i_pos)-1 ��Ϊ�˸�֮ǰ��i_opt_jubu_obs���Ӧ��
                        %���ж�Obs3 �����ã��ü��ж�
                            if pose_x(sub_lead(i_leader_pos),j)<centre_obs(i_opt_quanju_fina(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))-3),1)
                                    dir_th=dir_th+pi/2;

                            else
                                dir_th=dir_th-pi/2;
                            end
                        else
                                dir_th=dir_th+pi/2;
                        end
                    else
                         if pose_y(sub_lead(i_leader_pos),j)<centre_obs(i_opt_quanju_fina(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))-2),2)  % �˴���var(i_pos)-1 ��Ϊ�˸�֮ǰ��i_opt_jubu_obs���Ӧ��

                            if pose_x(sub_lead(i_leader_pos),j)<centre_obs(i_opt_quanju_fina(sub_lead(i_leader_pos),vars(sub_lead(i_leader_pos))-2),1)
                                    dir_th=dir_th+pi/2;

                            else
                                dir_th=dir_th-pi/2;
                            end
                        else
                                dir_th=dir_th+pi/2;
                        end
                    end
                   

            % ���ڼ���ʵ��λ�ø���֮ǰ
               % ǿ��ˢ��λ��

                    V_x(sub_lead(i_leader_pos),j+1)=sqrt(50)*cos(dir_th);
                    V_y(sub_lead(i_leader_pos),j+1)=sqrt(50)*sin(dir_th);

                    pose_x(sub_lead(i_leader_pos),j+1)=pose_x(sub_lead(i_leader_pos),j)+dt*V_x(sub_lead(i_leader_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                    pose_y(sub_lead(i_leader_pos),j+1)=pose_y(sub_lead(i_leader_pos),j)+dt*V_y(sub_lead(i_leader_pos),j+1);

                    distance_diedai(sub_lead(i_leader_pos),j)=sqrt((pose_x(sub_lead(i_leader_pos),j+1)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_y(sub_lead(i_leader_pos),j+1)-pose_y(sub_lead(i_leader_pos),j))^2);
                                %���������캽�ߵļн� ����ʹ�õ���atan
                                if V_y(sub_lead(i_leader_pos),j+1)>0&&V_x(sub_lead(i_leader_pos),j+1)>0
                                    pose_th(sub_lead(i_leader_pos),j+1)=atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1));
                                elseif V_y(sub_lead(i_leader_pos),j+1)>=0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                    pose_th(sub_lead(i_leader_pos),j+1)=pi-atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                                elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                    pose_th(sub_lead(i_leader_pos),j+1)=pi+atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                                elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)>=0
                                    pose_th(sub_lead(i_leader_pos),j+1)=2*pi-atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                                else
                                    pose_th(sub_lead(i_leader_pos),j+1)=pose_th(sub_lead(i_leader_pos),j);
                                end   
                                 V_syn_re(sub_lead(i_leader_pos),j+1)=sqrt(V_x(sub_lead(i_leader_pos),j+1)^2+V_y(sub_lead(i_leader_pos),j+1)^2);
            else   


                    pose_x(sub_lead(i_leader_pos),j+1)=pose_x(sub_lead(i_leader_pos),j)+dt*V_x(sub_lead(i_leader_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                    pose_y(sub_lead(i_leader_pos),j+1)=pose_y(sub_lead(i_leader_pos),j)+dt*V_y(sub_lead(i_leader_pos),j+1);
                    distance_diedai(sub_lead(i_leader_pos),j)=sqrt((pose_x(sub_lead(i_leader_pos),j+1)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_y(sub_lead(i_leader_pos),j+1)-pose_y(sub_lead(i_leader_pos),j))^2);
                    %���������캽�ߵļн� ����ʹ�õ���atan
                    if V_y(sub_lead(i_leader_pos),j+1)>0&&V_x(sub_lead(i_leader_pos),j+1)>0
                        pose_th(sub_lead(i_leader_pos),j+1)=atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1));
                    elseif V_y(sub_lead(i_leader_pos),j+1)>=0&&V_x(sub_lead(i_leader_pos),j+1)<0
                        pose_th(sub_lead(i_leader_pos),j+1)=pi-atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                    elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)<0
                        pose_th(sub_lead(i_leader_pos),j+1)=pi+atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                    elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)>=0
                        pose_th(sub_lead(i_leader_pos),j+1)=2*pi-atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                    else
                        pose_th(sub_lead(i_leader_pos),j+1)=pose_th(sub_lead(i_leader_pos),j);
                    end

           end
        else        
                    %�����˴��������쵼�ߴ��������ϰ������������ʵ����ٵȴ�
                    % ע��˴�Ӧ�ñ�ǡ���Ҫ�ж��Ƿ�����˾ֲ��������
                    pose_x(sub_lead(i_leader_pos),j+1)=pose_x(sub_lead(i_leader_pos),j)+dt*V_x(sub_lead(i_leader_pos),j+1)/10;            %�������ڵĳ�Ա��λ�úͽǶ�
                    pose_y(sub_lead(i_leader_pos),j+1)=pose_y(sub_lead(i_leader_pos),j)+dt*V_y(sub_lead(i_leader_pos),j+1)/10;
                    distance_diedai(sub_lead(i_leader_pos),j)=sqrt((pose_x(sub_lead(i_leader_pos),j+1)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_y(sub_lead(i_leader_pos),j+1)-pose_y(sub_lead(i_leader_pos),j))^2);
                    %���������캽�ߵļн� ����ʹ�õ���atan
                    if V_y(sub_lead(i_leader_pos),j+1)>0&&V_x(sub_lead(i_leader_pos),j+1)>0
                        pose_th(sub_lead(i_leader_pos),j+1)=atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1));
                    elseif V_y(sub_lead(i_leader_pos),j+1)>=0&&V_x(sub_lead(i_leader_pos),j+1)<0
                        pose_th(sub_lead(i_leader_pos),j+1)=pi-atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                    elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)<0
                        pose_th(sub_lead(i_leader_pos),j+1)=pi+atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                    elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)>=0
                        pose_th(sub_lead(i_leader_pos),j+1)=2*pi-atan(abs(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                    else
                        pose_th(sub_lead(i_leader_pos),j+1)=pose_th(sub_lead(i_leader_pos),j);
                    end
        end
 %%  �ж��Ƿ������ͼ���ں���
 
        for i_pos2judge=1:N
            in_set=true;
            degree_inset=0; 
            degree_inset_mirror=0;
            degree_inset_choose=0;
            while in_set

                for i_obs2judge=1:max(island_pos(:,1))
                    obs2num=find(island_pos(:,1)==i_obs2judge);
                    test=[island_tran_pos(obs2num(1,1):obs2num(1,1)+size(obs2num,1)-1,1),island_tran_pos(obs2num(1,1):obs2num(1,1)+size(obs2num,1)-1,2)]; % ����ÿ���ϰ������������ϰ������е������
                    
                    [in_set] = inpolygon_set([pose_x(i_pos2judge,j+1),pose_y(i_pos2judge,j+1)],test);% �ж� ��ǰ���˴�����һ��λ���Ƿ����ϰ��ﹹ�ɵķ��ͼ����
                    if in_set
 % �����������˴��뵱ǰ��Ŀ���ļнǣ����쵼�ߴ���(��������Ŀ������ŵı���)
                           dir_x = pose_quan_fina_x(i_pos2judge,vars(i_pos2judge))-pose_x(i_pos2judge,j);   %��Ŀ��������˴���ǰλ�õĲ�ֵx
                           dir_y = pose_quan_fina_y(i_pos2judge,vars(i_pos2judge))-pose_y(i_pos2judge,j);   %��Ŀ��������˴���ǰλ�õĲ�ֵy
                                if dir_x>=0&&dir_y>=0
                                    dir_th=atan(dir_y/dir_x);
                                elseif dir_y>=0&&dir_x<0
                                   dir_th=pi-abs(atan(dir_y/dir_x));
                                elseif dir_y<0&&dir_x<0
                                    dir_th=pi+abs(atan(dir_y/dir_x));
                                elseif dir_y<0&&dir_x>=0
                                    dir_th=2*pi-abs(atan(dir_y/dir_x));
                                end 

    %                       ���Ը�����Ŀ���ķ��������Դ�С�ͷ���
    %                   ������һ�������ϰ����ڵ��ۺ��ٶȣ�Ȼ����в�ͬ�Ƕȵķֽ�
                        if judge_fol_goal(i_pos2judge)==0 
                            if i_pos2judge<=fol_num
                                V_syn_judge(i_pos2judge,j+1)=V_syn_re(i_pos2judge,j+1);
                            else
                                V_syn_judge(i_pos2judge,j+1)=V_syn(i_pos2judge,j+1); 
                            end
                            
                        else
                            V_syn_judge(i_pos2judge,j+1)=V_syn(i_pos2judge,j+1);   
                        end

                                if pose_quan_fina_x(i_pos2judge,vars(i_pos2judge))<pose_x(i_pos2judge,j)
                                        
                                degree_inset_choose=2;
                                else
                                
                                degree_inset_choose=1;
                                
                                end

                            if degree_inset_choose==2
                                 degree_inset=degree_inset+pi/45;
                                V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th-pi/2-degree_inset);  
                                V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th-pi/2-degree_inset);  % y������ٶ���ȫ�������϶������ϵ�.�����յ���Ŀ�������ʱ����  
%                                 V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th-degree_inset);  
%                                 V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th-degree_inset);  % y������ٶ���ȫ�������϶������ϵ�.�����յ���Ŀ�������ʱ����  
                            else
                                degree_inset_mirror=degree_inset_mirror+pi/45;
                                V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th+pi/2+degree_inset_mirror);  
                                V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th+pi/2+degree_inset_mirror);  % y������ٶ���ȫ�������϶������ϵ�.�����յ���Ŀ�������ʱ����  
%                                 V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th+degree_inset);  
%                                 V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th+degree_inset); 
                            end
                            pose_x(i_pos2judge,j+1)=pose_x(i_pos2judge,j)+dt*V_x(i_pos2judge,j+1);           
                            pose_y(i_pos2judge,j+1)=pose_y(i_pos2judge,j)+dt*V_y(i_pos2judge,j+1);
                            distance_diedai(i_pos2judge,j)=sqrt((pose_x(i_pos2judge,j+1)-pose_x(i_pos2judge,j))^2+(pose_y(i_pos2judge,j+1)-pose_y(i_pos2judge,j))^2);
                            if V_y(i_pos2judge,j+1)>0&&V_x(i_pos2judge,j+1)>0
                                pose_th(i_pos2judge,j+1)=atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1));
                            elseif V_y(i_pos2judge,j+1)>=0&&V_x(i_pos2judge,j+1)<0
                                pose_th(i_pos2judge,j+1)=pi-abs(atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1)));
                            elseif V_y(i_pos2judge,j+1)<0&&V_x(i_pos2judge,j+1)<0
                                pose_th(i_pos2judge,j+1)=pi+abs(atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1)));
                            elseif V_y(i_pos2judge,j+1)<0&&V_x(i_pos2judge,j+1)>=0
                                pose_th(i_pos2judge,j+1)=2*pi-abs(atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1)));
                            else
                                pose_th(i_pos2judge,j+1)=pose_th(i_pos2judge,j);
                            end

                            break;
                    else
                        continue;

                    end


                end
            end
        end  
 


    %����ȫ���쵼��ʱ�����Ҫ������������Ǳ�Ӷ��εı���
        for i_setfol=1:N
                    pose_setfol_x(i_setfol,j)=pose_x(N,j)-delta_set_x(1,i_setfol);
                    pose_setfol_y(i_setfol,j)=pose_y(N,j)-delta_set_y(1,i_setfol);
        end    
        for i_set2pose=1:N-1
            distance_set2pose(i_set2pose,j)=sqrt((pose_setfol_x(i_set2pose,j)-pose_x(i_set2pose,j))^2+(pose_setfol_y(i_set2pose,j)-pose_y(i_set2pose,j))^2);

        end
    % ��ӵĶ��α������д���
    else
    %% ��ӳ�Աͧ�ع��쵼�ߵĲ�������
        for i_setfol=1:N 
                    pose_setfol_x(i_setfol,j)=pose_x(N,j)-delta_set_x(1,i_setfol);
                    pose_setfol_y(i_setfol,j)=pose_y(N,j)-delta_set_y(1,i_setfol);
        end    
        %20211129 ����ĸ����û���Ǳ�����ʩ����һ����Ҫ���ϡ�֮ǰ�滮��д�ˣ�����Ӧ�ÿ���ȫ�ֵ����ء�
    pose_change_judge(sub_lead(i_leader_pos))=1; 
      
        if Arrive_goal(sub_lead(i_leader_pos))==0
        

            if sub_lead(i_leader_pos)<=N-1
                %% �����ϰ�������󣬱�Ӷ��λָ��������١�

                        pose_x(sub_lead(i_leader_pos),j+1)=pose_x(sub_lead(i_leader_pos),j)+dt*V_x(sub_lead(i_leader_pos),j+1);
                        pose_y(sub_lead(i_leader_pos),j+1)=pose_y(sub_lead(i_leader_pos),j)+dt*V_y(sub_lead(i_leader_pos),j+1);
                        distance_diedai(sub_lead(i_leader_pos),j)=sqrt((pose_x(sub_lead(i_leader_pos),j+1)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_y(sub_lead(i_leader_pos),j+1)-pose_y(sub_lead(i_leader_pos),j))^2);
%                     for i_set2pose=1:N-1
                        distance_set2pose(sub_lead(i_leader_pos),j)=sqrt((pose_setfol_x(sub_lead(i_leader_pos),j)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_setfol_y(sub_lead(i_leader_pos),j)-pose_y(sub_lead(i_leader_pos),j))^2);
%                     end
            else
                            for i_set2pose=1:N-1
                                distance_set2pose(i_set2pose,j)=sqrt((pose_setfol_x(i_set2pose,j)-pose_x(i_set2pose,j))^2+(pose_setfol_y(i_set2pose,j)-pose_y(i_set2pose,j))^2);

                            end
                   % ������Ҫ���쵼�߼��٣����洬Ҳ����ֱ�����������ϣ�
                     if max(distance_set2pose(:,j)>=max(dis_st_fol(:)))
                             pose_x(sub_lead(i_leader_pos),j+1)=pose_x(sub_lead(i_leader_pos),j)+dt*V_x(sub_lead(i_leader_pos),j+1)/2;            %�������ڵĳ�Ա��λ�úͽǶ�
                             pose_y(sub_lead(i_leader_pos),j+1)=pose_y(sub_lead(i_leader_pos),j)+dt*V_y(sub_lead(i_leader_pos),j+1)/2;
                             distance_diedai(sub_lead(i_leader_pos),j)=sqrt((pose_x(sub_lead(i_leader_pos),j+1)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_y(sub_lead(i_leader_pos),j+1)-pose_y(sub_lead(i_leader_pos),j))^2);
                            %���������캽�ߵļн� ����ʹ�õ���atan
                            if V_y(sub_lead(i_leader_pos),j+1)>0&&V_x(sub_lead(i_leader_pos),j+1)>0
                                pose_th(sub_lead(i_leader_pos),j+1)=atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1));
                            elseif V_y(sub_lead(i_leader_pos),j+1)>=0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                pose_th(sub_lead(i_leader_pos),j+1)=pi-abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                pose_th(sub_lead(i_leader_pos),j+1)=pi+abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)>=0
                                pose_th(sub_lead(i_leader_pos),j+1)=2*pi-abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            else
                                pose_th(sub_lead(i_leader_pos),j+1)=pose_th(sub_lead(i_leader_pos),j);
                            end
                     else
                            pose_x(sub_lead(i_leader_pos),j+1)=pose_x(sub_lead(i_leader_pos),j)+dt*V_x(sub_lead(i_leader_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                            pose_y(sub_lead(i_leader_pos),j+1)=pose_y(sub_lead(i_leader_pos),j)+dt*V_y(sub_lead(i_leader_pos),j+1);
                            distance_diedai(sub_lead(i_leader_pos),j)=sqrt((pose_x(sub_lead(i_leader_pos),j+1)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_y(sub_lead(i_leader_pos),j+1)-pose_y(sub_lead(i_leader_pos),j))^2);
                            %���������캽�ߵļн� ����ʹ�õ���atan
                            if V_y(sub_lead(i_leader_pos),j+1)>0&&V_x(sub_lead(i_leader_pos),j+1)>0
                                pose_th(sub_lead(i_leader_pos),j+1)=atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1));
                            elseif V_y(sub_lead(i_leader_pos),j+1)>=0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                pose_th(sub_lead(i_leader_pos),j+1)=pi-abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                pose_th(sub_lead(i_leader_pos),j+1)=pi+abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)>=0
                                pose_th(sub_lead(i_leader_pos),j+1)=2*pi-abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            else
                                pose_th(sub_lead(i_leader_pos),j+1)=pose_th(sub_lead(i_leader_pos),j);
                            end
                     end

            end
 
        else %�Ѿ��ﵽ�յ�Ĵ��Ĵ��� λ�þͲ�Ҫ����
            % ���� �յ��ɲ�����ƣ����������˴�����ֱ��Ϊ0

            
                V_x(sub_lead(i_leader_pos),j+1)=0;
                V_y(sub_lead(i_leader_pos),j+1)=0;
                pose_x(sub_lead(i_leader_pos),j+1)=pose_x(sub_lead(i_leader_pos),j)+dt*V_x(sub_lead(i_leader_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                pose_y(sub_lead(i_leader_pos),j+1)=pose_y(sub_lead(i_leader_pos),j)+dt*V_y(sub_lead(i_leader_pos),j+1);
                distance_diedai(sub_lead(i_leader_pos),j)=sqrt((pose_x(sub_lead(i_leader_pos),j+1)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_y(sub_lead(i_leader_pos),j+1)-pose_y(sub_lead(i_leader_pos),j))^2);
                distance_set2pose(sub_lead(i_leader_pos),j)=sqrt((pose_setfol_x(sub_lead(i_leader_pos),j)-pose_x(sub_lead(i_leader_pos),j))^2+(pose_setfol_y(sub_lead(i_leader_pos),j)-pose_y(sub_lead(i_leader_pos),j))^2);
                            if V_y(sub_lead(i_leader_pos) ,j+1)>0&&V_x(sub_lead(i_leader_pos),j+1)>0
                                pose_th(sub_lead(i_leader_pos),j+1)=atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1));
                            elseif V_y(sub_lead(i_leader_pos),j+1)>=0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                pose_th(sub_lead(i_leader_pos),j+1)=pi-abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)<0
                                pose_th(sub_lead(i_leader_pos),j+1)=pi+abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            elseif V_y(sub_lead(i_leader_pos),j+1)<0&&V_x(sub_lead(i_leader_pos),j+1)>=0
                                pose_th(sub_lead(i_leader_pos),j+1)=2*pi-abs(atan(V_y(sub_lead(i_leader_pos),j+1)/V_x(sub_lead(i_leader_pos),j+1)));
                            else
                                pose_th(sub_lead(i_leader_pos),j+1)=pose_th(sub_lead(i_leader_pos),j);
                            end    

                         V_setfol_xx(sub_lead(i_leader_pos),j+1)=0;
                         V_setfol_yy(sub_lead(i_leader_pos),j+1)=0; 
                         V_setfol_x(sub_lead(i_leader_pos),j+1)=0;
                         V_setfol_y(sub_lead(i_leader_pos),j+1)=0;                         
                        
        end
    end    
    
        for i_fol_pos=1:fol_num_mass(i_leader_pos)
                


            out_fol=confine([V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j) V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)],[V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1) V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)],Kinematic,1); %confine��һ������,��442��
            V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=out_fol(1);
            V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=out_fol(2);
            V_syn(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=sqrt(V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)^2+V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)^2);

         V_x_rec_confine(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=out_fol(1);  
         V_y_rec_confine(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=out_fol(2);
         
      
%����ͧ���ٶȲ���
% ���洬���ٶȲ����Ǵ����￪ʼ�ȽϺ� �����յ���Ӧ���ǵ���ʼ�ع��Ӻ��ٽ��в����Ŷԡ� ����ƺ�������
    if pose_change(formation(sub_lead(i_leader_pos),i_fol_pos))==1
        if formation(sub_lead(i_leader_pos),i_fol_pos)<=fol_num

% 
%           ȫ�ָ�����Ŀ���  
        [V_x_add,V_y_add]=fols_addspeed(V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1),V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1),pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j),...
            pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j),pose_quan_fina_x(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))),pose_quan_fina_y(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))),d_max_fol,Kinematic);
             V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=V_x_add;
             V_x_rec_fols_addspeed(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=V_x_add;
             V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=V_y_add;
             V_y_rec_fols_addspeed(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=V_y_add;


        end
    end
    


% ����һ���жϺ�����·���滮״̬����ײ�ϰ���״̬
        
    % �˴���pose_change�������Ǽ�������ԭ��ÿ�������õ���Ŀ����н����������쵼��ΪĿ��㿿��
    if pose_change(formation(sub_lead(i_leader_pos),i_fol_pos))==0

    
        if judge_fol_goal(formation(sub_lead(i_leader_pos),i_fol_pos))==0     % �жϵ�ʱ���쵼���Ƿ�Ŀ����Ѿ�����Ϊ�յ�
        
            

            if j>1000 %1000���������Ժ�Ż�������־ֲ�����
                % ˼·:����һ���״�ѡ��,�жϱ����Ǹ������ϰ������״�Ȧ�ڲ�������ü��ξ��������С�ڶ�ֵ,�ٽ��н���ֲ��Ż���ѡ��.
               
%                 distance_obs2
            for i_dis_pose2obs=1:size(Obs_all,1)
                dis_pose2obs(formation(sub_lead(i_leader_pos),i_fol_pos),i_dis_pose2obs)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)-Obs_all(i_dis_pose2obs,1))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)-Obs_all(i_dis_pose2obs,2))^2);
            end
                if (distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j-1)<4)&&(distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j-2)<4)&&(distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j-3)<4)&&(min(dis_pose2obs(formation(sub_lead(i_leader_pos),i_fol_pos),:))<radar)
                        rec_opt_jubu(formation(sub_lead(i_leader_pos),i_fol_pos))=1;
                        % �˴��������˴����ò�ȡ���ϰ���Ĳ���������ʩ
                        % i_opt_quanju_fina
                            if i_opt_quanju_fina(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))-1)==3 % �˴�������ض����ϰ�����Ž���ר�ŵľֲ����Ż���
                                
                                    rec_opt_jubu_xunhuan(formation(sub_lead(i_leader_pos),i_fol_pos))=15;
                            else
                                    rec_opt_jubu_xunhuan(formation(sub_lead(i_leader_pos),i_fol_pos))=5;
                            end



                else
                        rec_opt_jubu(formation(sub_lead(i_leader_pos),i_fol_pos))=0;
                        if  rec_opt_jubu_xunhuan(formation(sub_lead(i_leader_pos),i_fol_pos))>0
                            rec_opt_jubu_xunhuan(formation(sub_lead(i_leader_pos),i_fol_pos))=rec_opt_jubu_xunhuan(formation(sub_lead(i_leader_pos),i_fol_pos))-1;
                        
                            
                        end
                end

            end
            if  rec_opt_jubu_xunhuan(formation(sub_lead(i_leader_pos),i_fol_pos))>0
                    rec_opt_jubu(formation(sub_lead(i_leader_pos),i_fol_pos))=0;

 % �����������˴��뵱ǰ��Ŀ���ļнǣ����쵼�ߴ���(��������Ŀ������ŵı���)

                                       dir_x = pose_quan_fina_x(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos)))-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j);   %��Ŀ��������˴���ǰλ�õĲ�ֵx
                                       dir_y = pose_quan_fina_y(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos)))-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j);   %��Ŀ��������˴���ǰλ�õĲ�ֵy
                                            if dir_x>=0&&dir_y>=0
                                                dir_th=atan(dir_y/dir_x);
                                            elseif dir_y>=0&&dir_x<0
                                               dir_th=pi-abs(atan(dir_y/dir_x));
                                            elseif dir_y<0&&dir_x<0
                                                dir_th=pi+abs(atan(dir_y/dir_x));
                                            elseif dir_y<0&&dir_x>=0
                                                dir_th=2*pi-abs(atan(dir_y/dir_x));
                                            end             
                                            
                    if i_opt_quanju_fina(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))-2)==0
                        if pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)<centre_obs(i_opt_quanju_fina(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))-3),2)  % �˴���var(formation(sub_lead(i_leader_pos),i_fol_pos))-1 ��Ϊ�˸�֮ǰ��i_opt_jubu_obs���Ӧ��
                        %���ж�Obs3 �����ã��ü��ж�
                            if pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)<centre_obs(i_opt_quanju_fina(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))-3),1)
                                    dir_th=dir_th+pi/2;

                            else
                                dir_th=dir_th-pi/2;
                            end
                        else
                                dir_th=dir_th+pi/2;
                        end
                    else
                         if pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)<centre_obs(i_opt_quanju_fina(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))-2),2)  % �˴���var(formation(sub_lead(i_leader_pos),i_fol_pos))-1 ��Ϊ�˸�֮ǰ��i_opt_jubu_obs���Ӧ��

                            if pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)<centre_obs(i_opt_quanju_fina(formation(sub_lead(i_leader_pos),i_fol_pos),vars(formation(sub_lead(i_leader_pos),i_fol_pos))-2),1)
                                    dir_th=dir_th+pi/2;

                            else
                                dir_th=dir_th-pi/2;
                            end
                        else
                                dir_th=dir_th+pi/2;
                        end
                    end
                   

            % ���ڼ���ʵ��λ�ø���֮ǰ
               % ǿ��ˢ��λ��

                    V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=sqrt(50)*cos(dir_th);
                    V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=sqrt(50)*sin(dir_th);

                    pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                    pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);

                    distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
                                %���������캽�ߵļн� ����ʹ�õ���atan
                                if V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0
                                    pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1));
                                elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                    pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi-atan(abs(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                                elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                    pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi+atan(abs(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                                elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0
                                    pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=2*pi-atan(abs(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                                else
                                    pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j);
                                end   
                                 V_syn_re(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=sqrt(V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)^2+V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)^2);
            else   
                                    %���θ��油��
                  [V_re_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1),V_re_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)] = fol_respeed_2_0_test0511(V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1),V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1),formation(sub_lead(i_leader_pos),i_fol_pos),Kinematic,vars(formation(sub_lead(i_leader_pos),i_fol_pos)),pose_quan_fina_xx_res,pose_quan_fina_yy_res,[pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j),pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)]);
%                                                                               ���������ڶ�����Ŀ��㣨�������յ����ڣ������˴�����·�����쵼�ߵ��ۺ��ٶȣ�V_x��V_y����δ������ǰ�ٶȣ����˴���ţ��쵼����ţ�����ѧԼ�����쵼�߱���λ�ã��쵼�߳�����Ŀ�����ţ����˴�������Ŀ�����ţ���Ŀ���λ�ã����˴�����λ�á�
                                    V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1) =V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)+V_re_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);
                                    V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1) =V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)+V_re_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);

                           


                        % ��¼����out_fol���ٶ�ֵ
                        V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)= V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);
                        V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)= V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);

                        V_syn_re(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=sqrt(V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)^2+V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)^2);

                    pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                    pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);
                    distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
                    %���������캽�ߵļн� ����ʹ�õ���atan
                    if V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0&&V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=atan(V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1));
                    elseif V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0&&V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi-atan(abs(V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                    elseif V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi+atan(abs(V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                    elseif V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=2*pi-atan(abs(V_yre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_xre(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                    else
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)= pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j);
                    end



            end
        else        
                    %�����˴��������쵼�ߴ��������ϰ������������ʵ����ٵȴ�
                    % ע��˴�Ӧ�ñ�ǡ���Ҫ�ж��Ƿ�����˾ֲ��������
                    pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/10;            %�������ڵĳ�Ա��λ�úͽǶ�
                    pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/10;
                    distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
                    %���������캽�ߵļн� ����ʹ�õ���atan
                    if V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1));
                    elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi-atan(abs(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                    elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi+atan(abs(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                    elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=2*pi-atan(abs(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                    else
                        pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j);
                    end
        end
 %%  �ж��Ƿ������ͼ���ں���
 
        for i_pos2judge=1:N
            in_set=true;
            degree_inset=0; %20220302
            degree_inset_mirror=0;
            degree_inset_choose=0;
            while in_set

                for i_obs2judge=1:max(island_pos(:,1))
                    obs2num=find(island_pos(:,1)==i_obs2judge);
                    test=[island_tran_pos(obs2num(1,1):obs2num(1,1)+size(obs2num,1)-1,1),island_tran_pos(obs2num(1,1):obs2num(1,1)+size(obs2num,1)-1,2)]; % ����ÿ���ϰ������������ϰ������е������
                    
                    [in_set] = inpolygon_set([pose_x(i_pos2judge,j+1),pose_y(i_pos2judge,j+1)],test);% �ж� ��ǰ���˴�����һ��λ���Ƿ����ϰ��ﹹ�ɵķ��ͼ����
                    if in_set
 % �����������˴��뵱ǰ��Ŀ���ļнǣ����쵼�ߴ���(��������Ŀ������ŵı���)
                           dir_x = pose_quan_fina_x(i_pos2judge,vars(i_pos2judge))-pose_x(i_pos2judge,j);   %��Ŀ��������˴���ǰλ�õĲ�ֵx
                           dir_y = pose_quan_fina_y(i_pos2judge,vars(i_pos2judge))-pose_y(i_pos2judge,j);   %��Ŀ��������˴���ǰλ�õĲ�ֵy
                                if dir_x>=0&&dir_y>=0
                                    dir_th=atan(dir_y/dir_x);
                                elseif dir_y>=0&&dir_x<0
                                   dir_th=pi-abs(atan(dir_y/dir_x));
                                elseif dir_y<0&&dir_x<0
                                    dir_th=pi+abs(atan(dir_y/dir_x));
                                elseif dir_y<0&&dir_x>=0
                                    dir_th=2*pi-abs(atan(dir_y/dir_x));
                                end 

    %                       ���Ը�����Ŀ���ķ��������Դ�С�ͷ���
    %                   ������һ�������ϰ����ڵ��ۺ��ٶȣ�Ȼ����в�ͬ�Ƕȵķֽ�
                        if judge_fol_goal(i_pos2judge)==0 
                            if i_pos2judge<=fol_num
                                V_syn_judge(i_pos2judge,j+1)=V_syn_re(i_pos2judge,j+1);
                            else
                                V_syn_judge(i_pos2judge,j+1)=V_syn(i_pos2judge,j+1); 
                            end
                            
                        else
                            V_syn_judge(i_pos2judge,j+1)=V_syn(i_pos2judge,j+1);   
                        end

                                if pose_quan_fina_x(i_pos2judge,vars(i_pos2judge))<pose_x(i_pos2judge,j)
                                        
                                degree_inset_choose=2;
                                else
                                
                                degree_inset_choose=1;
                                
                                end

                            if degree_inset_choose==2
                                 degree_inset=degree_inset+pi/45;
                                V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th-pi/2-degree_inset);  
                                V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th-pi/2-degree_inset);  % y������ٶ���ȫ�������϶������ϵ�.�����յ���Ŀ�������ʱ����  
%                                 V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th-degree_inset);  
%                                 V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th-degree_inset);  % y������ٶ���ȫ�������϶������ϵ�.�����յ���Ŀ�������ʱ����  
                            else
                                degree_inset_mirror=degree_inset_mirror+pi/45;
                                V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th+pi/2+degree_inset_mirror);  
                                V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th+pi/2+degree_inset_mirror);  % y������ٶ���ȫ�������϶������ϵ�.�����յ���Ŀ�������ʱ����  
%                                 V_x(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*cos(dir_th+degree_inset);  
%                                 V_y(i_pos2judge,j+1)=V_syn_judge(i_pos2judge,j+1)*sin(dir_th+degree_inset); 
                            end
                            pose_x(i_pos2judge,j+1)=pose_x(i_pos2judge,j)+dt*V_x(i_pos2judge,j+1);           
                            pose_y(i_pos2judge,j+1)=pose_y(i_pos2judge,j)+dt*V_y(i_pos2judge,j+1);
                            distance_diedai(i_pos2judge,j)=sqrt((pose_x(i_pos2judge,j+1)-pose_x(i_pos2judge,j))^2+(pose_y(i_pos2judge,j+1)-pose_y(i_pos2judge,j))^2);
                            if V_y(i_pos2judge,j+1)>0&&V_x(i_pos2judge,j+1)>0
                                pose_th(i_pos2judge,j+1)=atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1));
                            elseif V_y(i_pos2judge,j+1)>=0&&V_x(i_pos2judge,j+1)<0
                                pose_th(i_pos2judge,j+1)=pi-abs(atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1)));
                            elseif V_y(i_pos2judge,j+1)<0&&V_x(i_pos2judge,j+1)<0
                                pose_th(i_pos2judge,j+1)=pi+abs(atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1)));
                            elseif V_y(i_pos2judge,j+1)<0&&V_x(i_pos2judge,j+1)>=0
                                pose_th(i_pos2judge,j+1)=2*pi-abs(atan(V_y(i_pos2judge,j+1)/V_x(i_pos2judge,j+1)));
                            else
                                pose_th(i_pos2judge,j+1)=pose_th(i_pos2judge,j);
                            end

                            break;
                    else
                        continue;

                    end


                end
            end
        end  
 


    %����ȫ���쵼��ʱ�����Ҫ������������Ǳ�Ӷ��εı���
        for i_setfol=1:N
                    pose_setfol_x(i_setfol,j)=pose_x(N,j)-delta_set_x(1,i_setfol);
                    pose_setfol_y(i_setfol,j)=pose_y(N,j)-delta_set_y(1,i_setfol);
        end    
        for i_set2pose=1:N-1
            distance_set2pose(i_set2pose,j)=sqrt((pose_setfol_x(i_set2pose,j)-pose_x(i_set2pose,j))^2+(pose_setfol_y(i_set2pose,j)-pose_y(i_set2pose,j))^2);

        end

    else
    %% ��ӳ�Աͧ�ع��쵼�ߵĲ�������
        for i_setfol=1:N 
                    pose_setfol_x(i_setfol,j)=pose_x(N,j)-delta_set_x(1,i_setfol);
                    pose_setfol_y(i_setfol,j)=pose_y(N,j)-delta_set_y(1,i_setfol);
        end    

    pose_change_judge(formation(sub_lead(i_leader_pos),i_fol_pos))=1; 
      
        if Arrive_goal(formation(sub_lead(i_leader_pos),i_fol_pos))==0
        

            if formation(sub_lead(i_leader_pos),i_fol_pos)<=N-1
                %% �����ϰ�������󣬱�Ӷ��λָ��������١�

                        pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);
                        pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);
                        distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
%                     for i_set2pose=1:N-1
                        distance_set2pose(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_setfol_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_setfol_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
%                     end
                else
                   % ������Ҫ���쵼�߼��٣����洬Ҳ����ֱ�����������ϣ�
                     if max(distance_set2pose(:,j)>=max(dis_st_fol(:)))
                             pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/2;            %�������ڵĳ�Ա��λ�úͽǶ�
                             pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/2;
                             distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
                            %���������캽�ߵļн� ����ʹ�õ���atan
                            if V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi-abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi+abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=2*pi-abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            else
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j);
                            end
                     else
                            pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                            pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);
                            distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
                            %���������캽�ߵļн� ����ʹ�õ���atan
                            if V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi-abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi+abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=2*pi-abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            else
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j);
                            end
                     end

            end
 
        else 

            
                V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=0;
                V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=0;
                pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);            %�������ڵĳ�Ա��λ�úͽǶ�
                pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)+dt*V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1);
                distance_diedai(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
                distance_set2pose(formation(sub_lead(i_leader_pos),i_fol_pos),j)=sqrt((pose_setfol_x(formation(sub_lead(i_leader_pos),i_fol_pos),j)-pose_x(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2+(pose_setfol_y(formation(sub_lead(i_leader_pos),i_fol_pos),j)-pose_y(formation(sub_lead(i_leader_pos),i_fol_pos),j))^2);
                            if V_y(formation(sub_lead(i_leader_pos),i_fol_pos) ,j+1)>0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi-abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pi+abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            elseif V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)<0&&V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)>=0
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=2*pi-abs(atan(V_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)/V_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)));
                            else
                                pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=pose_th(formation(sub_lead(i_leader_pos),i_fol_pos),j);
                            end    

                         V_setfol_xx(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=0;
                         V_setfol_yy(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=0; 
                         V_setfol_x(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=0;
                         V_setfol_y(formation(sub_lead(i_leader_pos),i_fol_pos),j+1)=0;                         
                        
        end
        
        
    end    
          
            
            
            
            
        end
        
    end

    % ע�����Ƚ�����λ�ø����ٽ����������˴��Ƿ������Ŀ�����ж�
%% �������ͧ�ع��ж�
% ׼����������ѭ����ʼ֮ǰ�ȼ������ÿ�����쵼�ߴ������ĸ��洬��Ӧ�õ������Ŀ�������λ��
% ������Ҫ���������յ���varsֵ�ñ仯
    for i_pre=1:length(sub_lead)
          fol_num_sub_lead(i_pre)=size(find(formation(sub_lead(i_pre),:)~=0),2);
              if fol_num_sub_lead(i_pre)~=0

                    [pose_quan_fina_x_sub,pose_quan_fina_y_sub] = auto_formation0511(i_pre,[pose_quan_fina_x(sub_lead(i_pre),vars(i_pre)) pose_quan_fina_y(sub_lead(i_pre),vars(i_pre))],fol_num_sub_lead(i_pre),vars,formation,sub_lead,judge_tran_cond,N,pose_th(sub_lead(i_pre),j+1),tran_theta,dis_st_fol);
                    for i_write=1:fol_num_sub_lead(i_pre)
                        pose_quan_fina_x_sub_goal(formation(sub_lead(i_pre),i_write),vars(formation(sub_lead(i_pre),i_write)))=pose_quan_fina_x_sub(formation(sub_lead(i_pre),i_write),vars(formation(sub_lead(i_pre),i_write)));
                        pose_quan_fina_y_sub_goal(formation(sub_lead(i_pre),i_write),vars(formation(sub_lead(i_pre),i_write)))=pose_quan_fina_y_sub(formation(sub_lead(i_pre),i_write),vars(formation(sub_lead(i_pre),i_write)));
                    end
 
              end
    end

            if sqrt((pose_quan_fina_x(N,vars(N))-pose_x(N,j+1))^2+(pose_quan_fina_y(N,vars(N))-pose_y(N,j+1))^2)<2*V_syn(N,j+1) 
        % ����Ӧ���� ��ǰͧ��λ�� ��ȥȫ�ּ�¼�õ����꣬ ȫ�ּ�¼�����꣬��Ϊ ��n��ͧ����i����·���㡣
    %             K = j;%��¼���������ٴΣ�����Ŀ�ꡣ
                [m_quan,n_quan]=size(pose_quan_fina_x);
                
                if pose_quan_fina_x(N,vars(N))==goal_fol(N,1,2)
                    % ��һ���޶�����:�������쵼�ߵ�var�ﵽ����ֵ.
                    if vars(N)<size(pose_quan_fina_x,2)
                        vars(N)=vars(N)+1;
                    end
                    pose_change(N)=1;

                   
%                     continue;
                else
                   vars(N)=vars(N)+1;
                    disp('Change leader point!!');
                    if pose_quan_fina_x(N,vars(N))==goal_fol(N,1,2)
                         pose_change(N)=1;
                    
                            if disp_mass_leader==0
                                 disp('leader go through obs_area!!');
                                 disp_mass_leader=1;
                                 judge_tran_cond(N)=2;
                            end
                    end
                end




            end
%         else

    for i_pose=1:fol_num
            % �����쵼���еĴ����й켣���棬����Ǹ��洬����ʱ���ϸ�
            if ismember(i_pose,sub_lead)
               
                % �����쵼�߶��� ������Ŀ���λ������仯����route_follow ������Ӧ��ֵ
                 % �˴������ж��Ƿ񵽴�Ŀ���ķ�Χֵ��Ҳ���ж�̬���ж����������˴�����Ŀ���ľ���������ǰ���
%                    if ((abs(pose_x(i_pose,j+1) - pose_quan_fina_x(i_pose,vars(i_pose))) < 30*l) && (abs(pose_y(i_pose,j+1) - pose_quan_fina_y(i_pose,vars(i_pose))) < 30*l)|| pose_change(i_pose)==1) % �ж�������ԭ����50��������10.
                if (sqrt((pose_quan_fina_x(i_pose,vars(i_pose))-pose_x(i_pose,j+1))^2+(pose_quan_fina_y(i_pose,vars(i_pose))-pose_y(i_pose,j+1))^2)<2*V_syn(i_pose,j+1)||pose_change(i_pose)==1)
                       if ((abs(pose_quan_fina_x(i_pose,vars(i_pose))-goal_fol(i_pose,1,2))<200*l&&abs(pose_quan_fina_y(i_pose,vars(i_pose))-goal_fol(i_pose,2,2))<200*l)||(pose_change_judge_num(i_pose)==1))
                            judge_fol_goal(i_pose)=1;
                            if pose_quan_fina_x(N,vars(N))==goal_fol(N,1,2)


                              

                               pose_change_judge_num(i_pose)=1;
                               pose_quan_fina_x(i_pose,vars(i_pose))=pose_setfol_x(i_pose,j);
                               pose_quan_fina_y(i_pose,vars(i_pose))=pose_setfol_y(i_pose,j);
                               % ����һ���������� ��֤֮������쵼�߱�Ϊ�����ĸ��洬
                               % ����Ŀ�������Ӧ�ð��������������������ô�Ϊ���쵼�߲����и��洬����δ������洬���Ӵ�����һ����ֱ���Ǹ��洬�����ø��洬

                               % ������� ����ֻ֤���һ��
                               if disp_mass(i_pose)==0
                                       disp(['���˴� ',  num2str(i_pose),' ���쵼�߿���' ]);
                                       disp_mass(i_pose)=1;
                                       judge_tran_cond(i_pose)=1;    
                               end
                            end

                       else
                           %
                           if vars(i_pose)<size(pose_quan_fina_x,2)
                               vars(i_pose)=vars(i_pose)+1;
                               disp(['Change follower ',  num2str(i_pose),' subpoint!!']);
                           end
                           if (pose_quan_fina_x(i_pose,vars(i_pose))==goal_fol(i_pose,1,2)&&pose_quan_fina_y(i_pose,vars(i_pose))==goal_fol(i_pose,2,2))
                               pose_change(i_pose)=1;  
                               
                           end
                           
                       end

                end
            else

                [row_fols,col]=find(i_pose==formation);
                col_fols=length(find(formation(row_fols,:)~=0));                   
                        % ���ڸ��洬������
                            
                            if ( sqrt((pose_quan_fina_x(i_pose,vars(i_pose))-pose_x(i_pose,j+1))^2+(pose_quan_fina_y(i_pose,vars(i_pose))-pose_y(i_pose,j+1))^2)< dis_st_fol(col,1,col_fols))|| pose_change(i_pose)==1

                               if ((abs(pose_quan_fina_x(i_pose,vars(i_pose))-goal_fol(i_pose,1,2))<200*l&&abs(pose_quan_fina_y(i_pose,vars(i_pose))-goal_fol(i_pose,2,2))<200*l)||(pose_change_judge_num(i_pose)==1))
                                    judge_fol_goal(i_pose)=1;
                                    if pose_quan_fina_x(N,vars(N))==goal_fol(N,1,2)


                                       pose_change(i_pose)=1;  

                                       pose_change_judge_num(i_pose)=1;
                                       pose_quan_fina_x(i_pose,vars(i_pose))=pose_setfol_x(i_pose,j);
                                       pose_quan_fina_y(i_pose,vars(i_pose))=pose_setfol_y(i_pose,j);
                                       % ����һ���������� ��֤֮������쵼�߱�Ϊ�����ĸ��洬
                                       % ����Ŀ�������Ӧ�ð��������������������ô�Ϊ���쵼�߲����и��洬����δ������洬���Ӵ�����һ����ֱ���Ǹ��洬�����ø��洬

                                       % ������� ����ֻ֤���һ��
                                       if disp_mass(i_pose)==0
                                               disp(['���˴� ',  num2str(i_pose),' ���쵼�߿���' ]);
                                               disp_mass(i_pose)=1;
                                               judge_tran_cond(i_pose)=1;    
                                       end
                                    end

                               else
                                   %
                                   if vars(i_pose)<size(pose_quan_fina_x,2)
                                       vars(i_pose)=vars(i_pose)+1;
                                       disp(['Change follower ',  num2str(i_pose),' subpoint!!']);
                                   end
                                   
                                   if (pose_quan_fina_x(i_pose,vars(i_pose))==goal_fol(i_pose,1,2)&&pose_quan_fina_y(i_pose,vars(i_pose))==goal_fol(i_pose,2,2))
                                           pose_change(i_pose)=1;  

                                   end

                               end


                            end

                          
            end


%         end
        

        
    end
    % ��¼ÿһ�ε���vars��ֵ

        vars_rec(:,j)=vars;


            tt_x(1:N-1,j)=pose_setfol_x(1:N-1,j);            % tt_x��ʾ��ʼ������쵼�ߵ����꣬��������������������ͧ���쵼��֮���λ�����
            error_x(:,j)=tt_x(1:N-1,j)-pose_x(1:N-1,j);
            tt_y(1:N-1,j)=pose_setfol_y(1:N-1,j);
            error_y(:,j)=tt_y(1:N-1,j)-pose_y(1:N-1,j);
            error(1:N-1,j)=sqrt(error_x(:,j).^2+error_y(:,j).^2);
            
        for i_cal_v=1:N
            distance_jubu2vars(i_cal_v,j+1)=sqrt((pose_x(i_cal_v,j+1)-pose_quan_fina_x(i_cal_v,vars(i_cal_v)))^2+(pose_y(i_cal_v,j+1)-pose_quan_fina_y(i_cal_v,vars(i_cal_v)))^2);
            
        end
        %% ������һ�ε������쵼�ߺ͸��洬�����ƺ�����
        if j>2&& max(vars)>2
            
            [formation,decide_num]=decide_lead_fol_jubu0519(i_opt_quanju_fina,obs_axis_fina,vars,N,sub_lead,decide_num,judge_tran_cond,vars_rec,j,formation,pose_quan_fina_x,pose_quan_fina_y,pose_x,pose_y,distance_jubu2vars,dis_st_fol);
        end
       % ��ȫformation����ΪN�С�
       for_re=size(formation);
       if for_re(1)<N
           for i_for_re=1:(N-for_re(1))
               formation(for_re(1)+i_for_re,:)=zeros(1,for_re(2));
           end

       end
%         formation_rec(:,:,j)=formation;
        sub_lead=find(decide_num~=0);
        % ��ÿ�ε��������쵼�߽��м�¼��ͬʱ˼����μ�¼formation
        for i_sublead_rec=1:length(sub_lead)
            sub_lead_rec(j+1,i_sublead_rec)=sub_lead(i_sublead_rec);
        end
                % ѭ�������˵�һ�ε�����Ҫ�������Ŀ��㣬
        for i_fol_num=1:size(find(decide_num~=0),2)
            if sub_lead(i_fol_num)==N&& disp_mass_leader==1
                fol_num_mass(i_fol_num)=size(find(formation(sub_lead(i_fol_num),:)~=0),2);
              if fol_num_mass(i_fol_num)~=0
                  % �����ƺ���û�õ����趨�ı�Ӵ������·���η����ܱ�ӵĸ���λ���еĳ������
                    [pose_quan_fina_x_res,pose_quan_fina_y_res] = auto_formation0511(i_fol_num,[pose_x(sub_lead(i_fol_num),j+1) pose_y(sub_lead(i_fol_num),j+1)],fol_num_mass(i_fol_num),vars,formation,sub_lead,judge_tran_cond,N,pose_th(sub_lead(i_fol_num),j+1),tran_theta,dis_st_fol);
                    for i_write=1:fol_num_mass(i_fol_num)
                        pose_quan_fina_xx_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)))=pose_quan_fina_x_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)));
                        pose_quan_fina_yy_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)))=pose_quan_fina_y_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)));
                    end
 
              end
                
            else
                fol_num_mass(i_fol_num)=size(find(formation(sub_lead(i_fol_num),:)~=0),2);
              if fol_num_mass(i_fol_num)~=0
                    [pose_quan_fina_x_res,pose_quan_fina_y_res] = auto_formation0511(i_fol_num,[pose_x(sub_lead(i_fol_num),j+1) pose_y(sub_lead(i_fol_num),j+1)],fol_num_mass(i_fol_num),vars,formation,sub_lead,judge_tran_cond,N,pose_th(sub_lead(i_fol_num),j+1),tran_theta,dis_st_fol);
                    for i_write=1:fol_num_mass(i_fol_num)
                        pose_quan_fina_xx_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)))=pose_quan_fina_x_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)));
                        pose_quan_fina_yy_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)))=pose_quan_fina_y_res(formation(sub_lead(i_fol_num),i_write),vars(formation(sub_lead(i_fol_num),i_write)));
                    end

              end
            end
            
        end
        for i_v_os=1:N
            V_os(i_v_os,j+1)=sqrt(V_x(i_v_os,j+1)^2+V_y(i_v_os,j+1)^2);
            V_os_x(i_v_os,j+1)=V_x(i_v_os,j+1);
            V_os_y(i_v_os,j+1)=V_y(i_v_os,j+1);
            
            
        end
     % �ֶ��궨�����˴������յ�����
        Is_goal=1;
        for i_judge_goal=1:N
            

%                 if (((abs(pose_x(i_judge_goal,j+1) - pose_setfol_x(i_judge_goal,j)) <10 *l) && (abs(pose_y(i_judge_goal,j+1) - pose_setfol_y(i_judge_goal,j)) < 10*l)) && (pose_quan_fina_x(i_judge_goal,vars(i_judge_goal)+1)==goal(1,1))) % c�������ϰ�������ʱ��
                if (((abs(pose_x(i_judge_goal,j+1) - pose_setfol_x(i_judge_goal,j)) <2 *l) && (abs(pose_y(i_judge_goal,j+1) - pose_setfol_y(i_judge_goal,j)) < 2*l)) && (abs(pose_quan_fina_x(i_judge_goal,vars(i_judge_goal))-goal_fol(i_judge_goal,1,2))<100*l))
                   if i_judge_goal==N
                       if ((abs(pose_x(i_judge_goal,j+1) - goal_fol(i_judge_goal,1,2)) <1 *l) && (abs(pose_y(i_judge_goal,j+1) - goal_fol(i_judge_goal,2,2)) < 1*l))
                            Arrive_goal(i_judge_goal)=1;
                            pose_th(i_judge_goal,j+1)=pi/2;
                       else
                             Arrive_goal(i_judge_goal)=0;
                             Is_goal=0;
                       end
                   else
                       
                       Arrive_goal(i_judge_goal)=1; 
                   end
                   
                    continue; 
                else
                    Arrive_goal(i_judge_goal)=0;
                    Is_goal=0;
                end
        end
        
        if Is_goal==1
            
            disp('FAN Arrive goal!!');
            time_usv(N)=j;
            break;
        end
j

toc;
end

%��ѭ������
%% ����ÿ�εĹ��������ݱ�
 cd(picture_save_dir1);
 save('simulation_result.mat');

%% С���ܣ�����ÿ��usv�߹���ʵ��·��
route_real=zeros(N,1);
for i_route_real_usv=1:size(pose_x,1)
    for i_route_real=1:(size(pose_x,2)-1)
        route_real(i_route_real_usv)=route_real(i_route_real_usv)+sqrt((pose_x(i_route_real_usv,i_route_real+1)-pose_x(i_route_real_usv,i_route_real))^2+(pose_y(i_route_real_usv,i_route_real+1)-pose_y(i_route_real_usv,i_route_real))^2);
        
    end
    
end





 
 
%% ��¼ 
