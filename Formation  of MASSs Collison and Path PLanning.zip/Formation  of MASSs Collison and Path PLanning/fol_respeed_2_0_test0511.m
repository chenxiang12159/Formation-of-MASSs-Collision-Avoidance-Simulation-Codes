function [V_re_x,V_re_y] = fol_respeed_2_0_test0511(Vx,Vy,i,Kinematic,vars,pose_quan_fina_xx_res,pose_quan_fina_yy_res,pose_i)
%                         单船倒数第二个子目标点（不包括终点在内）至无人船起点的路径，领导者的综合速度，V_x、V_y本船未经加速前速度，无人船序号，领导者序号，动力学约束，领导者本次位置，领导者朝向子目标点序号，无人船朝向子目标点序号，子目标点位置，无人船本次位置。
%全局范围速度补偿函数
%% 更新为以相应的子领导者为基准，进行相应的速度补偿



        V_y=Vy;V_x=Vx;i_pos=i;
        pose_x_i=pose_i(1,1);pose_y_i=pose_i(1,2);
    
    route_now_i=sqrt((pose_quan_fina_xx_res(i,vars)-pose_x_i)^2+(pose_quan_fina_yy_res(i,vars)-pose_y_i)^2); 
    route_i_th=atan2((pose_quan_fina_yy_res(i,vars)-pose_y_i),(pose_quan_fina_xx_res(i,vars)-pose_x_i));
    if  route_i_th<0
         route_i_th= route_i_th+2*pi;
    end
    
% 
    if route_now_i>0
        V_fol_syn=sqrt(V_x^2+V_y^2);
            %领导者路径需要的时间            
           if route_now_i>V_fol_syn
               
               V_re=route_now_i-V_fol_syn;
               
           else
               V_re=0;
           end
            
          
        if V_re>=0
                


            V_re_x=V_re*cos(route_i_th);
           
            V_re_y=V_re*sin(route_i_th);
            
            if V_re_x>0
                V_re_x=min(Kinematic(3),V_re_x);

            else
                V_re_x=max(-Kinematic(4),V_re_x);   
            end

            if V_re_y>0
                V_re_y=min(Kinematic(3),V_re_y);

            else
                V_re_y=max(-Kinematic(4),V_re_y);
            end

           
            if (V_x>0 && V_re_x<0&&(abs(V_x)<abs(V_re_x)))
                V_re_x=-V_x;
            elseif (V_x<0&& V_re_x>0&&(abs(V_x)<abs(V_re_x)))
                V_re_x=-V_x;
            end
        else
            V_re_x=V_re*cos(route_i_th);
            % y方向补偿的速度值
            V_re_y=V_re*sin(route_i_th);
          
            if V_re_x>0
                V_re_x=min(Kinematic(3),V_re_x);

            else
                V_re_x=max(-Kinematic(4),V_re_x);   
            end

            if V_re_y>0
                V_re_y=min(Kinematic(3),V_re_y);

            else
                V_re_y=max(-Kinematic(4),V_re_y);
            end
            if (V_y>0 && V_re_y<0&&(abs(V_y)<abs(V_re_y)))
                V_re_y=-V_y;
            elseif (V_y<0&& V_re_y>0&&(abs(V_y)<abs(V_re_y)))
                V_re_y=-V_y;
            end
            
        end
    else
        V_re_x=0;
        V_re_y=0;
    end
end

