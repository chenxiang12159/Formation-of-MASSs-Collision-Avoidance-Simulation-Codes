function [formation,decide_num] = decide_lead_fol(i_opt_quanju_fina,obs_axis_fina,vars,N)
%UNTITLED 决定该船是属于跟随船还是领导者
%   该函数的作用是判断 该船出发时按照路径的序号大小成为跟随船与领导者船；到达第一个子目标点后 ，开始分类讨论谁是领导者 谁是跟随船
    %此函数 计算开始时刻的领导者和跟随船及他们的路径选择
%      decide_num(N)=1;
    decide_num(N)=N;
    form_num_N=0;

    sub_lead=min(find(obs_axis_fina(:,1)~=obs_axis_fina(N,1))); % 此处是默认了初始阶段只有两种路径可供选择
%     isfinte
%   该段函数是针对开头有一段编队一起行进的路径，所以如此设置
    if size(sub_lead,1)==0
         for i=1:N
                if i~=N
                        form_num_N=form_num_N+1;
                        formation(decide_num(N),form_num_N)=i;

                end
         end
    end
%     if sub_lead~=0
%         
% 
%             form_num_sub_lead=0;
%             decide_num(sub_lead)=sub_lead;
%         %     decide_num(sub_lead)=2;
%             for i=1:N
%                 if (i~=sub_lead)&&(i~=N)
% 
%                     if obs_axis_fina(i,vars(i)-1)==obs_axis_fina(N,vars(N)-1)&&i_opt_quanju_fina(i,vars(i)-1)==i_opt_quanju_fina(N,vars(N)-1)
%                         form_num_N=form_num_N+1;
%                         formation(decide_num(N),form_num_N)=i;
%                     end
% 
%                     if obs_axis_fina(i,vars(i)-1)==obs_axis_fina(sub_lead,vars(sub_lead)-1)&&i_opt_quanju_fina(i,vars(i)-1)==i_opt_quanju_fina(sub_lead,vars(sub_lead)-1)
%                         form_num_sub_lead=form_num_sub_lead+1;
%                         formation(decide_num(sub_lead),form_num_sub_lead)=i;
%                     end
%                 end
%             end
%     else
%         for i=1:N
%                 if i~=N
%                     if obs_axis_fina(i,vars(i)-1)==obs_axis_fina(N,vars(N)-1)&&i_opt_quanju_fina(i,vars(i)-1)==i_opt_quanju_fina(N,vars(N)-1)
%                         form_num_N=form_num_N+1;
%                         formation(decide_num(N),form_num_N)=i;
%                     end
%                 end
%          end
%     end
    

    


end

