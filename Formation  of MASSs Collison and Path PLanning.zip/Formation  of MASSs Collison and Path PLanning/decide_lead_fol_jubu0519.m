function [formation,decide_num] = decide_lead_fol_jubu0519(i_opt_quanju_fina,obs_axis_fina,vars,N,sub_lead,decide_num,judge_tran_cond,vars_rec,j,formation_cp,pose_quan_fina_x,pose_quan_fina_y,pose_x,pose_y,distance_jubu2vars,dis_st_fol)
%UNTITLED 决定该船是属于跟随船还是领导者
%   该函数的作用是判断 该船出发时按照路径的序号大小成为跟随船与领导者船；到达第一个子目标点后 ，开始分类讨论谁是领导者 谁是跟随船
    % 领导者占一个子领导位

    % 我建议给每个船的decide_num ，进行decide_num的变更
    % 配成他们船的序号，这样决定领导者和跟随船就会方便，但是相应的formation会变得相对复杂，对此进行变更。
%     clear formation;
    % 加入一个变量，当前位置距离领导者的距离。
    %% 目标点为3之前的编队状态判断
    % 加一个限定条件 ：使得无人船编队在经过第二个目标点后也进行相应的领导者判断
    if max(vars_rec(:,j))<4
    
    form_num=zeros(length(decide_num),1);
    re_judge=0;
    sel_num=0;
    select=0;
    
    % 对上一步的子领导者的重新判断:是否该去当跟随船了
    if (size(sub_lead,2)-1)>0
        
    
        for i_judge_lead=1:(size(sub_lead,2)-1)
            % 每次判断的条件都是从序号小的无人船对序号大的无人船进行对比，这其中会不会出现实际上序号小和序号大的处于同一段路径上，但序号小的船是比序号大的船要领先的，但是还是将序号小的给取消了无人船的身份呢？
            for  i_judge_lead_re=(size(sub_lead,2)-i_judge_lead):-1:1
                % 此处由于在起点增加了一段路径，使得vars发生了改进,是否进行了完善
                % 似乎没有考虑到将编队的领导者单独拿出来做例子，编队的总领导者与其他船冲突，则领导者的领导地位不变
                  if (vars(sub_lead(i_judge_lead))-2>0) && (vars(sub_lead(i_judge_lead+i_judge_lead_re))-2>0)
                        if i_opt_quanju_fina(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))-2)==i_opt_quanju_fina(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))-2)&&obs_axis_fina(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))-1)==obs_axis_fina(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))-1)...
                           &&i_opt_quanju_fina(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))-1)==i_opt_quanju_fina(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))-1)&&obs_axis_fina(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead)))==obs_axis_fina(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))) 
                              
                                      % 给领导者船作为特例，其他子领导者如果与领导者路径段一致，则直接把子领导者划分给领导者船，不需要进行判断。
                                     if sub_lead(i_judge_lead+i_judge_lead_re)==N
                                                decide_num(sub_lead(i_judge_lead))=0;
%                                                 re_judge=re_judge+1;
                                                % 应该顺便把该无人船划分为让其不是子领导者的船的下面
                                                form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)=form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)+1;
                                                formation(decide_num(sub_lead(i_judge_lead+i_judge_lead_re)),form_num(sub_lead(i_judge_lead+i_judge_lead_re),1))=sub_lead(i_judge_lead);
                                                % 标记该变成跟随船的子领导者船到达下面的跟随船自己组队的过程中
%                                                 re_judge_ship(re_judge)=sub_lead(i_judge_lead);
                                                sel_num=sel_num+1;
                                                select(sel_num)=sub_lead(i_judge_lead);
                                                break; 

                                     else


                                    % 这里不能任由 序号小的船变成子跟随船，需要根据两艘船相距目标点的距离来决定
                                        if distance_jubu2vars(sub_lead(i_judge_lead),j+1)>distance_jubu2vars(sub_lead(i_judge_lead+i_judge_lead_re),j+1)
    %                                     if sqrt((pose_x(sub_lead(i_judge_lead),j+1)-pose_quan_fina_x(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))))^2+(pose_y(sub_lead(i_judge_lead),j+1)-pose_quan_fina_y(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))))^2)...
    %                                         >sqrt((pose_x(sub_lead(i_judge_lead+i_judge_lead_re),j+1)-pose_quan_fina_x(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))))^2+(pose_y(sub_lead(i_judge_lead+i_judge_lead_re),j+1)-pose_quan_fina_y(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))))^2)

                                                decide_num(sub_lead(i_judge_lead))=0;
%                                                 re_judge=re_judge+1;
                                                % 应该顺便把该无人船划分为让其不是子领导者的船的下面
                                                form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)=form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)+1;
                                                formation(decide_num(sub_lead(i_judge_lead+i_judge_lead_re)),form_num(sub_lead(i_judge_lead+i_judge_lead_re),1))=sub_lead(i_judge_lead);
                                                % 标记该变成跟随船的子领导者船到达下面的跟随船自己组队的过程中
%                                                 re_judge_ship(re_judge)=sub_lead(i_judge_lead);
                                                sel_num=sel_num+1;
                                                select(sel_num)=sub_lead(i_judge_lead);
                                                break; 
                                        else     % 如果序号小的船与子目标点距离较近 则应该让后面的子领导者当序号小的跟随船

                                                decide_num(sub_lead(i_judge_lead+i_judge_lead_re))=0;
%                                                 re_judge=re_judge+1;
                                                % 应该顺便把该无人船划分为让其不是子领导者的船的下面
                                                form_num(sub_lead(i_judge_lead),1)=form_num(sub_lead(i_judge_lead),1)+1;
                                                formation(decide_num(sub_lead(i_judge_lead)),form_num(sub_lead(i_judge_lead),1))=sub_lead(i_judge_lead+i_judge_lead_re);
                                                % 标记该变成跟随船的子领导者船到达下面的跟随船自己组队的过程中
%                                                 re_judge_ship(re_judge)=sub_lead(i_judge_lead+i_judge_lead_re);
                                                sel_num=sel_num+1;
                                                select(sel_num)=sub_lead(i_judge_lead+i_judge_lead_re);
    %                                        % 这里不用break 因为还要继续判断别的子领导船是否需要变为跟随船   
                                        end
                                    end
                                

                        end

                  end

            end
            % 在下一个子领导者进行循环迭代判断之前进行更新
            sub_lead=find(decide_num~=0);
        end
        
    end
    % 对上一步的跟随船进行判断，需要判断跟随船的此次迭代后，继续是跟随某条子领导者船前进，还是自立门户，成为新的子领导者(没有船跟随也不用怕)。
    % 需要对decide_num 和formation 进行更新。
    sub_lead=find(decide_num~=0);

   
    for i_judge=1:length(sub_lead)
        if vars(sub_lead(i_judge))>2
            i_obs_choose(i_judge)=i_opt_quanju_fina(sub_lead(i_judge),vars(sub_lead(i_judge))-2);
            
        else
            i_obs_choose(i_judge)=i_opt_quanju_fina(sub_lead(i_judge),vars(sub_lead(i_judge))-1);
        end
        
        if vars_rec(sub_lead(i_judge),j-1)~=vars_rec(sub_lead(i_judge),j)
            % 这里得改
            if max(formation_cp(sub_lead(i_judge),:))>0 % 编队内的跟随船的的最大值大于0，代表了船舶的序号，说明该子领导者有跟随船
                for i_chu=1:(length(find(formation_cp(sub_lead(i_judge),:)~=0)))
                    if (vars(sub_lead(i_judge))-2>0)
                        % 这里需要分情况 就是该领导者所属的子船的vars 是否也进行了更新
                        if   (vars(formation_cp(sub_lead(i_judge),i_chu))-2>0)
                             if i_opt_quanju_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu))-2)==i_opt_quanju_fina(sub_lead(i_judge),vars(sub_lead(i_judge))-2)&&obs_axis_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu))-1)==obs_axis_fina(sub_lead(i_judge),vars(sub_lead(i_judge))-1)
                                     %在此处将船舶的编队进行分类    
                                        form_num(sub_lead(i_judge),1)=form_num(sub_lead(i_judge),1)+1;
                                        formation(sub_lead(i_judge),form_num(sub_lead(i_judge),1))=formation_cp(sub_lead(i_judge),i_chu);
                                        sel_num=sel_num+1;
                                        select(sel_num)=formation_cp(sub_lead(i_judge),i_chu);
                                        continue;
                             else

                                         if (ismember(i_opt_quanju_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu))-2),i_obs_choose)==0)
                                             decide_num(i_chu)=i_chu;
                                              i_obs_choose(i_chu)=i_opt_quanju_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu))-2);

                                         end


                             end
                        else
                             if i_opt_quanju_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu))-1)==i_opt_quanju_fina(sub_lead(i_judge),vars(sub_lead(i_judge))-2)&&obs_axis_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu)))==obs_axis_fina(sub_lead(i_judge),vars(sub_lead(i_judge))-1)
                                 %在此处将船舶的编队进行分类    
                                    form_num(sub_lead(i_judge),1)=form_num(sub_lead(i_judge),1)+1;
                                    formation(sub_lead(i_judge),form_num(sub_lead(i_judge),1))=formation_cp(sub_lead(i_judge),i_chu);
                                    sel_num=sel_num+1;
                                    select(sel_num)=formation_cp(sub_lead(i_judge),i_chu);
                                    continue;
                             else
                             
                                     if (ismember(i_opt_quanju_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu))-1),i_obs_choose)==0)
                                         decide_num(i_chu)=i_chu;
                                          i_obs_choose(i_chu)=i_opt_quanju_fina(formation_cp(sub_lead(i_judge),i_chu),vars(formation_cp(sub_lead(i_judge),i_chu))-1);

                                     end
                         
                
                             end
                       end
                        
                    end

                end
            end
        end
    end
    
    sub_lead=find(decide_num~=0);
    % 20220519更新将 子跟随船先于子领导者到达目标点的判断搬到上面也进行判断
    for i_v_c=1:length(sub_lead)
         if max(formation_cp(sub_lead(i_v_c),:))>0 
             for i_v_c_fol=1:length(find(formation_cp(sub_lead(i_v_c),:)~=0))
                    if vars_rec(sub_lead(i_v_c),j-1)==vars_rec(sub_lead(i_v_c),j)&&vars_rec(formation_cp(sub_lead(i_v_c),i_v_c_fol),j-1)~=vars_rec(formation_cp(sub_lead(i_v_c),i_v_c_fol),j)
                         if i_opt_quanju_fina(sub_lead(i_v_c),vars(sub_lead(i_v_c))-1)==i_opt_quanju_fina(formation_cp(sub_lead(i_v_c),i_v_c_fol),vars(formation_cp(sub_lead(i_v_c),i_v_c_fol))-2)&&obs_axis_fina(sub_lead(i_v_c),vars(sub_lead(i_v_c)))==obs_axis_fina(formation_cp(sub_lead(i_v_c),i_v_c_fol),vars(formation_cp(sub_lead(i_v_c),i_v_c_fol))-1)
                                form_num(sub_lead(i_v_c),1)=form_num(sub_lead(i_v_c),1)+1;
                                formation(sub_lead(i_v_c),form_num(sub_lead(i_v_c),1))=formation_cp(sub_lead(i_v_c),i_v_c_fol);
                                sel_num=sel_num+1;
                                select(sel_num)=formation_cp(sub_lead(i_v_c),i_v_c_fol);  
                             
                         end
                    end
             end
         end
    sub_lead=find(decide_num~=0);

        
    end
    for i_opt=1:N
        judge_ismember=0;
        for i_test=1:length(sub_lead)     % 将上一步的子领导者先拿出来让其他剩余子船进行对比
            if vars(i_opt)>=2&& vars(sub_lead(i_test))>=2
                
            
                    if (ismember(i_opt,sub_lead)||ismember(i_opt,select) )&&(judge_ismember==0)
                        % 问题出在这
                        % i_opt属于sub_lead,所以无法进行后续的避障了；如果下面领导者与跟随船互换了位置，需要对后面的领导者继续进行判断。
                        break;

                    else   
                       if i_opt_quanju_fina(i_opt,vars(i_opt)-1)==i_opt_quanju_fina(sub_lead(i_test),vars(sub_lead(i_test))-1)&&obs_axis_fina(i_opt,vars(i_opt))==obs_axis_fina(sub_lead(i_test),vars(sub_lead(i_test)))
                            % 对某艘可能成为跟随船的 船 还是要判断一下其于子领导者的位置。
                                    if ((distance_jubu2vars(sub_lead(i_test),j+1)-distance_jubu2vars(i_opt,j+1)<max(dis_st_fol(:)))||(sub_lead(i_test)==N))
                                            form_num(sub_lead(i_test),1)=form_num(sub_lead(i_test),1)+1;
                                            formation(sub_lead(i_test),form_num(sub_lead(i_test),1))=i_opt;
                                            % 判断刚刚成为跟随船的船是否有其他的跟随船,以及将其他的子跟随船都迁移到对应的新的领导者下面
                                            if decide_num(i_opt)>0
                                                decide_num(i_opt)=0;
                                                
                                            end
                                            if form_num(i_opt,1)>0
                                                  if max(formation(i_opt,:))>0

                                                        for i_qianyi=1:(length(find(formation(i_opt,:)~=0)))
                                                            form_num(sub_lead(i_test),1)=form_num(sub_lead(i_test),1)+1;
                                                            formation(sub_lead(i_test),form_num(sub_lead(i_test),1))=formation(i_opt,i_qianyi);

                                                        end

                                                  end
                                                
                                            end
                                            sub_lead=find(decide_num~=0);
                                            break;
                                    else    
                                            decide_num(sub_lead(i_test))=0;

                                            if form_num(sub_lead(i_test),1)>0
                                                
                                                   if max(formation(sub_lead(i_test),:))>0
                                                            
                                                        for i_qianyi=1:(length(find(formation(sub_lead(i_test),:)~=0)))
                                                            form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                            formation(i_opt,form_num(i_opt,1))=formation(sub_lead(i_test),i_qianyi);

                                                        end
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                        % 消除本身具有的子跟随船的相关变量
                                                        form_num(sub_lead(i_test),1)=0;
                                                        formation(sub_lead(i_test),:)=0;
                                                   else
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                        
                                                        % 消除本身具有的子跟随船的相关变量
                                                        form_num(sub_lead(i_test),1)=0;
                                                        formation(sub_lead(i_test),:)=0;
                                                   end
                                                
                                            else
                                                if max(formation_cp(sub_lead(i_test),:))>0

                                                        for i_qianyi=1:(length(find(formation_cp(sub_lead(i_test),:)~=0)))
                                                            if formation_cp(sub_lead(i_test),i_qianyi)<i_opt
                                                                form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                                formation(i_opt,form_num(i_opt,1))=formation_cp(sub_lead(i_test),i_qianyi);
                                                            end
                                                        end
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                else
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                end
                                                
                                                
                                            end

                                                    %需要将该i_opt子船给重新设定为子领导者
                                                    decide_num(i_opt)=i_opt;
                                                    sub_lead=find(decide_num~=0);
                                                    judge_ismember=1;
%                                             break;
                                    end
                                    
                      
                       end
                       
   
                    end

                    if  i_test==length(sub_lead)    % 在路径判断的过程中，如果该点不属于任何一个子领导者的跟随船，在此成为一个新的子领导者，并且更新相应的
                        decide_num(i_opt)=i_opt;
                        sub_lead=find(decide_num~=0);
                    end
              
            end
            
        end

            
    end

        
        
        
        
        
        
        
        
        
        
        
    else
    %% 目标点为3之后的编队状态判断
    
    form_num=zeros(length(decide_num),1);
    re_judge=0;
    sel_num=0;
    select=0;
    % 对上一步的子领导者的重新判断:是否该去当跟随船了
    if (size(sub_lead,2)-1)>0
        
    
        for i_judge_lead=1:(size(sub_lead,2)-1)
            % 每次判断的条件都是从序号小的无人船对序号大的无人船进行对比，这其中会不会出现实际上序号小和序号大的处于同一段路径上，但序号小的船是比序号大的船要领先的，但是还是将序号小的给取消了无人船的身份呢？
            for  i_judge_lead_re=(size(sub_lead,2)-i_judge_lead):-1:1
                % 此处由于在起点增加了一段路径，使得vars发生了改进,是否进行了完善
                % 似乎没有考虑到将编队的领导者单独拿出来做例子，编队的总领导者与其他船冲突，则领导者的领导地位不变
                        if judge_tran_cond(sub_lead(i_judge_lead))==1
                             decide_num(sub_lead(i_judge_lead))=0;
%                              re_judge=re_judge+1;
                             form_num(N,1)=form_num(N,1)+1;
                             formation(N,form_num(N,1))=sub_lead(i_judge_lead);
%                              re_judge_ship(re_judge)=sub_lead(i_judge_lead);
                             sel_num=sel_num+1;
                             select(sel_num)=sub_lead(i_judge_lead);
                             break;
                        end
                  if (vars(sub_lead(i_judge_lead))-2>0) && (vars(sub_lead(i_judge_lead+i_judge_lead_re))-2>0)
                        if i_opt_quanju_fina(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))-2)==i_opt_quanju_fina(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))-2)&&obs_axis_fina(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))-1)==obs_axis_fina(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))-1)
                            if (vars(sub_lead(i_judge_lead))-3>0) && (vars(sub_lead(i_judge_lead+i_judge_lead_re))-3>0)
                                if i_opt_quanju_fina(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))-3)==i_opt_quanju_fina(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))-3) % 这一步是判断如果两个子领导者的子目标点一致，说明有可能是要将新的子领导者汇合，但是不能将两条路径进行合流，所以再判断一次他们的切换子目标点前的出发点是否一致。
                                      % 给领导者船作为特例，其他子领导者如果与领导者路径段一致，则直接把子领导者划分给领导者船，不需要进行判断。
                                     if sub_lead(i_judge_lead+i_judge_lead_re)==N
                                                decide_num(sub_lead(i_judge_lead))=0;
%                                                 re_judge=re_judge+1;
                                                % 应该顺便把该无人船划分为让其不是子领导者的船的下面
                                                form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)=form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)+1;
                                                formation(decide_num(sub_lead(i_judge_lead+i_judge_lead_re)),form_num(sub_lead(i_judge_lead+i_judge_lead_re),1))=sub_lead(i_judge_lead);
                                                % 标记该变成跟随船的子领导者船到达下面的跟随船自己组队的过程中
%                                                 re_judge_ship(re_judge)=sub_lead(i_judge_lead);
                                                sel_num=sel_num+1;
                                                select(sel_num)=sub_lead(i_judge_lead);
                                                break; 

                                     else


                                    % 这里不能任由 序号小的船变成子跟随船，需要根据两艘船相距目标点的距离来决定
                                        if distance_jubu2vars(sub_lead(i_judge_lead),j+1)>distance_jubu2vars(sub_lead(i_judge_lead+i_judge_lead_re),j+1)
    %                                     if sqrt((pose_x(sub_lead(i_judge_lead),j+1)-pose_quan_fina_x(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))))^2+(pose_y(sub_lead(i_judge_lead),j+1)-pose_quan_fina_y(sub_lead(i_judge_lead),vars(sub_lead(i_judge_lead))))^2)...
    %                                         >sqrt((pose_x(sub_lead(i_judge_lead+i_judge_lead_re),j+1)-pose_quan_fina_x(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))))^2+(pose_y(sub_lead(i_judge_lead+i_judge_lead_re),j+1)-pose_quan_fina_y(sub_lead(i_judge_lead+i_judge_lead_re),vars(sub_lead(i_judge_lead+i_judge_lead_re))))^2)

                                                decide_num(sub_lead(i_judge_lead))=0;
%                                                 re_judge=re_judge+1;
                                                % 应该顺便把该无人船划分为让其不是子领导者的船的下面
                                                form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)=form_num(sub_lead(i_judge_lead+i_judge_lead_re),1)+1;
                                                formation(decide_num(sub_lead(i_judge_lead+i_judge_lead_re)),form_num(sub_lead(i_judge_lead+i_judge_lead_re),1))=sub_lead(i_judge_lead);
                                                % 标记该变成跟随船的子领导者船到达下面的跟随船自己组队的过程中
%                                                 re_judge_ship(re_judge)=sub_lead(i_judge_lead);
                                                sel_num=sel_num+1;
                                                select(sel_num)=sub_lead(i_judge_lead);
                                                break; 
                                        else     % 如果序号小的船与子目标点距离较近 则应该让后面的子领导者当序号小的跟随船

                                                decide_num(sub_lead(i_judge_lead+i_judge_lead_re))=0;
%                                                 re_judge=re_judge+1;
                                                % 应该顺便把该无人船划分为让其不是子领导者的船的下面
                                                form_num(sub_lead(i_judge_lead),1)=form_num(sub_lead(i_judge_lead),1)+1;
                                                formation(decide_num(sub_lead(i_judge_lead)),form_num(sub_lead(i_judge_lead),1))=sub_lead(i_judge_lead+i_judge_lead_re);
                                                % 标记该变成跟随船的子领导者船到达下面的跟随船自己组队的过程中
%                                                 re_judge_ship(re_judge)=sub_lead(i_judge_lead+i_judge_lead_re);
                                                sel_num=sel_num+1;
                                                select(sel_num)=sub_lead(i_judge_lead+i_judge_lead_re);
    %                                        % 这里不用break 因为还要继续判断别的子领导船是否需要变为跟随船   
                                        end
                                    end
                                end
                            end
                        end

                                % 是否直接在此处就把该子领导者划分为某个领导者的跟随船
                                % 存在问题：假如在变换领导者的过程中，子领导者率先完成了自己的路径点，但是此时它的跟随船还没有完全到达他应该的子目标点，那应该将跟随船1.独立出来，设置原先二次路径的子目标点为现在子目标点2.查询剩余和它同样类型的船，在组成一个编队，继续完成到二次路径优化后的子目标点。
                  end

            end
            % 在下一个子领导者进行循环迭代判断之前进行更新
            sub_lead=find(decide_num~=0);
        end
        
    end
    % 对上一步的跟随船进行判断，需要判断跟随船的此次迭代后，继续是跟随某条子领导者船前进，还是自立门户，成为新的子领导者(没有船跟随也不用怕)。
    % 需要对decide_num 和formation 进行更新。
    sub_lead=find(decide_num~=0);


    for i_judge=1:length(sub_lead)
        if vars_rec(sub_lead(i_judge),j-1)~=vars_rec(sub_lead(i_judge),j)
            if max(formation_cp(sub_lead(i_judge),:))>0 % 编队内的跟随船的的最大值大于0，代表了船舶的序号，说明该子领导者有跟随船
                
                % 这里的选择，应该是计算出哪一个跟随船距离vars （本次的——与其上一迭代的子领导者的var值应保持一致）目标点最近，则自动将其视为子领导者。 
                % 问题：如果下一迭代有编号更小的船为子领导者，该怎么决定。这样应该不会出现尾巴的现象了
                % 问题：有没有一种设想会出现先判定的是vars值比较小的子目标点，那就是有问题的选择和判断
                for i_cal=1:(length(find(formation_cp(sub_lead(i_judge),:)~=0)))
                    cal_dis(i_cal)=sqrt((pose_quan_fina_x(formation_cp(sub_lead(i_judge),i_cal),vars(formation_cp(sub_lead(i_judge),i_cal)))-pose_x(formation_cp(sub_lead(i_judge),i_cal),j+1))^2+((pose_quan_fina_y(formation_cp(sub_lead(i_judge),i_cal),vars(formation_cp(sub_lead(i_judge),i_cal)))-pose_y(formation_cp(sub_lead(i_judge),i_cal),j+1))^2));
                end
                    min_cal_dis=find(cal_dis==min(cal_dis(find(cal_dis~=0))));
                    decide_num(formation_cp(sub_lead(i_judge),min_cal_dis))= formation_cp(sub_lead(i_judge),min_cal_dis);
                    cal_dis(:)=0;
%                     judge_num=0;
                for i_trans=1:(length(find(formation_cp(sub_lead(i_judge),:)~=0)))
                    % 这得函数原来是为了找到距离目标点最近的船，并把原来子领导则下属的跟随船都分给当前的新成立的领导者
                    if ismember(i_trans,min_cal_dis)

%                         continue;
                    else
%                             judge_num=1;
                            form_num(formation_cp(sub_lead(i_judge),min_cal_dis),1)=form_num(formation_cp(sub_lead(i_judge),min_cal_dis),1)+1;
                            formation(decide_num(formation_cp(sub_lead(i_judge),min_cal_dis)),form_num(formation_cp(sub_lead(i_judge),min_cal_dis),1))=formation_cp(sub_lead(i_judge),i_trans);
                            sel_num=sel_num+1;
                            select(sel_num)=formation_cp(sub_lead(i_judge),i_trans);
                    end
                    
%                     if
%                         
%                     end
                   
                    

                end
            else
                 continue;
            end
         
        end
        
    end
    
    % 判断re_judge 是否存在船
%     if max(re_judge)>0
%          for i_judge=1:length(re_judge_ship)
% 
%                 if max(formation_cp(re_judge_ship(i_judge),:))>0 % 编队内的跟随船的的最大值大于0，代表了船舶的序号，说明该子领导者有跟随船
% 
%                     这里的选择，应该是计算出哪一个跟随船距离vars （本次的——与其上一迭代的子领导者的var值应保持一致）目标点最近，则自动将其视为子领导者。 
%                     问题：如果下一迭代有编号更小的船为子领导者，该怎么决定。这样应该不会出现尾巴的现象了
%                     问题：有没有一种设想会出现先判定的是vars值比较小的子目标点，那就是有问题的选择和判断
%                     for i_cal=1:(length(find(formation_cp(re_judge_ship(i_judge),:)~=0)))
%                         cal_dis_re(i_cal)=sqrt((pose_quan_fina_x(formation_cp(re_judge_ship(i_judge),i_cal),vars(formation_cp(re_judge_ship(i_judge),i_cal)))-pose_x(formation_cp(re_judge_ship(i_judge),i_cal),j+1))^2+((pose_quan_fina_y(formation_cp(re_judge_ship(i_judge),i_cal),vars(formation_cp(re_judge_ship(i_judge),i_cal)))-pose_y(formation_cp(re_judge_ship(i_judge),i_cal),j+1))^2));
%                     end
%                         min_cal_dis=find(cal_dis_re==min(cal_dis_re(find(cal_dis_re~=0))));
%                         decide_num(formation_cp(re_judge_ship(i_judge),min_cal_dis))= formation_cp(re_judge_ship(i_judge),min_cal_dis);
%                         cal_dis_re(:)=0;
%                     for i_trans=1:(length(find(formation_cp(re_judge_ship(i_judge),:)~=0)))
%                         if i_trans==min_cal_dis
%                             
%                             continue;
%                         else
%                                 form_num(formation_cp(re_judge_ship(i_judge),min_cal_dis),1)=form_num(formation_cp(re_judge_ship(i_judge),min_cal_dis),1)+1;
%                                 formation(decide_num(formation_cp(re_judge_ship(i_judge),min_cal_dis)),form_num(formation_cp(re_judge_ship(i_judge),min_cal_dis),1))=formation_cp(re_judge_ship(i_judge),i_trans);
%                                 sel_num=sel_num+1;
%                                 select(sel_num)=formation_cp(re_judge_ship(i_judge),i_trans);
%                         end
% 
% 
% 
%                     end
%                 else
%                      continue;
%                 end
% 
% 
% 
%         end
%     end
    sub_lead=find(decide_num~=0);
    for i_v_c=1:length(sub_lead)
         if max(formation_cp(sub_lead(i_v_c),:))>0 
             for i_v_c_fol=1:length(find(formation_cp(sub_lead(i_v_c),:)~=0))
                    if vars_rec(sub_lead(i_v_c),j-1)==vars_rec(sub_lead(i_v_c),j)&&vars_rec(formation_cp(sub_lead(i_v_c),i_v_c_fol),j-1)~=vars_rec(formation_cp(sub_lead(i_v_c),i_v_c_fol),j)
                         if i_opt_quanju_fina(sub_lead(i_v_c),vars(sub_lead(i_v_c))-1)==i_opt_quanju_fina(formation_cp(sub_lead(i_v_c),i_v_c_fol),vars(formation_cp(sub_lead(i_v_c),i_v_c_fol))-2)&&obs_axis_fina(sub_lead(i_v_c),vars(sub_lead(i_v_c)))==obs_axis_fina(formation_cp(sub_lead(i_v_c),i_v_c_fol),vars(formation_cp(sub_lead(i_v_c),i_v_c_fol))-1)
                                form_num(sub_lead(i_v_c),1)=form_num(sub_lead(i_v_c),1)+1;
                                formation(sub_lead(i_v_c),form_num(sub_lead(i_v_c),1))=formation_cp(sub_lead(i_v_c),i_v_c_fol);
                                sel_num=sel_num+1;
                                select(sel_num)=formation_cp(sub_lead(i_v_c),i_v_c_fol);  
                             
                         end
                    end
             end
         end
    sub_lead=find(decide_num~=0);

        
    end
    % 新出现的子领导者是否能够 真正担任领导者的位置， 他们距离子目标点的距离相对于想要跟随它的船而言是否是最近
    for i_opt=1:N
        judge_ismember=0;
        for i_test=1:length(sub_lead)     % 将上一步的子领导者先拿出来让其他剩余子船进行对比
            if vars(i_opt)>2&& vars(sub_lead(i_test))>2
                
            
                    if (ismember(i_opt,sub_lead)||ismember(i_opt,select) )&&(judge_ismember==0)
                        % 问题出在这
                        % i_opt属于sub_lead,所以无法进行后续的避障了；如果下面领导者与跟随船互换了位置，需要对后面的领导者继续进行判断。
                        break;

                    else
                        
                       if judge_tran_cond(i_opt)==1
                           form_num(sub_lead(length(sub_lead)),1)= form_num(sub_lead(length(sub_lead)),1)+1;
                           formation(decide_num(sub_lead(length(sub_lead))),form_num(sub_lead(length(sub_lead)),1))=i_opt;
                           break;
                       end
                       
                       if i_opt_quanju_fina(i_opt,vars(i_opt)-2)==i_opt_quanju_fina(sub_lead(i_test),vars(sub_lead(i_test))-2)&&obs_axis_fina(i_opt,vars(i_opt)-1)==obs_axis_fina(sub_lead(i_test),vars(sub_lead(i_test))-1)
                            % 对某艘可能成为跟随船的 船 还是要判断一下其于子领导者的位置。
                            if (vars(sub_lead(i_test))>3) && (vars(i_opt)>3)
                                if i_opt_quanju_fina(i_opt,vars(i_opt)-3)==i_opt_quanju_fina(sub_lead(i_test),vars(sub_lead(i_test))-3)&&obs_axis_fina(i_opt,vars(i_opt)-2)==obs_axis_fina(sub_lead(i_test),vars(sub_lead(i_test))-2)
                                    
                                    if ((distance_jubu2vars(sub_lead(i_test),j+1)-distance_jubu2vars(i_opt,j+1)<max(dis_st_fol(:)))||(sub_lead(i_test)==N))
                                            form_num(sub_lead(i_test),1)=form_num(sub_lead(i_test),1)+1;
                                            formation(decide_num(sub_lead(i_test)),form_num(sub_lead(i_test),1))=i_opt;
                                            % 判断刚刚成为跟随船的船是否有其他的跟随船,以及将其他的子跟随船都迁移到对应的新的领导者下面
                                            if decide_num(i_opt)>0
                                                decide_num(i_opt)=0;
                                                
                                            end
                                            if form_num(i_opt,1)>0
                                                  if max(formation(i_opt,:))>0

                                                        for i_qianyi=1:(length(find(formation(i_opt,:)~=0)))
                                                            form_num(sub_lead(i_test),1)=form_num(sub_lead(i_test),1)+1;
                                                            formation(sub_lead(i_test),form_num(sub_lead(i_test),1))=formation(i_opt,i_qianyi);

                                                        end
                                                        form_num(sub_lead(i_test),1)=form_num(sub_lead(i_test),1)+1;
                                                        formation(sub_lead(i_test),form_num(sub_lead(i_test),1))=i_opt;
                                                  else
                                                        form_num(sub_lead(i_test),1)=form_num(sub_lead(i_test),1)+1;
                                                        formation(sub_lead(i_test),form_num(sub_lead(i_test),1))=i_opt;
                                                  end
                                                
                                            end
                                            sub_lead=find(decide_num~=0);
                                            break;
                                    else    % 如果该跟随船与子目标点的距离比子领导者与子目标点的距离还近，则需要调换它与子领导者之间的  关系与 子领导者之间的跟随船的数量
                                                    decide_num(sub_lead(i_test))=0;

                                                    % 应该顺便把该无人船划分为让其不是子领导者的船的下面
                                                    % 该循环是让如果该子领导者的编队中有无人船，则需要将它本身带有的跟随船迁移到新的子领导者下面
                                                    % 对选择formation 还是formation_cp
                                                    % 顺序应该是先formation，看看此时的是否存在新的船，不存在新的跟随船则使用formation_cp
                                                    % 这个合理吗 需要考虑
                                            if form_num(sub_lead(i_test),1)>0
                                                
                                                   if max(formation(sub_lead(i_test),:))>0
                                                            
                                                        for i_qianyi=1:(length(find(formation(sub_lead(i_test),:)~=0)))
                                                            form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                            formation(i_opt,form_num(i_opt,1))=formation(sub_lead(i_test),i_qianyi);

                                                        end
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                        % 消除本身具有的子跟随船的相关变量
                                                        form_num(sub_lead(i_test),1)=0;
                                                        formation(sub_lead(i_test),:)=0;
                                                   else
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                        
                                                        % 消除本身具有的子跟随船的相关变量
                                                        form_num(sub_lead(i_test),1)=0;
                                                        formation(sub_lead(i_test),:)=0;
                                                   end
                                                
                                            else
                                                if max(formation_cp(sub_lead(i_test),:))>0

                                                        for i_qianyi=1:(length(find(formation_cp(sub_lead(i_test),:)~=0)))
                                                            if formation_cp(sub_lead(i_test),i_qianyi)<i_opt
                                                                form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                                formation(i_opt,form_num(i_opt,1))=formation_cp(sub_lead(i_test),i_qianyi);
                                                            end
                                                        end
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                else
                                                        form_num(i_opt,1)=form_num(i_opt,1)+1;
                                                        formation(i_opt,form_num(i_opt,1))=sub_lead(i_test);
                                                end
                                                
                                                
                                            end

                                                    %需要将该i_opt子船给重新设定为子领导者
                                                    decide_num(i_opt)=i_opt;
                                                    sub_lead=find(decide_num~=0);
                                                    judge_ismember=1;
%                                             break;
                                    end
                                end
                                
                            else
                                  form_num(sub_lead(i_test),1)=form_num(sub_lead(i_test),1)+1;
                                  formation(decide_num(sub_lead(i_test)),form_num(sub_lead(i_test),1))=i_opt;
                                  break;
                            end



                            

                       end
                       

                    end

                    if  i_test==length(sub_lead)    % 在路径判断的过程中，如果该点不属于任何一个子领导者的跟随船，在此成为一个新的子领导者，并且更新相应的
                        decide_num(i_opt)=i_opt;
                        sub_lead=find(decide_num~=0);
                    end
            elseif vars(i_opt)>2
                  if  i_test==length(sub_lead)    % 在路径判断的过程中，如果该点不属于任何一个子领导者的跟随船，在此成为一个新的子领导者，并且更新相应的
                        decide_num(i_opt)=i_opt;
                        sub_lead=find(decide_num~=0);
                        
                  end
                
            end
            
        end

            
    end
    
    
    
    
    
    
    
    
    
    
    
    
    
    end
    
    
    
    
    
    
   % 对生成的formation的每一行 进行重新排序 sort ,因为可能存在乱序的情况。
    if size(sub_lead,2)==20
        formation=zeros(N,1);
        
    end
%    formation_cp
%    formation
   
    % 作为最后解决思路的措施，如果本次无任何子船的变化则维持原样
    if max(form_num)==0&& size(sub_lead,2)~=20
        formation=formation_cp;
    else

           for i_sort=1:length(sub_lead)
                if form_num(sub_lead(i_sort),1)>0
                    
                       if max(formation(sub_lead(i_sort),:))>0
                           num=(length(find(formation(sub_lead(i_sort),:)~=0)));
                           formation(sub_lead(i_sort),1:num)=sort(formation(sub_lead(i_sort),1:num));

                       end
                end
       
           end
    end


end